package Utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Configuration {
	
	public String FetchData() throws IOException
	{
	File f = new File("D:\\Workspace\\Appium\\locator.properties");
	FileInputStream input= new FileInputStream(f);
	Properties p = new Properties();
	p.load(input);
    final String loc = p.getProperty("findLoc");
    return loc;
	}

}
