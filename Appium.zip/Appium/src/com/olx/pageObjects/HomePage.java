package com.olx.pageObjects;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;
import java.util.Properties;

import javax.security.auth.login.Configuration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import Utility.SharedClass;

public class HomePage extends SharedClass {
	
	
    
	@FindBy(xpath = "//input[starts-with(@id,'undefined-Pleasetypeyourlocation')]")
	public static  WebElement location;
	@FindBy(xpath = "//i[@class='material-icons']")
	public static List<WebElement> location_Count;
	@FindBy(xpath = "//i[text()='photo_camera']")
	public static WebElement Click_Sell;
	
	public static  void OlxWebApp() throws InterruptedException
	{
		Thread.sleep(10000);
		location.sendKeys("sangam vihar");
		Thread.sleep(10000);
		int count = location_Count.size();
		System.out.println(count);
		Thread.sleep(5000);
		location_Count.get(2).click();
		Thread.sleep(5000);
		Click_Sell.click();
	}
}
