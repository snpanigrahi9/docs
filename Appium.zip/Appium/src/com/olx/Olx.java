    package com.olx;

	import org.testng.annotations.Test;
    import com.olx.pageObjects.HomePage;
    import Utility.SharedClass;

	public class Olx extends SharedClass{
		
		@Test
		public void regression() throws InterruptedException
		{
			logger = reports.createTest("regression");
			driver.get("https://www.olx.in/");
			Thread.sleep(5000);
			HomePage.OlxWebApp();	
		}				
	}

