package com.olx;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class Olx1 {

	//AppiumDriver driver;
	AndroidDriver driver;
	DesiredCapabilities cap;
	ExtentReports report;
	ExtentHtmlReporter htmlreport;
	ExtentTest logger;
	@BeforeTest
	public void intialize() throws MalformedURLException
	{
		cap = new DesiredCapabilities();
		cap.setCapability(MobileCapabilityType.AUTOMATION_NAME,"Appium");
		cap.setCapability(MobileCapabilityType.DEVICE_NAME,"Redmi");
		cap.setCapability(MobileCapabilityType.BROWSER_NAME, "Chrome");
		cap.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		cap.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, "5000");
		cap.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6.0.1");
		driver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"),cap);
		
		report = new ExtentReports();
		htmlreport = new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-output/MyextentReport.html");
		report.attachReporter(htmlreport);
		report.setSystemInfo("Host Name", "Satya-4720");
		report.setSystemInfo("Env", "Olx Regression");
		report.setSystemInfo("User", "Satyanarayan Panigrahi");	
	}
	@Test
	public void regression() throws InterruptedException
	{
		logger = report.createTest("regression");
		driver.get("https://www.olx.in/");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//input[starts-with(@id,'undefined-Pleasetypeyourlocation')]")).sendKeys("sangam vihar");
		Thread.sleep(10000);
		int count = driver.findElementsByXPath("//i[@class='material-icons']").size();
		System.out.println(count);
		List<WebElement>locations = driver.findElements(By.xpath("//i[@class='material-icons']"));
		Thread.sleep(5000);
		locations.get(2).click();
		Thread.sleep(5000);
		driver.findElementByAndroidUIAutomator("new UiScrollable(new UiSelector()).scrollIntoView("+ "new UiSelector().text(\"_input your text name here_\"));").click();
		driver.findElement(By.xpath("//i[text()='photo_camera']//")).click();
		
	}
		
	@AfterMethod
		public void Result(ITestResult result)
		{
			if(result.getStatus() == ITestResult.SUCCESS)
			{
				logger.pass(result.getName());
			}
			if(result.getStatus() == ITestResult.FAILURE)
			{
				logger.fail(result.getName());
				
			}
			if(result.getStatus() == ITestResult.SKIP)
			{
				//logger.skip(result.getName());
				System.out.println(result.getMethod()+"is skipped");
			}
}
		@AfterTest
		public void end()
		{
			report.flush();
		}
				
	}

