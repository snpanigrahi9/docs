package Report;

import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Utility.Configuration;
import Utility.SharedClass;

public class TestReport extends Configuration
     {
	public static ExtentReports reports;
	public static ExtentHtmlReporter htmlreport;
	public static  ExtentTest logger;
        
	    public void setEnvironment()
	    {
		reports = new ExtentReports();
		htmlreport = new ExtentHtmlReporter(System.getProperty("user.dir")+"/test-output/MyextentReport.html");
		reports.attachReporter(htmlreport);
		reports.setSystemInfo("Host Name", "Satya-4720");
		reports.setSystemInfo("Env", "Olx Regression");
		reports.setSystemInfo("User", "Satyanarayan Panigrahi");
	    
	    }
   
   @AfterMethod
	public void Result(ITestResult result)
	{
		if(result.getStatus() == ITestResult.SUCCESS)
		{
			logger.pass(result.getName());
		}
		if(result.getStatus() == ITestResult.FAILURE)
		{
			logger.fail(result.getName());
			
		}
		if(result.getStatus() == ITestResult.SKIP)
		{
			logger.skip(result.getName());
		}
	}
    @AfterTest
	public static void End()
	{
		reports.flush();
	} 
}
