package com.igt.base;

import java.util.HashMap;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BrowserFactory {
	
	private static BrowserFactory instance= null;
	ThreadLocal<WebDriver> d = new ThreadLocal<WebDriver>();
	
	private BrowserFactory()
	{
		
		
	}
	
	public static BrowserFactory getInstance()
	{
		if (instance == null)
		{
			instance = new BrowserFactory();
			
		}
		return instance;
		
	}
	
	public final void setDriver(String browser)
	{
		
		if(browser.equalsIgnoreCase("chrome"))
		{
			String downloadFilepath = System.getProperty("user.dir")+"\\src\\main\\resources\\Reporting";
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", downloadFilepath);
			ChromeOptions options = new ChromeOptions();
			options.setExperimentalOption("prefs", chromePrefs);
			options.addArguments("--test-type");
			options.addArguments("--disable-extensions");
			options.setAcceptInsecureCerts(true);
			options.addArguments("ignore-certificate-errors");
			options.addArguments("--remote-allow-origins=*"); 
			//WebDriverManager.chromedriver().setup();
			
			d.set(new ChromeDriver(options));
			
			
		}
		
		else if(browser.equalsIgnoreCase("firefox"))
		{
			FirefoxOptions option = new FirefoxOptions();
			option.setAcceptInsecureCerts(true);
			option.addPreference("dom.file.createInChild", true);
			//option.setCapability("marionette", true);
    		//WebDriverManager.firefoxdriver().setup();
			d.set(new FirefoxDriver(option));
		}
		else if(browser.equalsIgnoreCase("headlesschrome"))
		{
			String downloadFilepath = System.getProperty("user.dir")+"\\src\\main\\resources\\Reporting";
			HashMap<String, Object> chromePrefs = new HashMap<String, Object>();
			chromePrefs.put("profile.default_content_settings.popups", 0);
			chromePrefs.put("download.default_directory", downloadFilepath);
		    ChromeOptions options = new ChromeOptions();
		    // options.setBinary("C:\\Program Files (x86)\\Google\\Chrome Beta\\Application\\chrome.exe");
		    options.addArguments("window-size=1920,1080");
		    options.setHeadless(true);
		    options.setCapability("acceptInsecureCerts", true);
		    options.addArguments("--remote-allow-origins=*");
		    d.set(new ChromeDriver(options));
		    
		}
		else if(browser.equalsIgnoreCase("headlessfirefox"))
		{
			FirefoxOptions option = new FirefoxOptions();
			option.setAcceptInsecureCerts(true);
			//option.setCapability("marionette", true);
			option.setHeadless(true);
			d.set(new FirefoxDriver(option));
		}
		
	}
	
	
	public WebDriver getDriver()
	{
		return d.get();
	}
	

}
