package com.igt.base;


import java.io.File;
import java.io.FileInputStream;
import java.util.Hashtable;
import java.util.LinkedHashMap;
import java.util.Properties;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.github.javafaker.Faker;
import com.igt.pageObjects.AgentDashboard;
import com.igt.pageObjects.AgentLogin;
import com.igt.pageObjects.AllocateGDSQueueToSitepartition;
import com.igt.pageObjects.AstqAllocation;
import com.igt.pageObjects.AutoTask;
import com.igt.pageObjects.Breaks;
import com.igt.pageObjects.Dashboard;
import com.igt.pageObjects.InboundCall;
import com.igt.pageObjects.Login;
import com.igt.pageObjects.ManageMasterData;
import com.igt.pageObjects.ManageSTQ;
import com.igt.pageObjects.ManageUsers;
import com.igt.pageObjects.ManualTask;
import com.igt.pageObjects.ManualWorkItem;
import com.igt.pageObjects.Reports;
import com.igt.pageObjects.SkillTaskQueueConfiguration;
import com.igt.pageObjects.TaskBasket;
import com.igt.pageObjects.UserProfile;
import com.igt.stepDefinition.GBTStepDefinition;
import io.cucumber.core.gherkin.Feature;
import io.cucumber.java.Scenario;


public class TestSetup  {
	
	
	public static DesiredCapabilities caps;  
	//public static WebDriver d;
	public String BrowserName;
	public static Properties p;
	public static Properties pro;
	public static Feature feature;
	public Scenario scenario;
	public static long l;
	public Login log;
	public ManageMasterData mmd;
	public ManageSTQ ms;
	public AllocateGDSQueueToSitepartition gs;
	public SkillTaskQueueConfiguration stqc;
	public AstqAllocation aa;
	public Reports rep;
	public Dashboard db;
	public ManageUsers mu;
	public XSSFWorkbook workbook=null;
	public static File file =null;
	public FileInputStream fis=null;
	public static XSSFCell cell=null;
	public static XSSFSheet sheet=null;
	public static XSSFRow row=null;
	public static String Recipientlist ;
	public static GBTStepDefinition definition;
	public static Faker faker;
    public String filename=null;
    
    
    public AgentLogin alog;
    public AgentDashboard adb;
    public AutoTask at;
    public ManualTask mt;
    public ManualWorkItem mwi;
    public TaskBasket tb;
    public UserProfile up;
    public InboundCall ic;
    public Breaks brks;
}
