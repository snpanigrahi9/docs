package com.igt.base;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import com.igt.base.BrowserFactory;
import com.google.common.io.Files;
import com.igt.utility.UserActions;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class TestBase extends TestSetup {
		
	    UserActions ua = null;
	
		public static void loadProperty()
		{
			p = new Properties();
			pro = new Properties();
			try {
				File ff = new File(System.getProperty("user.dir")+"//src//main//resources//Config//config.properties");
				System.out.println(ff);
				FileInputStream f = new FileInputStream(ff);
				p.load(f);
			} catch (Exception e) {
				
				e.printStackTrace();
				
			}
		}
		
		
		public static void loadUserInput()
		{
			try {
			File file = new File(System.getProperty("user.dir")+"//src//main//resources//Config//UserInput.properties");
				
			System.out.println(file);
			FileInputStream input = new FileInputStream(file);
			pro.load(input);
			//pro.getProperty("url");
			}
			
			catch(Exception e)
			{
				e.printStackTrace();
			}	
		}    
     
		@Before
		public void keepScenario(Scenario scenario) {
			this.scenario = scenario;

		}
	    
			
		@After
		public void afterScenario(Scenario scenario) {
			
			BrowserFactory bf = BrowserFactory.getInstance();
			WebDriver d = bf.getDriver();
			
			if (scenario.isFailed()) {
				
				//String screenshotName = scenario.getName().replaceAll(" ", "_");
				String screenshotName = scenario.getName() + "_Fail";
				try {
					//This takes a screenshot from the driver at save it to the specified location
					File sourcePath = ((TakesScreenshot)d).getScreenshotAs(OutputType.FILE);	
					//Building up the destination path for the screenshot to save
					//Also make sure to create a folder 'screenshots' with in the cucumber-report folder
					File destinationPath = new File(System.getProperty("user.dir")+"//FailedScreenShot//"+screenshotName+".png");
					//Copy taken screenshot from source location to destination location
					Files.copy(sourcePath, destinationPath);   
				} catch (IOException e) {
					
					e.printStackTrace();
				} 
			}
			
			else {
				

				
				
		}
				
			
		}  
		
		@AfterStep
		public void afterStep(Scenario scenario) throws IOException {
			BrowserFactory bf = BrowserFactory.getInstance();
			WebDriver d = bf.getDriver();
			ua = new UserActions();
			ua.Wait_Sec();
			scenario.attach(((TakesScreenshot) d).getScreenshotAs(OutputType.BYTES),"image/png","screenshot");		
		}
		
}
	    
	    
	
