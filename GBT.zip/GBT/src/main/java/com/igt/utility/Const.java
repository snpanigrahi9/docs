package com.igt.utility;

public class Const {
	
	
	public final static String PAST_DATE="Past Date";
	

}
