package com.igt.stepDefinition;


import java.io.IOException;
import org.junit.Assert;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.BrowserFactory;
import com.igt.base.TestSetup;
import com.igt.pageObjects.ManageMasterData;
import com.igt.pageObjects.ManageSTQ;
import com.igt.pageObjects.ManageUsers;
import com.igt.pageObjects.Reports;
import com.igt.pageObjects.SkillTaskQueueConfiguration;
import com.igt.pageObjects.AllocateGDSQueueToSitepartition;
import com.igt.pageObjects.AstqAllocation;
import com.igt.pageObjects.Dashboard;
import com.igt.pageObjects.Login;
import com.igt.utility.UserActions;
import com.igt.utility.Util;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class GBTStepDefinition extends TestSetup {

	//UserActions ua = null;
	@Given("GBT Login Screen")
	public void iqd_login_screen() throws Exception {
		try {
			
			BrowserFactory bf = BrowserFactory.getInstance();
			WebDriver d = bf.getDriver();
			Capabilities cap = ((RemoteWebDriver)d).getCapabilities();
			String browserName = cap.getBrowserName();
			ExtentCucumberAdapter.addTestStepLog("Executing automation testcases on"+"  "+browserName);
			log = new Login(d);
			ExtentCucumberAdapter.addTestStepLog(log.GetAppUrl() + "  " + "Application opened successfully");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {
			//ExtentCucumberAdapter.addTestStepLog(
					//"Application is not loaded. See below error message for more details." + "\n" + e.printStackTrace());
			//e.printStackTrace();
			e.printStackTrace();
					Assert.fail();
		}

	}

	@When("enter login credentials such as username password")
	public void enter_login_credentials_such_as_username_password() throws Exception {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			//log.EnterCredentials();
			ExtentCucumberAdapter.addTestStepLog("Login credentials entered successfully");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {
			ExtentCucumberAdapter
					.addTestStepLog("username or password is not present for this application." + "\n" + e.toString());
		}

	}
	


	@When("Clicked on logon button")
	public void clicked_on_logon_button() throws Throwable {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			log.ClickLogOn();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on logon button");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Logon Button is not clicked" + "\n" + e.toString());
			Assert.fail();
		}
	}
	
	
	@When("I click on logout button")
	public void logout()
	{
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		
		try{
		log.ClickLogOut();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on logout button");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Logout Button is not clicked" + "\n" + e.toString());
			Assert.fail();
		}	
	}

	@Then("click on manage master data")
	public void click_on_manage_master_data() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.ClickManageMasterData();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on manageMasterData");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("manageMasterData is not clicked" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@Then("click on task")
	public void click_on_task() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.ClickTask();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on task");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("task is not clicked" + "\n" + e.toString());
			Assert.fail();
		}

	}

	@Then("click on addnew button")
	public void click_on_addnew_button() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.ClickAddNew();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on AddNew");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("AddNew is not clicked" + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I enter taskcode")
	public void i_enter_taskcode_as() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			String tsk = mmd.enterNewTaskCode();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered task code"+" "+tsk);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("task code is not entered" + "\n" + e.toString());
			Assert.fail();
		}

	}

	@When("I enter taskname")
	public void i_enter_taskname_as() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.enterNewTaskName();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered task name");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("task name is not entered" + "\n" + e.toString());
			Assert.fail();
		}
	}

	@Then("I click on submit button")
	public void i_click_on_submit_button() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickSubmit();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on submit button");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("submit button is not clicked" + "\n" + e.toString());
			Assert.fail();

		}

	}
	
	@Then("I click on submit button for Brand")
	public void i_click_on_submit_button_for_brand() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.clickSubmitBrand();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on submit button for brand.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("submit button is not clicked for brand" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click on subtasks")
	public void i_click_on_subtasks() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.ClickSubTasks();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on subtask");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("subtask is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I enter subtaskcode")
	public void i_enter_subtaskcode() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.enterNewSubTaskCode();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered subtask code");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("subtask code is not entered" + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I enter subtaskname")
	public void i_enter_subtaskname() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.enterNewSubTaskName();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered subtask name");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("subtask name is not entered" + "\n" + e.toString());
			Assert.fail();

		}
	}

	@Then("I verify task created successfully message")
	public void i_verify_task_created_successfully_message() {
		String SucMsg;
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			SucMsg = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(SucMsg);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("task is not created successfully" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@Then("I click OK from the popup")
	public void i_click_ok_from_the_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the subtask popup")
	public void i_click_ok_from_the_subtask_popup() {
		
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_SubTask();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	
	
	
	@Then("I click OK from the action popup")
	public void i_click_ok_from_the_action_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_Action();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the subaction popup")
	public void i_click_ok_from_the_subaction_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_SubAction();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the agentskill popup")
	public void i_click_ok_from_the_agentskill_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_AgentSkill();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the languageskill popup")
	public void i_click_ok_from_the_languageskill_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_LanguageSkill();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the brand popup")
	public void i_click_ok_from_the_brand_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_Brand();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the mapping popup")
	public void i_click_ok_from_the_mapping_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_Mapping();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the pos popup")
	public void i_click_ok_from_the_pos_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_Pos();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the pcc popup")
	public void i_click_ok_from_the_pcc_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_Pcc();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@Then("I click OK from the gds popup")
	public void i_click_ok_from_the_gds_popup() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickOkPopup_Gds();
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Popup is not clicked" + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	

	@Then("I verify subtask created successfully message")
	public void i_verify_subtask_created_successfully_message() {
		String SuccMsg;
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			SuccMsg = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(SuccMsg);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Subtask is not created successfully" + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I click on action")
	public void i_click_on_action() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.ClickAction();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on action");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Action is not clicked" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I enter actioncode")
	public void i_enter_actioncode() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.enterNewActionCode();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered action code");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Action code is not entered" + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I enter actionname")
	public void i_enter_actionname() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.enterNewActionName();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered action name");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Action name is not entered" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@Then("I verify action created successfully message")
	public void i_verify_action_created_successfully_message() {
		String SMsg;

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			SMsg = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(SMsg);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Action not created" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click on map Task Subtask and action")
	public void i_click_on_map_task_subtask_and_action() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickMapSubtaskAction();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on Map task Subtask Action button");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Map Task Subtask Action button is not clicked" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select task from the dropdown")
	public void i_select_task_from_the_dropdown() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.selectTask();
			ExtentCucumberAdapter.addTestStepLog("task selected from the dropdown");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("task is not selected from the dropdown" + "\n" + e.toString());
			Assert.fail();

		}

	}

	
	@When("I select task from the dropdown which has already mapped")
	public void selecttask() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.selectTask();
			ExtentCucumberAdapter.addTestStepLog("task selected from the dropdown");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("task is not selected from the dropdown" + "\n" + e.toString());
			Assert.fail();

		}

	}
	
	
	
	@When("I click on Map Task Subtask Action button")
	public void i_click_on_map_task_subtask_action_button() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.clickMapTaskSubtaskAction_Button();
			ExtentCucumberAdapter.addTestStepLog("Map Task Subtask Action button is clicked successfully");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Map Task Subtask Action button is not clicked" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select subtask from the dropdown")
	public void i_select_subtask_from_the_dropdown() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.selectSubTask();
			ExtentCucumberAdapter.addTestStepLog("subtask selected from the dropdown");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("subtask not selected from the dropdown" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select action from the dropdown")
	public void i_select_action_from_the_dropdown() throws InterruptedException {
		
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		mmd.selectAction();
		ExtentCucumberAdapter.addTestStepLog("action selected from the dropdown");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        	ExtentCucumberAdapter.addTestStepLog("action not selected from the dropdown" + "\n" + e.toString());
			Assert.fail();
        	
        }

	}
	
	@When("I select subaction from the dropdown")
	public void i_select_subaction_from_the_dropdown() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		mmd.selectSubAction();
		ExtentCucumberAdapter.addTestStepLog("subaction selected from the dropdown");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
        	e.printStackTrace();
        	ExtentCucumberAdapter.addTestStepLog("subaction not selected from the dropdown" + "\n" + e.toString());
			Assert.fail();
        	
        }
		
	}

	@Then("I verify action mapped to task and subtask successfully")
	public void i_verify_action_mapped_to_task_and_subtask_successfully() {

		String SM;
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		
		try {
			SM = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(SM);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Action not mapped to task and subtask" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click on POS")
	public void i_click_on_pos() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickPOS();
			ExtentCucumberAdapter.addTestStepLog("Clicked on POS");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("POS is not clicked" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I enter POS code and POS name")
	public void i_enter_pos_code_as_and_pos_name_as() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.enterPosCode();
			mmd.enterPosName();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered POS code and POS name");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("POS code and POS name is not entered" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select country,brand,currency")
	public void i_select_country_as_brand_as_currency_as() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.selectCountry();
			mmd.selectBrand();
			mmd.selectCurrency();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected country,brand and currency");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("country or brand or currency is not selected" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select LangId and POSIATACode")
	public void i_select_langid_and_posiata_code() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.selectLangId();
			mmd.addIataCode();
			ExtentCucumberAdapter.addTestStepLog("langId selected and IATA code entered");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter
					.addTestStepLog("langId is not selected or IATA code is not entered" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@Then("I verify POS created successfully")
	public void i_verify_pos_created_successfully() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			String vpos;
			vpos = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(vpos);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("POS is not created successfully" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click on PccConfiguration")
	public void i_click_on_pcc_configuration() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			mmd.clickPccConfiguration();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on PCC Configuration");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("PCC Configuration is not clicked" + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select POS and select GDS")
	public void i_select_pos_and_select_gds() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.selectPOSAndGDS();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected POS and GDS");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("POS and GDS is not selected" + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I enter pcc")
	public void i_enter_pcc() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd.enterPCC();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered PCC");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("PCC not entered." + "\n" + e.toString());
			Assert.fail();

		}
	}

	@Then("I verify PCC created successfully")
	public void i_verify_pcc_created_successfully() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			String psuc;
			psuc = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(psuc);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("PCC not created successfully." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click on manage STQ")
	public void i_click_on_manage_stq() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms = new ManageSTQ(d);
			ms.clickManageSTQ();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on manage STQ");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Manage STQ is not clicked." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click on GDS Queue Configuration")
	public void i_click_on_gds_queue_configuration() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.clickGDSQueueConfiguration();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on GDS Queue Configuration");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("GDS Queue Configuration is not clicked." + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("click on addnew")
	public void click_on_addnew() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.AddNew_Click();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on addnew");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Addnew is not clicked." + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I enter GDS queue name")
	public void i_enter_gds_queue_name() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.enterGDSQueueName();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered GDS queue name.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to enter GDS queue." + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I select GDS type")
	public void i_select_gds_type_as() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.selectGDS();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected GDS type.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select GDS type." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select POS and POS IATA Number and Pcc")
	public void i_select_pos_as_and_pos_iata_number_as_and_pcc_as() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.selectPOS();
			ms.selectPOSIata();
			ms.selectPcc();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected POS,POSIata,PCC");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select POS,POSIata,PCC." + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I select Target THT Hour and Minute")
	public void i_select_target_tht_hour_and_minute() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.selectTargetTHT();

			ExtentCucumberAdapter.addTestStepLog("Successfully selected THT hour and THT minute");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		} catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select THT hour and THT minute." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select Task and Subtask")
	public void i_select_task_and_subtask() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.selectTaskAndSubTask();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected task and subtask");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select task and subtask." + "\n" + e.toString());
			Assert.fail();
		}

	}

	@When("I select Skill")
	public void i_select_skill() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.selectSkill();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected skill");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select skill." + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I select Duration hour and minute")
	public void i_select_duration_hour_and_minute() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.selectDuration();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected Duration hour and Duration minute");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select skill." + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I select timezone")
	public void i_select_timezone() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.selectTimeZone();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected timezone");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select timezone." + "\n" + e.toString());
			Assert.fail();
		}
	}
	
	
	
	@When("I click on Test Connection button if available")
	public void i_click_on_test_connection_button_if_available() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		ms.clickTestConnection();
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on Test Connection." + "\n" + e.getMessage());
			Assert.fail();
		}
	}

	@When("I click on submit")
	public void i_click_on_submit() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			ms.submit();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on submit");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to click on submit." + "\n" + e.toString());
			Assert.fail();

		}

	}
	
	
	@Then("I verify GDS Queue created successfully message")
	public void i_verify_gds_queue_created_successfully_message() {
	    
		String SucMsg;
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mmd = new ManageMasterData(d);
			SucMsg = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(SucMsg);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("GDS Queue is not created successfully" + "\n" + e.toString());
			Assert.fail();
		}	
	}

	@When("I click on reporting")
	public void i_click_on_reporting() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		rep = new Reports(d);
		rep.clickReporting();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on reporting.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on reporting." + "\n" + e.getMessage());
			Assert.fail();
		}
	}

	@When("I click on agent report")
	public void i_click_on_agent_report() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		rep.clickAgentReport();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on agent report.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on agent report." + "\n" + e.getMessage());
			Assert.fail();
		}	
	}

	@When("I select site, site partition, datefilter, startDate, endDate")
	public void i_select_site_site_partition_date_filter_start_date_end_date() throws IOException{

		rep.selectSite();
		rep.selectSitePartions();
		rep.selectDateType();

	}

	@Then("I click on download button")
	public void i_click_on_download_button() {

		rep.clickDownload();

	}

	@When("I click on agent performance report")
	public void i_click_on_agent_performance_report() {

		rep.clickAgentPerformance();

	}

	@When("I select site, site partition, pos, datefilter, startDate, endDate")
	public void i_select_site_site_partition_pos_datefilter_start_date_end_date() throws IOException

	{
		rep.selectSite_AgentPerformance();
		rep.selectSitePartions_AgentPerformance();
		rep.select_pos();
		//
		rep.selectDateType_AgentPerformance();
	}

	@Then("I click on download")
	public void i_click_on_download() {

		rep.download();
		
//
	}

	@When("I click on work itme details report")
	public void i_click_on_work_itme_details_report() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.click_WorkItemDetails();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on WorkItemDetails.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to click on WorkItemDetails." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select OnDateType, site, sitePartition, workItemType, startDate, endDate, datefilter")
	public void i_select_ondatetype_site_sitepartition_workitemtype_startdate_enddate_datefilter() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectOnDateType();
			rep.selectSite_WorkItemDetails();
			rep.selectSitePartions_WorkItemDetails();
			rep.selectWorkItemType();
			rep.selectDateByDateType_WorkItemDetails();
			ExtentCucumberAdapter.addTestStepLog(
					"Successfully selected OndateType or site or sitepartition or workitemtype or startdate or enddate.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog(
					"Unable to select OndateType or site or sitepartition or workitemtype or startdate or enddate."
							+ "\n" + e.toString());
			Assert.fail();
		}

	}

	@When("I select task")
	public void i_select_task() throws InterruptedException {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectTask();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected task.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select task." + "\n" + e.toString());
			Assert.fail();
		}
	}
	
	@When("I select subtask")
	public void i_select_subtask() throws InterruptedException {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectSubTask();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected subtask.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select subtask." + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I click on SLA Compliance report")
	public void i_click_on_sla_compliance_report() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.click_SLACompliance();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on SLA Compliance.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("SLA Compliance report is not clicked." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select site, sitepartition, datefilter, startDate, endDate")
	public void i_select_vendor_vendorpartition_datefilter_startdate_enddate() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectSite_SLACompliance();
			rep.selectSitePartions_SLACompliance();
			rep.selectDateType_SLACompliance();
			ExtentCucumberAdapter
					.addTestStepLog("Successfully selected vendor,vendor partition,datefilter,startdate,enddate.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog(
					"Unable to select vendor,vendor partition,datefilter,startdate,enddate." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click task or STQ radio button")
	public void i_click_task_or_stq_radio_button() throws InterruptedException {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.clickRadioButton();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected task or STQ radio button.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		} catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select task or STQ radio button." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select task or STQ from the dropdown")
	public void i_select_task_or_stq_from_the_dropdown() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectValueFromDropdown();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected task or STQ.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			ExtentCucumberAdapter
					.addTestStepLog("Unable to select task or STQ from the dropdown." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select subtask or ASTQ from the checkbox")
	public void i_select_subtask_or_astq_from_the_checkbox() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectValueFromCheckbox();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected subtask or ASTQ from the checkbox.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		} catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter
					.addTestStepLog("Unable to select subtask or ASTQ from the checkbox." + "\n" + e.toString());
			Assert.fail();

		}
	}

	@When("I click on SingleWorkItem report")
	public void i_click_on_single_work_item_report() {
		
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.click_SingleWorkItem();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on singleWorkItem.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to click on singleWorkItem." + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I enter WorkItemId and PNRRecordlocator")
	public void i_enter_work_item_id_as_and_pnr_recordlocator_as() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.enterWorkItemIdAndPnr();
			ExtentCucumberAdapter.addTestStepLog("Successfully entered WorkItemId and PNRRecordLocator.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		}

		catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter
					.addTestStepLog("Unable to enter WorkItemId and PNRRecordLocator." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I click on escalated work item report")
	public void i_click_on_escalated_work_item_report() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.click_EscalatedWorkItem();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on escalated work item report.");
			Util.TakeScreenShot(d, System.currentTimeMillis());

		} catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter
					.addTestStepLog("Unable to click on escalated work item report." + "\n" + e.toString());
			Assert.fail();

		}

	}

	@When("I select site, sitepartition, startDate, endDate")
	public void i_select_site_sitepartition_startdate_enddate() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectSite_EscalatedWorkItem();
			rep.selectSitePartions_EscalatedWorkItem();
			rep.selectDateByDateType();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected site, sirepartition,startdate,enddate");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter
					.addTestStepLog("Unable to select site, sirepartition,startdate,enddate." + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I select STQ from the dropdown")
	public void i_select_stq_from_the_dropdown() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectSTQ();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected STQ from the dropdown");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to select STQ from the dropdown." + "\n" + e.toString());
			Assert.fail();
		}
	}

	@When("I select ASTQ from the checkbox")
	public void i_select_astq_from_the_checkbox() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			rep.selectValueFromCheckboxes();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected ASTQ from the checkbox");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to select ASTQ from the checkbox." + "\n" + e.toString());
			Assert.fail();
		}
	}
	
	@When("I click on SubAction")
	public void i_click_on_sub_action() {

		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd = new ManageMasterData(d);
		mmd.click_SubAction();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on SubAction.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to click on SubAction." + "\n" + e.toString());
			Assert.fail();
		}
	}
	
	
	@When("I enter subaction code")
	public void i_enter_subaction_code() {
	   
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterNewSubActionCode();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered subaction code.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to enter subaction code." + "\n" + e.toString());
			Assert.fail();
		}
	}
	@When("I enter subaction name")
	public void i_enter_subaction_name() {
	   
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterNewSubActionName();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered subaction name.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to enter subaction name." + "\n" + e.toString());
			Assert.fail();

		}
		
	}
	@Then("I verify subaction created successfully message")
	public void i_verify_subaction_created_successfully_message() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		String success = mmd.getSuccessMsg();
		ExtentCucumberAdapter.addTestStepLog(success);
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		
		catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to verify subaction created successfully." + "\n" + e.toString());
			Assert.fail();

		}
		
	}
	
	@When("I click on agentskills from the menu")
	public void i_click_on_agentskills_from_the_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.clickAgentSkills();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on AgentSkills from the menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		
		catch(Exception e)
		
		{
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to click AgentSkills from the menu." + "\n" + e.toString());
			Assert.fail();
			
		}
		
		
	}
	@When("I enter agentskillcode")
	public void i_enter_agentskillcode() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterAgentSkillCode();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered agentSkillCode.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to enter agentSkillCode." + "\n" + e.toString());
			Assert.fail();
			
		}	
	}
	@When("I enter agentskillname")
	public void i_enter_agentskillname_as() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterAgentSkillName();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered agentSkillName.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to enter agentSkillName." + "\n" + e.toString());
			Assert.fail();
			
		}		
		
	}
	@Then("I verify agent skill created successfully message")
	public void i_verify_agent_skill_created_successfully_message() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		String success = mmd.getSuccessMsg();
		ExtentCucumberAdapter.addTestStepLog(success);
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		
		catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to verify agentskills created successfully." + "\n" + e.toString());
			Assert.fail();

		}
	}
	
	@When("I click on languageskills from the menu")
	public void i_click_on_languageskills_from_the_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd = new ManageMasterData(d);
		mmd.clickLanguageSkills();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on languageSkills from the menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to click on languageSkills from the menu." + "\n" + e.toString());
			Assert.fail();
		}
	}
	@When("I enter languagecode")
	public void i_enter_languagecode() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterLanguageCode();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered language code.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to enter language code." + "\n" + e.toString());
			Assert.fail();
		}		
	}
	@When("I enter language name")
	public void i_enter_language_name_as() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterLanguageName();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered language name.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to enter language name." + "\n" + e.toString());
			Assert.fail();
		}
	}
	
	@Then("I verify language skills created successfully message")
	public void i_verify_language_skills_created_successfully_message() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
			try{
			String success = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(success);
			Util.TakeScreenShot(d, System.currentTimeMillis());
			}
			catch (Exception e) {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to verify language skills created successfully." + "\n" + e.toString());
				Assert.fail();
			}
	}
	
	
	@When("I click on dashboard from the menu")
	public void i_click_on_dashboard_from_the_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		db = new Dashboard(d);
		try{
		db.click_Dashboard();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked dashboard from the menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to click on dashboard." + "\n" + e.toString());
			Assert.fail();
		}
	}
	
	@When("I click on AgentAndWorkItem dashboard")
	public void i_click_on_agent_and_work_item_dashboard() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.click_agentworkitem();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on AgentAndWorkItem dashboard.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to click on AgentAndWorkItem dashboard." + "\n" + e.toString());
			Assert.fail();
		}	
	}
	
	@When("I select site, sitepartition, duration")
	public void i_select_site_as_sitepartition_as_duration_as() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.select_Site_Sitepartitions_Duration();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected site,sitepartition, duration.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
	   }
	   catch(Exception e)
	   {
			e.printStackTrace();
			ExtentCucumberAdapter.addTestStepLog("Unable to select site,sitepartition,duration." + "\n" + e.toString());
			Assert.fail();
	   }
	}
	@When("I select STQ")
	public void i_select_stq() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.select_Stq();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected stq.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to select stq." + "\n" + e.toString());
				Assert.fail();
		   }
		
	}
	@Then("I click on search button")
	public void i_click_on_search_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.click_Search();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on search button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to search." + "\n" + e.toString());
				Assert.fail();
		   }
		
	}	
	
	@When("I click on STQ\\/ASTQ dashboard")
	public void i_click_on_stq_astq_dashboard() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.click_StqAstq();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on STQ/ASTQ dashboard.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to click on STQ/ASTQ dashboard." + "\n" + e.toString());
				Assert.fail();
		   }	
	}
	
	@Then("I click on the expand arrow of 'New ITEMS'")
	public void i_click_on_the_expand_arrow_of() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.click_ExpandArrow();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on expand arrow.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
	    }
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to click on expand arrow." + "\n" + e.toString());
				Assert.fail();
		   }
			
	}
	@Then("I verify 'Work Item Status' dialog box")
	public void i_verify_dialog_box() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.verifyExpandDialog();
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to verify expand arrow dialog." + "\n" + e.toString());
				Assert.fail();
		   }
	}
	
	@When("I click on STQ dropdown")
	public void i_click_on_stq_dropdown() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
       db.expandAllSTQ();
       ExtentCucumberAdapter.addTestStepLog("Successfully expanded all stqs.");
       Util.TakeScreenShot(d, System.currentTimeMillis());
       
		}
		
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to expand all stqs." + "\n" + e.toString());
				Assert.fail();
		   }
		
	}
	@Then("I verify if the count of COMPLETED WORK ITEMS, NEW WORK ITEMS, SLA BREACHED \\(NEW), AGENTS ASSIGNED, AGENTS WORKING, AGENTS ON BREAK, AGENTS IDLE is displaying as expected")
	public void i_verify_if_the_count_of_completed_work_items_new_work_items_sla_breached_new_agents_assigned_agents_working_agents_on_break_agents_idle_is_displaying_as_expected() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		db.click_Search();
		//ua = new UserActions();
		//ua.Wait_Sec();
		db.verifyCompletedWorkItemsCount();
        db.verifyNewWorkItemsCount();
        db.verifySLABreachedCount();
        db.verifyAgentsAssignedCount();
        db.verifyAgentsWorkingCount();
        db.verifyAgentsOnBreakCount();
        db.verifyAgentsIdleCount();
        ExtentCucumberAdapter.addTestStepLog("Successfully verified the count of COMPLETED WORK ITEMS, NEW WORK ITEMS, SLA BREACHED, AGENTS ASSIGNED, AGENTS WORKING, AGENTS ON BREAK, AGENTS IDLE .");
        Util.TakeScreenShot(d, System.currentTimeMillis());
        
		}
		
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to verify the count of COMPLETED WORK ITEMS, NEW WORK ITEMS, SLA BREACHED, AGENTS ASSIGNED, AGENTS WORKING, AGENTS ON BREAK, AGENTS IDLE ." + "\n" + e.toString());
				Assert.fail();
		   }
	}
	
	@When("I add all the agents from the data sheet")
	public void add_all_the_agents_from_the_data_sheet() throws IOException, InterruptedException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mu = new ManageUsers(d);
		mu.manageAgent();
		ExtentCucumberAdapter.addTestStepLog("Successfully added all the agents data from the excel sheet.");
		Util.TakeScreenShot(d, System.currentTimeMillis());

		}
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to add agents data from the excel." + "\n" + e.toString());
				Assert.fail();
		   }
	}
	
	
	@When("I add all the supervisor from the data sheet")
	public void i_add_all_the_supervisor_from_the_data_sheet() throws IOException, InterruptedException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		mu = new ManageUsers(d);
		mu.manageSupervisor();
		
		
		
		
		
	}

	
	@When("I click on brand")
	public void i_click_on_brand() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd = new ManageMasterData(d);	
		mmd.ClickBrand();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on brand from the menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to click on brand from the menu." + "\n" + e.toString());
				Assert.fail();
		   }
	}
	@When("I enter brand code")
	public void i_enter_brand_code() throws IOException {
	
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterBrandCode();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered brand code.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to enter brand code." + "\n" + e.toString());
				Assert.fail();
		   }
	}
	@When("I enter brand name")
	public void i_enter_brand_name() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mmd.enterBrandName();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered brand name.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		   catch(Exception e)
		   {
				e.printStackTrace();
				ExtentCucumberAdapter.addTestStepLog("Unable to enter brand name." + "\n" + e.toString());
				Assert.fail();
		   }	
	}
	@Then("I verify brand created successfully message")
	public void i_verify_brand_created_successfully_message() {
	
		String SMsg;
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			SMsg = mmd.getSuccessMsg();
			ExtentCucumberAdapter.addTestStepLog(SMsg);
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Brand is not created successfully." + "\n" + e.toString());
			Assert.fail();

		}		
	}
	
	@When("I click on countries")
	public void i_click_on_countries() {
	  
		
		
		
		
	}
	@When("I enter region name")
	public void i_enter_region_name() {
	   
		
		
		
		
	}
	@When("I enter country code")
	public void i_enter_country_code() {
	
		
		
		
	}
	@When("I enter country name")
	public void i_enter_country_name() {
	  
		
		
		
	}
	
	@And("I click on Allocate GDS Queues to sitepartition")
	public void I_click_on_Allocate_GDS_Queues_to_sitepartition() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		gs = new AllocateGDSQueueToSitepartition(d);
		gs.clickAllocateGDSQueueToSitePartition();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on AllocateGDSQueuesToSitepartition");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to click on AllocateGDSQueuesToSitepartition." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select site and sitepartition")
	public void I_select_site_and_sitepartition() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		gs.selectSiteAndSitePartition();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected site and sitepartition.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select site or sitepartition." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@And("I click on search")
	public void I_click_on_search() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		gs.clickSearchButton();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on search button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to click on search button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@And("I select new gds queues to map")
	public void I_select_new_gds_queues_to_map() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		gs.mapNewGDSQueues();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected gds queue to map.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to select gds queue to map." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on MapSelectedGDSQueue button")
	public void I_click_on_MapSelectedGDSQueue_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		gs.mapSelectedGDSQueue();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on MapSelectedGDSQueue button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to click on MapSelectedGDSQueue button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I verify the mapped gds queue under GDSQueueCurrentlyMapped section")
	public void I_verify_the_mapped_gds_queue_under_GDSQueueCurrentlyMapped_section() {
	    
		
		
		
	}
	@And("I click on the delete button under GDSQueueCurrentlyMapped section")
	public void I_click_on_the_delete_button_under_GDSQueueCurrentlyMapped_section() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		gs.deleteGDSQueueCurrentlyMapped();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on the delete button under GDSQueueCurrentlyMapped section.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {

			ExtentCucumberAdapter.addTestStepLog("Unable to click on the delete button under GDSQueueCurrentlyMapped section." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click confirm from the delete dialog")
	public void I_click_confirm_from_the_delete_dialog() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		gs.confirmDelete();
		//ExtentCucumberAdapter.addTestStepLog("Successfully clicked on confirm from the delete dialog.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on confirm from the delete dialog." + "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	
	@And("I click on Astq Allocation")
	public void I_click_on_Astq_Allocation() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		aa = new AstqAllocation(d);
		aa.clickAstqAllocation();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on Astq allocation.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
        }
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on Astq Allocation." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select site,site partition,center")
	public void I_select_site_sitepartition_center() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			aa.Select_site_sitepartition_center();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected site,sitepartition,center.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} 
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select site,sitepartition,center." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select agent skills")
	public void I_select_agent_skills() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			aa.selectAgentSkills();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected agent skills.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} 
		catch (Exception e) {
			
			ExtentCucumberAdapter.addTestStepLog("Unable to select agent skills." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on search icon")
	public void I_click_on_search_icon() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.searchData();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on search.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on search." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select agent radio button")
	public void I_select_agent_radio_button() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.selectAgent();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected agent.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select agent." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on ManageAssignedAstqs button")
	public void I_click_on_ManageAssignedAstqs_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.clickManageAssignedAstqs();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on ManageAssignedAstqs button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on ManageAssignedAstqs button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I hit AddNew button")
	public void I_hit_AddNew_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.addNew_click();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on addnew.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on addnew." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select Astq to assign")
	public void I_select_Astq_to_assign() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.selectAstq();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected astq to assign.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select astq to assign." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I hit submit button")
	public void I_hit_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.submit();
		ExtentCucumberAdapter.addTestStepLog("Successfully hit submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to hit submit button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I delete assigned astqs")
	public void I_delete_assigned_astqs() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.deleteAssignedAstq();
		ExtentCucumberAdapter.addTestStepLog("Successfully deleted assigned astqs.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to delete assigned astqs." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on AssignASTQToAgents Tab")
	public void I_click_on_AssignASTQToAgents_Tab() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.clickAssignAstqToAgents_Tab();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on assignAstqToAgents tab.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on assignAstqToAgents tab." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select site,site partition,stq")
	public void selectSite_Sitepartition_stq() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.select_site_sitepartition_stq();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected site,site partition,stq.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select site,site partition,stq." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select astq radio button")
	public void I_select_astq_radio_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.selectAstq_AssignAstqToAgentsTab();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected Astq.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select Astq." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on ManageAssignedAgents button")
	public void I_click_on_ManageAssignedAgents_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.clickManageAssignedAgents();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on ManageAssignedAgents.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on ManageAssignedAgents." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select Agent to assign")
	public void I_select_Agent_to_assign() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.selectAgent_AssignAstqToAgentsTab();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected agent to assign.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select agent to assign." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on MultiAssignASTQsToAgents Tab")
	public void I_click_on_MultiAssignASTQsToAgents_Tab() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.clickMultiAssignAstqsToAgents_Tab();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on MultiAssignASTQsToAgents tab.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on MultiAssignASTQsToAgents tab." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on NextItem")
	public void I_click_on_NextItem() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.clickNextItem();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on next item.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on next item." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I hit submit")
	public void I_hit_submit() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.click_Submit();
		ExtentCucumberAdapter.addTestStepLog("Successfully hit submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to hit submit button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I hit AddNew")
	public void I_hit_AddNew() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		aa.addNew();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on addnew.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on addnew." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on SkillTaskQueueConfiguration")
	public void I_click_on_SkillTaskQueueConfiguration() {
		
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		stqc = new SkillTaskQueueConfiguration(d);
		try{
		stqc.clickSkillTaskQueueConfiguration();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on skillTaskQueueConfiguration.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on skillTaskQueueConfiguration." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on add new stq or astq")
	public void I_click_on_add_new_stq_or_astq() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		stqc.addNewStq();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on AddNew.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on AddNew." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I enter stq code")
	public void I_enter_stq_code() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		stqc.enterStqCode();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered stq code.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to enter stq code." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I enter stq desc")
	public void I_enter_stq_desc() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		stqc.enterStqDesc();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered stq desc.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to enter stq desc." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select both site and sitepartition")
	public void I_select_both_site_and_sitepartition() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		stqc.selectSiteName();
		stqc.selectSitePartitionName();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected site and sitepartition.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select site and sitepartition." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click OK for stq created successfully")
	public void I_click_OK_for_stq_created_successfully() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
	     stqc.stqCreatedOk();
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on Ok." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	
	@And("I click on manage ASTQ")
	public void I_click_on_manage_ASTQ() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
	   stqc.clickManageAstqButton();
			
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on manage ASTQ.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on manage ASTQ." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I enter astq code")
	public void I_enter_astq_code() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.enterAstqCode();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered astq code.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to enter astq code." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I enter astq desc")
	public void I_enter_astq_desc() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.enterAstqDesc();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered astq description.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to enter astq description." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select serving order")
	public void I_select_serving_order() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
	     stqc.selectServingOrder();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected the serving order.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select the serving order." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click OK for astq created successfully")
	public void I_click_OK_for_astq_created_successfully() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
	     stqc.astqCreatedOk();
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on Ok." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	
	@And("I click on plus icon to map new gds queue")
	public void I_click_on_plus_icon() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.mapNewGdsQueue();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on map new gds queue icon.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on map new gds queue icon." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select gds queue to map")
	public void I_select_gds_queue_to_map() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.selectGDSQueueToMap();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected gds queue to map.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select gds queue to map." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click OK from the dialog")
	public void I_click_OK_from_the_dialog() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.okMapping();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked ok from the dialog.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click ok from the dialog." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on uploadWorkItems icon")
	public void I_click_on_uploadWorkItems_icon() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.clickUploadWorkItem();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on uploadWorkItems.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on uploadWorkItems." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I select GDS queue name from the dropdown")
	public void I_select_GDS_queue_name_from_the_dropdown() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.selectGdsQueueName();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected gds queue name from the dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select gds queue name from the dropdown." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I browser the csv file to upload")
	public void I_browser_the_csv_file_to_upload() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.fileToUpload();
		 ExtentCucumberAdapter.addTestStepLog("Successfully browsed file to upload.");
		 Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to browse file to upload." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on upload button")
	public void I_click_on_upload_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.clickUpload();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on upload button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on upload button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on back button")
	public void I_click_on_back_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.clickBack();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on back button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on back button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on ViewMappedGDSQueue icon")
	public void I_click_on_ViewMappedGDSQueue_icon() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.viewMappedGdsQueue();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on viewMappedGDSQueue.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on viewMappedGDSQueue." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I delete the gds queue mapped")
	public void I_delete_the_gds_queue_mapped() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.deleteQueue();	
		ExtentCucumberAdapter.addTestStepLog("Successfully deleted gds queue mapped.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to delete gds queue mapped." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on close")
	public void I_click_on_close() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
			stqc.clickClose();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on close button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to click on close button." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
}
	

