package com.igt.stepDefinition;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.BrowserFactory;
import com.igt.base.TestSetup;
import com.igt.pageObjects.AgentDashboard;
import com.igt.pageObjects.AgentLogin;
import com.igt.pageObjects.AutoTask;
import com.igt.pageObjects.Breaks;
import com.igt.pageObjects.InboundCall;
import com.igt.pageObjects.ManualTask;
import com.igt.pageObjects.ManualWorkItem;
import com.igt.pageObjects.TaskBasket;
import com.igt.pageObjects.UserProfile;
import com.igt.utility.Util;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class AgentStepDefinition extends TestSetup {
	
	
	
	@When("Agent enter login credentials such as username password")
	public void agent_enter_login_credentials_such_as_username_password() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		
		try {
			alog = new AgentLogin(d);
			alog.EnterCredentials();
			ExtentCucumberAdapter.addTestStepLog("Agent Login credentials entered successfully");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter
					.addTestStepLog("Agent username or password is not present for this application." + "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	
	@When("I click on agent logout button")
	public void logout()
	{
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		alog.ClickAgentLogOut();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on agent logout button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Agent Logout Button is not clicked" + "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@When("I verify AutoTask tile of the page")
	public void i_verify_auto_task_tile_of_the_page() {
	
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb = new AgentDashboard(d);
		adb.verifyAutoTaskTile();
		ExtentCucumberAdapter.addTestStepLog("AutoTask is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("AutoTask is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();	
		}		
	}
	@When("I verify ManualTask tile of the page")
	public void i_verify_manual_task_tile_of_the_page() {
	 
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyManualTaskTile();
		ExtentCucumberAdapter.addTestStepLog("ManualTask is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("ManualTask is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
			
		}
	}
	@When("I verify Create Manual Workitem tile of the page")
	public void i_verify_create_manual_workitem_tile_of_the_page() {
	   
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyCreateManualWorkitemTile();
		ExtentCucumberAdapter.addTestStepLog("Create Manual Workitem is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Create Manual Workitem is not present in the agent home page." + "\n" + e.getMessage());	
			Assert.fail();
		}
		
	}
	@When("I verify Spl. Project Initiated tile of the page")
	public void i_verify_spl_project_initiated_tile_of_the_page() {
	   
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifysplProjectInitiatedTile();
		ExtentCucumberAdapter.addTestStepLog("Spl. Project Initiated is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Spl. Project Initiated is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I verify Training Initiated tile of the page")
	public void i_verify_training_initiated_tile_of_the_page() {
	
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyTrainingInitiatedTile();
		ExtentCucumberAdapter.addTestStepLog("Training Initiated is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Training Initiated is not present in the agent home page." + "\n" + e.getMessage());	
			Assert.fail();
		}
		
	}
	@When("I verify Meeting tile of the page")
	public void i_verify_meeting_tile_of_the_page() {
	   
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyMeetingTile();
		ExtentCucumberAdapter.addTestStepLog("Meeting is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Meeting is not present in the agent home page." + "\n" + e.getMessage());	
			Assert.fail();
		}
		
	}
	@When("I verify Coaching tile of the page")
	public void i_verify_coaching_tile_of_the_page() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyCoachingTile();
		ExtentCucumberAdapter.addTestStepLog("Coaching is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Coaching is not present in the agent home page." + "\n" + e.getMessage());	
			Assert.fail();
		}
	}
	@When("I verify Schedule Break tile of the page")
	public void i_verify_schedule_break_tile_of_the_page() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyScheduleBreakTile();
		ExtentCucumberAdapter.addTestStepLog("Schedule Break is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Schedule Break is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("I verify Unschedule Break tile of the page")
	public void i_verify_unschedule_break_tile_of_the_page() {
	   
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyUnScheduleBreakTile();
		ExtentCucumberAdapter.addTestStepLog("Unschedule Break is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}	
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unschedule Break is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("I verify Not Ready Res Support tile of the page")
	public void i_verify_not_ready_res_support_tile_of_the_page() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
	    try{
		adb.verifyNotReadyResSupportTile();
		ExtentCucumberAdapter.addTestStepLog("NotReadyResSupport is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
	    }
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("NotReadyResSupport is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
		}    
		
	}
	@When("I verify Not Ready PC Problem tile of the page")
	public void i_verify_not_ready_pc_problem_tile_of_the_page() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyNotReadyPCProblemTile();
		ExtentCucumberAdapter.addTestStepLog("NotReadyPCProblem is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("NotReadyPCProblem is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
		}  	
		
	}
	@When("I verify Not Ready Other Department tile of the page")
	public void i_verify_not_ready_other_department_tile_of_the_page() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
	    adb.verifyNotReadyOtherDepartmentTile();
		ExtentCucumberAdapter.addTestStepLog("NotReadyOtherDepartment is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("NotReadyOtherDepartment is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
		}  		
	}
	@When("I verify Lunch Break tile of the page")
	public void i_verify_lunch_break_tile_of_the_page() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyLunchBreakTile();
		ExtentCucumberAdapter.addTestStepLog("Lunch Break is present in the agent home page.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Lunch Break is not present in the agent home page." + "\n" + e.getMessage());
			Assert.fail();
		}  	
	}	
	
	@When("I verify last twenty hours items pick")
	public void i_verify_last_hours_items_pick() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		String totalitemspick = adb.getItemsPick();
		ExtentCucumberAdapter.addTestStepLog("Last 24 hours items pick is"+"  "+totalitemspick);
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to get Last 24 hours items pick." + "\n" + e.getMessage());
			Assert.fail();
		}  
		
		
		
	}
	@When("I verify last twenty hours items complete")
	public void i_verify_last_hours_items_complete() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		String totalitemscomplete = adb.getItemsComplete();
		ExtentCucumberAdapter.addTestStepLog("Last 24 hours items complete is"+"  "+totalitemscomplete);
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to get Last 24 hours items complete." + "\n" + e.getMessage());
			Assert.fail();
		}  
	}
	@When("I verify last twenty hours items escalate")
	public void i_verify_last_hours_items_escalate() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		String totalitemsescalate = adb.getItemsEscalate();
		ExtentCucumberAdapter.addTestStepLog("Last 24 hours items escalate is"+"  "+totalitemsescalate);
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to get Last 24 hours items escalate." + "\n" + e.getMessage());
			Assert.fail();
		}  
	}
	@When("I verify last twenty hours items delay")
	public void i_verify_last_hours_items_delay() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		String totalitemsdelay = adb.getItemsDelay();
		ExtentCucumberAdapter.addTestStepLog("Last 24 hours items delay is"+"  "+totalitemsdelay);
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to get Last 24 hours items delay." + "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@When("I click on MyProfile from the agent dashboard screen")
	public void i_click_on_my_profile_from_the_agent_dashboard_screen() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.clickMyDashboard();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on my profile.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on my profile." + "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("I verify Mydashboard menu")
	public void i_verify_mydashboard_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyMyDashboardMenu();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified my dashboard menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to verify my dashboard menu." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("I verify Myprofile menu")
	public void i_verify_myprofile_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyMyprofileMenu();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified my profile menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to verify my profile menu." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("I verify Changepassword menu")
	public void i_verify_changepassword_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyChangePasswordMenu();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified change password menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to verify change password menu." + "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I verify logout menu")
	public void i_verify_logout_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		adb.verifyLogoutMenu();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified logout menu.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to verify logout menu." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("I click on agent autotask tile from the dashboard screen")
	public void i_click_on_agent_autotask_tile_from_the_dashboard_screen() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at = new AutoTask(d);
		at.clickAutoTask();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on autotask from the dashboard screen.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click autotask from the dashboard screen." + "\n" + e.getMessage());
			Assert.fail();
		} 			
	}
	@When("I select item from filter and general info dropdown")
	public void i_select_item_from_filter_and_general_info_dropdown() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.selectFilter();
		at.selectGeneralInfo();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected value from filter and generalInfo dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select value from filter and generalInfo dropdown." + "\n" + e.getMessage());
			Assert.fail();
		} 		
	}
	@When("I click on diagnostics")
	public void i_click_on_diagnostics() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			at.clickDiagnostics();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected diagnostics.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} 
		catch (Exception e) {
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select diagnostics." + "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I click on actions")
	public void i_click_on_actions() {
	   
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			at.clickActions();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected actions.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} 
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select actions." + "\n" + e.getMessage());
			Assert.fail();
		} 
		
	}
	@Then("I click on complete work item")
	public void i_click_on_complete_work_item() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickCompleteWorkItem();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on complete work item button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on complete work item button." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	
	@When("I click on pause from the top menu")
	public void i_click_on_pause_from_the_top_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickPause();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on pause.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on pause." + "\n" + e.getMessage());
			Assert.fail();
		} 
		
	}
	@When("I click on submit from the dialog")
	public void i_click_on_submit_from_the_dialog() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickSubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on submit button from the dialog.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on submit button from the dialog." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	
	@When("I click on delay from the top menu")
	public void i_click_on_delay_from_the_top_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickDelay();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on delay.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on delay." + "\n" + e.getMessage());
			Assert.fail();
		} 
		
	}
	@When("I select delay date time")
	public void i_select_delay_date_time() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.selectDelayDateTime();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected delay date and time.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select delay date and time." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	@When("I enter delay remarks")
	public void i_enter_delay_remarks() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.enterDelayRemarks();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered delay remarks.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to enter delay remarks." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	@Then("click on submit button")
	public void click_on_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickDelaySubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on delay submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click delay submit button." + "\n" + e.getMessage());
			Assert.fail();
		} 	
	}
	
	@Then("click on close button")
	public void click_on_close_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickClose();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on close button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on close button."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("I click on breaks from the top menu")
	public void i_click_on_breaks_from_the_top_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickBreaks();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on breaks.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on breaks."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("I select break type")
	public void i_select_break_type() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			at.selectBreakType();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected break type.");
			Util.TakeScreenShot(d, System.currentTimeMillis());	
		} 
		catch (Exception e) {
			
			ExtentCucumberAdapter.addTestStepLog("Unable to select break type."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@Then("click on breaks submit button")
	public void click_on_breaks_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickBreaksSubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on breaks submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on breaks submit button."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@Then("click on resume button")
	public void click_on_resume_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickResume();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on resume button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on resume button."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@When("I click on escalate from the top menu")
	public void i_click_on_escalate_from_the_top_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver(); 
		try{
	    at.clickEscalate();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on escalate.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on escalate."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("I enter escalate remarks")
	public void i_enter_escalate_remarks() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.enterEscalateRemark();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered escalate remarks.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to enter escalate remarks."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@Then("click on escalate submit button")
	public void click_on_escalate_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		at.clickEscalateSubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on escalate submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on escalate submit button."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("I click on agent manualtask tile from the dashboard screen")
	public void i_click_on_agent_manualtask_tile_from_the_dashboard_screen() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt = new ManualTask(d);
		mt.clickManualTask();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on manual task.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on manual task."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("I select ASTQ from the dropdown")
	public void i_select_astq_from_the_dropdown() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mt.selectASTQ();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected ASTQ from the dropdown.");
			Util.TakeScreenShot(d, System.currentTimeMillis());		
		} catch (Exception e) {
			ExtentCucumberAdapter.addTestStepLog("Unable to select ASTQ from the dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@And("I click on next item")
	public void I_click_on_next_item() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mt.clickNextItem();
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on next item.");
			Util.TakeScreenShot(d, System.currentTimeMillis());		
		} catch (Exception e) {
			
			ExtentCucumberAdapter.addTestStepLog("Unable to click next item."+ "\n" + e.getMessage());	
			Assert.fail();
		}
	}
	
	@When("Select item from filter and general info dropdown")
	public void selectFilterAndgeneralInfo() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.selectFilter();
		mt.selectGeneralInfo();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected value from filter and generalInfo dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select value from filter and generalInfo dropdown." + "\n" + e.getMessage());
			Assert.fail();
		} 		
	}
	@When("Click on diagnostics")
	public void click_Diagnostics() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mt.clickDiagnostics();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected diagnostics.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} 
		catch (Exception e) {
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select diagnostics." + "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("Click on actions")
	public void clickactions() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mt.clickActions();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected actions.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
		} 
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select actions." + "\n" + e.getMessage());
			Assert.fail();
		} 
		
	}
	@Then("Click on complete work item")
	public void click_complete_work_item() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickCompleteWorkItem();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on complete work item button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on complete work item button." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	
	@When("Click on pause from the top menu")
	public void click_pause_from_the_top_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickPause();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on pause.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on pause." + "\n" + e.getMessage());
			Assert.fail();
		} 
		
	}
	@When("Click on submit from the dialog")
	public void click_submit_dialog() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickSubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on submit button from the dialog.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on submit button from the dialog." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	
	@When("Click on delay from the top menu")
	public void click_delay() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickDelay();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on delay.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click on delay." + "\n" + e.getMessage());
			Assert.fail();
		} 
		
	}
	@When("Select delay date time")
	public void select_delay_datetime() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.selectDelayDateTime();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected delay date and time.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to select delay date and time." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	@When("Enter delay remarks")
	public void enter_delay_remarks() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		mt.enterDelayRemarks();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered delay remarks.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to enter delay remarks." + "\n" + e.getMessage());
			Assert.fail();
		} 
	}
	@Then("Click submit button")
	public void click_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickDelaySubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on delay submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch (Exception e) 
		{
			ExtentCucumberAdapter
			.addTestStepLog("Unable to click delay submit button." + "\n" + e.getMessage());
			Assert.fail();
		} 	
	}
	
	@Then("Click close button")
	public void click_close_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickClose();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on close button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on close button."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("Click on breaks from the top menu")
	public void click_breaks() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickBreaks();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on breaks.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on breaks."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("Select break type")
	public void select_break_type() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try {
			mt.selectBreakType();
			ExtentCucumberAdapter.addTestStepLog("Successfully selected break type.");
			Util.TakeScreenShot(d, System.currentTimeMillis());	
		} 
		catch (Exception e) {
			
			ExtentCucumberAdapter.addTestStepLog("Unable to select break type."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@Then("Click breaks submit button")
	public void click_breaks_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickBreaksSubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on breaks submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on breaks submit button."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@Then("Click resume button")
	public void click_resume_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt = new ManualTask(d);
		mt.clickResume();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on resume button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on resume button."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@When("Click on escalate from the top menu")
	public void click_escalate() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
	    mt.clickEscalate();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on escalate.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on escalate."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("Enter escalate remarks")
	public void enter_escalate_remarks() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.enterEscalateRemark();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered escalate remarks.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to enter escalate remarks."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@Then("Click escalate submit button")
	public void click_escalate_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mt.clickEscalateSubmit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on escalate submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on escalate submit button."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("I click on create manual workitem tile from the dashboard screen")
	public void i_click_on_create_manual_workitem_tile_from_the_dashboard_screen() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi = new ManualWorkItem(d);
		mwi.clickManualWorkItem();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on create manual workitem.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click create manual workitem."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("I click on BYCallerType Tab")
	public void i_click_on_by_caller_type_tab() { 
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.clickByCallerTypeTab();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on By caller type Tab.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on By caller type Tab."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	@When("I click submit button")
	public void i_click_submit_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		mwi = new ManualWorkItem(d);
		
		try{
		mwi.submit();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on submit button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}		
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on submit button."+ "\n" + e.getMessage());
			Assert.fail();
		}		
	}
	@When("I select point of sale from the dropdown")
	public void i_select_point_of_sale_from_the_dropdown() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
	    mwi.selectPointOfSale();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected point of sale.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to select point of sale."+ "\n" + e.getMessage());
			Assert.fail();
		}		
	}
	@When("I select GDS from the dropdown")
	public void i_select_gds_from_the_dropdown() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.selectGDS();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected GDS type from the dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to select GDS type from the dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I enter PNR in the text field")
	public void i_enter_pnr_in_the_text_field() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.enterPNRName();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered PNR in the text field.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to enter PNR in the text field."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("I select task from dropdown")
	public void i_select_task_from_dropdown() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.selectTask();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected task from dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to select task from dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}		
	}
	@When("I select subtask from dropdown")
	public void i_select_subtask_from_dropdown() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.selectSubTask();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected subtask from dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to select subtask from dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("I enter remarks")
	public void i_enter_remarks() throws IOException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.enterRemark();
		ExtentCucumberAdapter.addTestStepLog("Successfully entered remarks.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to enter remarks."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("I select diagnostics")
	public void i_select_diagnostics() throws IOException, InterruptedException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.selectDiagnostics();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected diagnostics from dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to select diagnostics from dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@When("I select Actions")
	public void i_select_actions() throws IOException, InterruptedException {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.selectAction();
		ExtentCucumberAdapter.addTestStepLog("Successfully selected actions from dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to select actions from dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@Then("I click on complete workitem button")
	public void i_click_on_complete_workitem_button() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.clickCompleteWorkitemButton();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on complete workitem button.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on complete workitem button."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@Then("I confirm complete work item")
	public void i_confirm_complete_work_item() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		mwi.clickConfirmComplete();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on confirm complete.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on confirm complete."+ "\n" + e.getMessage());
			Assert.fail();
		}	
	}
	
	@When("I click on completed task from dashboard menu")
	public void i_click_on_completed_task_from_dashboard_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb = new TaskBasket(d);
		tb.clickCompletedTask();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on completed task from dashboard.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to click on completed task from dashboard."+ "\n" + e.getMessage());
			Assert.fail();
		}	
		
		
	}
	@When("I verify if the search box is available or not")
	public void i_verify_if_the_search_box_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver(); 
		try{
		tb.verifySearchBox();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified search box.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify search box."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("I verify if the GDS column is available or not")
	public void i_verify_if_the_gds_column_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.verifyGdsHeader();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified GDS column.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify GDS column."+ "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I verify if the PNR column is available or not")
	public void i_verify_if_the_pnr_column_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.verifyPnrHeader();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified PNR column.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify PNR column."+ "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I verify if the ASTQ column is available or not")
	public void i_verify_if_the_astq_column_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.verifyAstqHeader();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified ASTQ column.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify ASTQ column."+ "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I verify if the TASK column is available or not")
	public void i_verify_if_the_task_column_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.verifyTaskHeader();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified TASK column.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify TASK column."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	@When("I verify if the SUBTASK column is available or not")
	public void i_verify_if_the_subtask_column_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.verifySubTaskHeader();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified SUBTASK column.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify SUBTASK column."+ "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@When("I verify if the DATE column is available or not")
	public void i_verify_if_the_date_column_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.verifyDateHeader();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified DATE column.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify DATE column."+ "\n" + e.getMessage());
			Assert.fail();
		}
		
	}
	@Then("I verify if the filter dropdown is available or not")
	public void i_verify_if_the_filter_dropdown_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.ClickAndverifyFilterDrpDrn();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified filter dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify filter dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@Then("I verify if the filter dropdown is available or not available")
	public void i_verify_if_the_filter_dropdown_is_available_or_not_available() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.ClickAndverifyPausedFilterDrpDrn();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified filter dropdown.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
		}
		catch(Exception e)
		{
			ExtentCucumberAdapter.addTestStepLog("Unable to verify filter dropdown."+ "\n" + e.getMessage());
			Assert.fail();
		}
	}
	
	@Then("I click on pause task from dashboard menu")
	public void I_click_on_pause_task_from_dashboard_menu() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
        tb = new TaskBasket(d);
		tb.clickPauseBasket();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on pause task from dashboard.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on pause task from dashboard."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@Then("I verify if the ACTION column is available or not")
	public void I_verify_if_the_ACTION_column_is_available_or_not() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		tb.verifyActionHeader();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified action column.");
		Util.TakeScreenShot(d, System.currentTimeMillis());	
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to verify action column."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@Then("I search the PNR which has been paused from agent autotask screen")
	public void searchPnr() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		tb.searchPausedPNR();
		ExtentCucumberAdapter.addTestStepLog("Successfully searched PNR.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to search PNR."+ "\n" + e.getMessage());
        	Assert.fail();
        	
        }
	}
	
	@Then("I verify the search result")
	public void I_verify_the_search_result() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		tb.verifyResult();
		ExtentCucumberAdapter.addTestStepLog("Successfully verified search result.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to verify search result."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@Then("I close the dialog")
	public void I_close_the_dialog() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		tb.closeDialog();
		ExtentCucumberAdapter.addTestStepLog("Successfully closed dialog.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to close dialog."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
	}
	
	
	@When("I click on myprofile icon and select myprofile option")
	public void I_click_on_myprofile_icon_and_select_myprofile_option() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        up = new UserProfile(d);
     
        try{
		up.clickUserProfile();
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
           	ExtentCucumberAdapter.addTestStepLog("Unable to click myprofile."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@When("I verify that firstname field is not editable")
	public void I_verify_that_firstname_field_is_not_editable() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		up.verifyFnameDisabled();
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("First name field is not disabled."+ "\n" + e.getMessage());
        	Assert.fail();
        	
        }
	}
	
	@When("I verify that lastname field is not editable")
	public void I_verify_that_lastname_field_is_not_editable() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		up.verifyLnameDisabled();
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Last name field is not disabled."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@When("I verify that emailaddress field is not editable")
	public void I_verify_that_emailaddress_field_is_not_editable() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		up.verifyEmailDisabled();
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Email address field is not disabled."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@When("I verify that usertype field is not editable")
	public void I_verify_that_usertype_field_is_not_editable() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
         try{
		up.verifyUserTypeDisabled();
		Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("Usertype field is not disabled."+ "\n" + e.getMessage());
         	Assert.fail();
         }	
	}
	
	@When("I verify that centername field is not editable")
	public void I_verify_that_centername_field_is_not_editable() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		up.verifyCenterNameDisabled();
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Center name field is not disabled."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
	}
	
	@When("I verify that sitename field is not editable")
	public void I_verify_that_sitename_field_is_not_editable() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
		up.verifySiteNameDisabled();
		Util.TakeScreenShot(d, System.currentTimeMillis());
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Site name field is not disabled."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@When("I verify that sitepartition field is not editable")
	public void I_verify_that_sitepartition_field_is_not_editable() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
         try{
		 up.verifySitePartitionDisabled();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("Site partition field is not disabled."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I close myprofile dialog")
	public void I_close_myprofile_dialog() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
	    try{
		up.closeUserProfileDialog();
		ExtentCucumberAdapter.addTestStepLog("Successfully closed myprofile dialog.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
	    }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to close myprofile dialog."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	}
	
	@When("I click on InboundCall from dashboard screen")
	public void I_click_on_InboundCall_from_dashboard_screen() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
		 
         try{
		 ic.clickInboundcall();
		 ExtentCucumberAdapter.addTestStepLog("Successfully clicked on inbound call from dashboard screen.");
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("Unable to click on inbound call from dashboard screen."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I verify BySearchPNR tab")
	public void I_verify_BySearchPNR_tab() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver(); 
		 ic  = new InboundCall(d);
		 
         try{
		 ic.verifyBysearchPnr_Tab();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("BySearchPNR tab is not present."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I verify ByCallerType tab")
	public void I_verify_ByCallerType_tab() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
		 
         try{
		 ic.verifyBycallerType_Tab();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("ByCallerType tab is not present."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I verify the CallerType option as Airline Outbound")
	public void I_verify_the_CallerType_option_as_Airline_Outbound() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
		 
         try{
         ic.clickBycallerType_Tab();
		 ic.verifyAirlineOutboundOption();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("Airline Outbound option is not present in the dropdown."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	
	@When("I verify the CallerType option as Customer Outbound")
	public void I_verify_the_CallerType_option_as_Customer_Outbound() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
         try{
         //ic.clickBycallerType_Tab();
		 ic.verifyCustomerOutboundOption();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("Customer Outbound option is not present in the dropdown."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I verify the CallerType option as Email")
	public void I_verify_the_CallerType_option_as_Email() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
         try{
         //ic.clickBycallerType_Tab();
		 ic.verifyEmailOption();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("Email option is not present in the dropdown."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I verify the CallerType option as Other")
	public void I_verify_the_CallerType_option_as_Other() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
         try{
         //ic.clickBycallerType_Tab();
		 ic.verifyOtherOption();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("Other option is not present in the dropdown."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I verify the CallerType option as Queue Work")
	public void I_verify_the_CallerType_option_as_Queue_Work() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
         try{
         //ic.clickBycallerType_Tab();
		 ic.verifyQueueWorkOption();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("QueueWork option is not present in the dropdown."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I verify the CallerType option as Slack Escalation")
	public void I_verify_the_CallerType_option_as_Slack_Escalation() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		 ic  = new InboundCall(d);
         try{
         //ic.clickBycallerType_Tab();
		 ic.verifySlackEscalationOption();
		 Util.TakeScreenShot(d, System.currentTimeMillis());
         }
         catch(Exception e)
         {
         	ExtentCucumberAdapter.addTestStepLog("SlackEscalation option is not present in the dropdown."+ "\n" + e.getMessage());
         	Assert.fail();
         }
	}
	
	@When("I click Spl. Project Initiated tile of the page")
	public void clickSplProjectInitiated() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
	    try{
		brks = new Breaks(d);
		brks.clickSplprojectInitiated();
		Util.TakeScreenShot(d, System.currentTimeMillis());
	    }
	    catch(Exception e)
	    {
         	ExtentCucumberAdapter.addTestStepLog("Unable to click on Spl. project initiated tile."+ "\n" + e.getMessage());
         	Assert.fail();
	    }
	  } 
	
	@When("I click Training Initiated tile of the page")
	public void clickTrainingInitiated() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		brks.clickTrainingInitiated();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on Training initiated.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on training initiated."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	  }
	
	@When("I click Meeting tile of the page")
	public void clickMeeting() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		brks.clickMeeting();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on meeting.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on meeting."+ "\n" + e.getMessage());
        	Assert.fail();
        }
		
	  } 
	
	@When("I click Coaching tile of the page")
	public void clickCoaching() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		brks.clickCoaching();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on coaching.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on coaching."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
		
	  } 
	
	@When("I click Schedule Break tile of the page")
	public void clickScheduleBreak() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		brks.clickScheduleBreak();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on schedule break.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on schedule break."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
	 }
	
	@When("I click Unschedule Break tile of the page")
	public void clickUnScheduleBreak() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver(); 
		try{
		brks.clickUnScheduleBreak();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on Unschedule break.");
		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on Unschedule break."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
	 } 
	
	@When("I click Not Ready Res Support tile of the page")
	public void clickNotReadyResSupport() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
         brks.clickNotReadyResSupport();
 		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on NotReadyResSupport.");
 		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on NotReadyResSupport."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
		
	 }
	
	@When("I click Not Ready PC Problem tile of the page")
	public void clickNotReadyPCProblem() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		brks.clickNotReadyPCProblem();
 		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on NotReadyPCProblem.");
 		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on NotReadyPCProblem."+ "\n" + e.getMessage());
        	Assert.fail();
        }
		
	 }
	
	@When("I click Not Ready Other Department tile of the page")
	public void clickNotReadyOtherDepartment() {
	    
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		brks.clickNotReadyOtherDepartment();
 		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on NotReadyOtherDepartment.");
 		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on NotReadyOtherDepartment."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	 }
	
	@When("I click Lunch Break tile of the page")
	public void clickLunchBreak() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		brks.clickLunch();
 		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on lunch.");
 		Util.TakeScreenShot(d, System.currentTimeMillis());
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Unable to click on lunch."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
	 } 
	
	
	@When("I verify the default value of filter dropdown")
	public void verifyDefaultValue() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
            try{
            at.verifyDefaultValue_FilterDropdown();
     		Util.TakeScreenShot(d, System.currentTimeMillis());    
            }
            catch(Exception e)
            {
            	ExtentCucumberAdapter.addTestStepLog("Default value is not present."+ "\n" + e.getMessage());
            	Assert.fail();
            }	
		
	 } 
	
	@When("I verify other options in the filter dropdown")
	public void verifyMultipleValues() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		try{
		 at.verifyMultipleOptionsCount();
		 Util.TakeScreenShot(d, System.currentTimeMillis()); 
		}
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("Filter dropdown has only default value."+ "\n" + e.getMessage());
        	Assert.fail();
        }	
	 } 
	
	@When("I verify that generalInfo dropdown is activated on selecting value from filter dropdown")
	public void verifyActivation_GeneralInfoDrpdrn() {
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
        try{
        at.verifyGeneralInfoActivation();
        Util.TakeScreenShot(d, System.currentTimeMillis());  
        }
        catch(Exception e)
        {
        	ExtentCucumberAdapter.addTestStepLog("GeneralInfo dropdown is currenly disabled."+ "\n" + e.getMessage());
        	Assert.fail();
        }
	 }
	
}
