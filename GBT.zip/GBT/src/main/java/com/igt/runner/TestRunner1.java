package com.igt.runner;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.time.Duration;
import org.apache.poi.xssf.usermodel.XSSFFormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import com.igt.base.BrowserFactory;
import com.igt.base.TestBase;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;
import com.igt.utility.Util;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

	
	@CucumberOptions(features = {"src/main/resources/Feature"}, glue = { "com.igt.stepDefinition",
	"com.igt.base" },
monochrome = true, dryRun =false,tags=("@login or @task"),
plugin = {"pretty",
    "html:target/cucumber",
    "json:target/cucumber-report/cucumber.json",
    "json:target/cucumber.json",
    "com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter: target/report.html",})

public class TestRunner1 extends AbstractTestNGCucumberTests   {

UserActions ua = null;
TestSetup ts = null;

@BeforeTest
@Parameters({"Browser"})
public void setup(String browser)
{
	ts= new TestSetup();
	if(browser.equalsIgnoreCase("chrome"))
	{
		File dir = new File("PassedScreenShot");
		File dir1 = new File("FailedScreenShot");
		Util.purgeDirectory(dir);
		System.out.println("deleted passed screenshot");
		Util.purgeDirectory(dir1);
		System.out.println("deleted failed screenshot");
		TestBase.loadProperty();
		System.out.println("successfully loaded property");
		TestBase.loadUserInput();
		try{
			ts.filename = "MyTestData.xlsx";
		File src = new File(ts.filename);
		ts.fis = new FileInputStream(src);
		ts.workbook = new XSSFWorkbook(ts.fis);
		   XSSFFormulaEvaluator.evaluateAllFormulaCells(ts.workbook);
			  FileOutputStream out = new FileOutputStream(ts.filename);
	          ts.workbook.write(out); 
	          ts.workbook.close();
	          System.out.println("Excel data modified");
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
		}
		BrowserFactory bf = BrowserFactory.getInstance();
		bf.setDriver("chrome");
		WebDriver d = bf.getDriver();
		d.get(System.getProperty("url"));
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(120));
		final By userid = By.cssSelector(TestBase.p.getProperty("id_locator"));
		final By pass = By.cssSelector(TestBase.p.getProperty("pass_locator"));
		final By userrole = By.cssSelector(TestBase.p.getProperty("role_locator"));
		ua  = new UserActions();
		ua.SelectValue(userrole,"Administrator");
		ua.SetValue(userid, System.getProperty("Username"));
		ua.SetValue(pass, System.getProperty("Password"));

	}
	
	else if(browser.equalsIgnoreCase("headlesschrome"))
	{

	    File dir = new File("PassedScreenShot");
		File dir1 = new File("FailedScreenShot");
		Util.purgeDirectory(dir);
		System.out.println("deleted passed screenshot");
		Util.purgeDirectory(dir1);
		System.out.println("deleted failed screenshot");
		TestBase.loadProperty();
		System.out.println("successfully loaded property");
		TestBase.loadUserInput();
		
		try{
			ts.filename = "MyTestData.xlsx";
		File src = new File(ts.filename);
		ts.fis = new FileInputStream(src);
		ts.workbook = new XSSFWorkbook(ts.fis);
		   XSSFFormulaEvaluator.evaluateAllFormulaCells(ts.workbook);
			  FileOutputStream out = new FileOutputStream(ts.filename);
	          ts.workbook.write(out); 
	          ts.workbook.close();
	          System.out.println("Excel data modified");
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		BrowserFactory bf = BrowserFactory.getInstance();
		bf.setDriver("headlesschrome");
		WebDriver d = bf.getDriver();
		d.get(System.getProperty("url"));

		d.manage().window().maximize();
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(120));
		
		final By userid = By.cssSelector(TestBase.p.getProperty("id_locator"));
		final By pass = By.cssSelector(TestBase.p.getProperty("pass_locator"));
		final By userrole = By.cssSelector(TestBase.p.getProperty("role_locator"));
		ua  = new UserActions();
		ua.SelectValue(userrole,"Administrator");
		ua.SetValue(userid, System.getProperty("Username"));
		ua.SetValue(pass, System.getProperty("Password"));
		
	}
	else if(browser.equalsIgnoreCase("firefox"))
	{
		File dir = new File("PassedScreenShot");
		File dir1 = new File("FailedScreenShot");
		Util.purgeDirectory(dir);
		System.out.println("deleted passed screenshot");
		Util.purgeDirectory(dir1);
		System.out.println("deleted failed screenshot");
		TestBase.loadProperty();
		System.out.println("successfully loaded property");
		TestBase.loadUserInput();
		try{
			ts.filename = "MyTestData.xlsx";
		File src = new File(ts.filename);
		ts.fis = new FileInputStream(src);
		ts.workbook = new XSSFWorkbook(ts.fis);
		   XSSFFormulaEvaluator.evaluateAllFormulaCells(ts.workbook);
			  FileOutputStream out = new FileOutputStream(ts.filename);
	          ts.workbook.write(out); 
	          ts.workbook.close();
	          System.out.println("Excel data modified");
		}
		catch(Exception e)
		{
			
			e.printStackTrace();
		}
		BrowserFactory bf = BrowserFactory.getInstance();
		bf.setDriver("firefox");
		WebDriver d = bf.getDriver();
		d.get(System.getProperty("url"));
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(120));
		final By userid = By.cssSelector(TestBase.p.getProperty("id_locator"));
		final By pass = By.cssSelector(TestBase.p.getProperty("pass_locator"));
		final By userrole = By.cssSelector(TestBase.p.getProperty("role_locator"));
		ua  = new UserActions();
		ua.SelectValue(userrole,"Administrator");
		ua.SetValue(userid, System.getProperty("Username1"));
		ua.SetValue(pass, System.getProperty("Password1"));
	}
	
	else if(browser.equalsIgnoreCase("headlessfirefox"))
	{
		
		    File dir = new File("PassedScreenShot");
			File dir1 = new File("FailedScreenShot");
			Util.purgeDirectory(dir);
			System.out.println("deleted passed screenshot");
			Util.purgeDirectory(dir1);
			System.out.println("deleted failed screenshot");
			TestBase.loadProperty();
			System.out.println("successfully loaded property");
			TestBase.loadUserInput();
			try{
				ts.filename = "MyTestData.xlsx";
			    File src = new File(ts.filename);
			    ts.fis = new FileInputStream(src);
			    ts.workbook = new XSSFWorkbook(ts.fis);
			    XSSFFormulaEvaluator.evaluateAllFormulaCells(ts.workbook);
				  FileOutputStream out = new FileOutputStream(ts.filename);
		          ts.workbook.write(out); 
		          ts.workbook.close();
		          System.out.println("Excel data modified");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			
			BrowserFactory bf = BrowserFactory.getInstance();
			bf.setDriver("headlessfirefox");
			WebDriver d = bf.getDriver();
			d.get(System.getProperty("url"));
			d.manage().window().maximize();
			d.manage().timeouts().implicitlyWait(Duration.ofSeconds(120));

		final By userid = By.cssSelector(TestBase.p.getProperty("id_locator"));
		final By pass = By.cssSelector(TestBase.p.getProperty("pass_locator"));
		final By userrole = By.cssSelector(TestBase.p.getProperty("role_locator"));
		ua  = new UserActions();
		ua.SelectValue(userrole,"Administrator");
		ua.SetValue(userid, System.getProperty("Username1"));
		ua.SetValue(pass, System.getProperty("Password1"));
	}
}
	@AfterTest()
public void last(){
		
		System.out.println("Test executed");
		BrowserFactory bf = BrowserFactory.getInstance();
		WebDriver d = bf.getDriver();
		d.quit();
	//tags=("@login or @task or @subtask or @action or @subaction or @mapping or @posAndpcc or @stq or @report or @agentSkills or @languageSkills or @dashboard or @brand")
	 //tags=("@Agentlogin or @AgentDashboard or @AutoTask or @ManualTask or @ManualWorkItem or @completedtaskbasket or @Pausebasket or @myprofile or @inboundcall or @breaks or @filterVerification") 
     }
}
