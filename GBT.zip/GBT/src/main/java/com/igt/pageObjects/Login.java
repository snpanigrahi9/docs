package com.igt.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class Login extends TestSetup {
	
	
	UserActions ua = null;
	public WebDriver d;

	public Login(WebDriver d) {
		this.d = d;

	}

	//public final By userid = By.cssSelector(p.getProperty("id_locator"));
	//public final By pass = By.cssSelector(p.getProperty("pass_locator"));
	public final By logon = By.cssSelector(p.getProperty("LoginButton_locator"));
	public final By userrole = By.cssSelector(p.getProperty("role_locator"));
	public final By logout = By.cssSelector(p.getProperty("AdminLogout_locator"));
	public final By clickMyprofile = By.cssSelector(p.getProperty("ClickMyProfile_locator"));
	
	public String GetAppUrl() {
		ua  = new UserActions();
		String appUrl = ua.GetCurrentUrl();
		return appUrl;
	}

	
	public void EnterCredentials() {
		//ua  = new UserActions();
		//UserActions.SelectByOptionValue(userrole,System.getProperty("Role"));
		//ua.SelectValue(userrole,"Administrator");
		//ua.SetValue(userid, System.getProperty("Username"));
		//ua.SetValue(pass, System.getProperty("Password"));

	}

	public void ClickLogOn() {
		ua  = new UserActions();
		ua.click(logon);
	}
	
	
	public void ClickLogOut() {
		ua  = new UserActions();
		ua.Wait_Sec();
		ua.Wait_Sec();
		ua.click(clickMyprofile);
		ua.Wait_Sec();
		ua.click(logout);
	}

}
