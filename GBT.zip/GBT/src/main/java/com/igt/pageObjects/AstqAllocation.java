package com.igt.pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class AstqAllocation extends TestSetup{
	
	
	UserActions ua = null;
	public WebDriver d;
	
	public AstqAllocation(WebDriver d)
	{	
		this.d = d;
	}
	
	public final By astqallocation = By.cssSelector(p.getProperty("AstqAllocation_locator"));
	public final By choosesite = By.cssSelector(p.getProperty("ChooseSite_locator"));
	public final By choosesitepartition = By.cssSelector(p.getProperty("ChooseSitePartition_locator"));
	public final By choosecenter = By.cssSelector(p.getProperty("ChooseCenter_locator"));
	public final By searchdata = By.cssSelector(p.getProperty("SearchData_locator"));
	public final By clickagentskill = By.cssSelector(p.getProperty("ClickAgentSkills_locator"));
	public final By manageAssignedAstqs = By.cssSelector(p.getProperty("ManageAssignedAstqs_locator"));
	public final By add_new = By.cssSelector(p.getProperty("AddNewButton_locator"));
	public final By submit = By.cssSelector(p.getProperty("SubmitData_locator"));
	public final By deleteconfirm = By.cssSelector(p.getProperty("DeleteConfirm_locator"));
	public final By assignAstqToAgentsTab = By.cssSelector(p.getProperty("AssignAstqToAgentsTab_locator"));
	public final By stqDrpDrn = By.cssSelector(p.getProperty("StqDrpDrn_locator"));
	public final By manageAssignedAgents = By.cssSelector(p.getProperty("ManageAssignedAgents_locator"));
	public final By ManageSTQ = By.cssSelector(p.getProperty("ManageSTQ_locator"));
	public final By multiAssignAstqsToAgents = By.cssSelector(p.getProperty("MultiAssignAstqsToAgentsTab_locator"));
	public final By nextitem = By.cssSelector(p.getProperty("NextItemButton_locator"));
	public final By clickSubmit = By.cssSelector(p.getProperty("Click_Submit"));
	public final By nodatafound = By.cssSelector(p.getProperty("NoDataFound_locator"));
	
	public void clickAstqAllocation()
	{
		ua  = new UserActions();
		Boolean isExist_astqAllocation = ua.GetDisplayed(astqallocation);
		if(isExist_astqAllocation)
		{
		ua.click(astqallocation);
		}
		else
		{
			ua.Click_JavaScript(ManageSTQ);
			ua.Click_JavaScript(astqallocation);
		}
		
	}
	
	
	public void Select_site_sitepartition_center() throws IOException
	{
		ua  = new UserActions();
		String sitedetail = ua.getCellData("UserData","Site_AstqAllocation",2);
		ua.SelectValue(choosesite,sitedetail);
		String sitepartitiondetail = ua.getCellData("UserData","Sitepartition_AstqAllocation",2);
		ua.SelectValue(choosesitepartition,sitepartitiondetail);
		String centerdetail = ua.getCellData("UserData","Center_AstqAllocation",2);
		ua.SelectValue(choosecenter,centerdetail);
	}
	
	
	public void selectAgentSkills() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String agentskill = ua.getCellData("UserData","AstqAllocation_agentskill",2);
		ua.click(clickagentskill);
		ua.click_by_dynamicCssNoSpace(agentskill);
	}
	
	
	public void searchData()
	{
		ua  = new UserActions();
		ua.click(searchdata);
		
	}
	
	public void selectAgent() throws IOException
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String radioButtonNumber = ua.getCellData("UserData","SelectAgent_RadioButtonNo",2);
		int radiobutton_No = Integer.parseInt(radioButtonNumber);
		List<WebElement>allradio = d.findElements(By.cssSelector("input[type='radio']"));
		allradio.get(radiobutton_No).click();
		
	}
	public void clickManageAssignedAstqs()
	{
		ua  = new UserActions();
		ua.Click_JavaScript(manageAssignedAstqs);
	}
	
	public void addNew_click()
	{
		ua  = new UserActions();
		ua.click(add_new);
	}
	
	public void selectAstq() throws IOException
	{
		ua  = new UserActions();
		
		String checkboxNumber = ua.getCellData("UserData","SelectAstq_CheckboxNo",2);
		int checkbox_No = Integer.parseInt(checkboxNumber);
		//ua.Wait_Sec();
		//ua.Wait_Sec();
		ua.SetObjectSyncronizationTimeOut();
		List<WebElement>allcheck = d.findElements(By.cssSelector("input[onclick*='check']"));
		allcheck.get(checkbox_No).click();
	}
	
	public void submit()
	{
		ua  = new UserActions();
		ua.click(submit);
	}
	
	public void deleteAssignedAstq() throws IOException
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		//ua.SetObjectSyncronizationTimeOut();
		List<WebElement>allradio = d.findElements(By.cssSelector("a[class='delete']"));
		int numberof = allradio.size();
		int deleteNo = numberof-1;
		allradio.get(deleteNo).click();
		//ua.Wait_Sec();
		ua.click(deleteconfirm);
	}
	
	public void clickAssignAstqToAgents_Tab()
	{
		ua  = new UserActions();
		ua.click(assignAstqToAgentsTab);
		
	}
	
	public void select_site_sitepartition_stq() throws IOException
	{
		ua  = new UserActions();
		String sitedetail = ua.getCellData("UserData","Site_AstqAllocation",2);
		ua.SelectValue(choosesite,sitedetail);
		String sitepartitiondetail = ua.getCellData("UserData","Sitepartition_AstqAllocation",2);
		ua.SelectValue(choosesitepartition,sitepartitiondetail);
		String selectStq = ua.getCellData("UserData","SelectStq",2);
		ua.SelectValue(stqDrpDrn,selectStq);
		
	}
	
	public void selectAstq_AssignAstqToAgentsTab() throws IOException
	{
		List<WebElement>allradio = d.findElements(By.cssSelector("input[type='radio']"));
		int radionumber = allradio.size();
		int radiobutton_No = radionumber-1;
		allradio.get(radiobutton_No).click();
	}
	
	public void clickManageAssignedAgents()
	{
		ua  = new UserActions();
		ua.click(manageAssignedAgents);
	}
	
	public void selectAgent_AssignAstqToAgentsTab() throws IOException
	{
		ua  = new UserActions();
		String checkboxNumber = ua.getCellData("UserData","SelectAgent_CheckBoxNo",2);
		int checkbox_No = Integer.parseInt(checkboxNumber);
		List<WebElement>allcheck = d.findElements(By.cssSelector("input[onclick*='check']"));
		allcheck.get(checkbox_No).click();
	}
	
	public void clickMultiAssignAstqsToAgents_Tab()
	{
		ua  = new UserActions();
		ua.click(multiAssignAstqsToAgents);
		
	}
	
	public void clickNextItem()
	{
		ua  = new UserActions();
		ua.click(nextitem);
	}
	
	public void click_Submit()
	{
		ua  = new UserActions();
		ua.click(clickSubmit);
	}
	
	public void addNew()
	{
		ua  = new UserActions();
		Boolean isExist_Nodata = ua.GetDisplayed(nodatafound);
		if(!isExist_Nodata)
		{
			ua.Wait_Sec();
			List<WebElement>allradio = d.findElements(By.cssSelector("a[class='delete']"));
			int numberof = allradio.size();
			int deleteNo = numberof-1;
			allradio.get(deleteNo).click();
			ua.Wait_Sec();
			ua.click(deleteconfirm);
		}
	
		ua.click(add_new);
	}
}
