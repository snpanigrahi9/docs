package com.igt.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class TaskBasket extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;
	
	public TaskBasket(WebDriver d)
	{
		
		this.d=d;
	}
	
	public final By completedtask = By.cssSelector(p.getProperty("clickCompletedTaskBasket_locator"));
	public final By verifygds = By.cssSelector(p.getProperty("verifyGDSHeader_locator"));
	public final By verifypnr = By.cssSelector(p.getProperty("verifyPNRHeader_locator"));
	public final By verifyastq = By.cssSelector(p.getProperty("verifyASTQHeader_locator"));
	public final By verifytask = By.cssSelector(p.getProperty("verifyTASKHeader_locator"));
	public final By verifysubtask = By.cssSelector(p.getProperty("verifySUBTASKHeader_locator"));
	public final By verifydate = By.cssSelector(p.getProperty("verifyDATEHeader_locator"));
	public final By verifysearchbox = By.cssSelector(p.getProperty("searchBox_locator"));
	public final By verifyfilterdrpdrn = By.cssSelector(p.getProperty("taskLength_locator"));
	public final By pausebasket = By.cssSelector(p.getProperty("clickPauseBasket_locator"));
	public final By verifyaction = By.cssSelector(p.getProperty("verifyACTIONHeader_locator"));
	public final By autotask = By.cssSelector(p.getProperty("Autotask_locator"));
	public final By pause = By.cssSelector(p.getProperty("pause_locator"));
	public final By getpnr = By.cssSelector(p.getProperty("getPNRValue_locator"));
	public final By verifySearchResult = By.cssSelector(p.getProperty("verifySearchResult_locator"));
	public final By verifyPausedfilterdrpdrn = By.cssSelector(p.getProperty("pauseTaskLength_locator"));
	public final By submit = By.cssSelector(p.getProperty("submit_locator"));
	public final By dialogclose = By.cssSelector(p.getProperty("dialogClose_locator"));
	
	public void clickCompletedTask()
	{
		ua  = new UserActions();
		ua.click(completedtask);
		ua.waitForElement(verifysearchbox);
		//UserActions.HighWait_Sec();
	}
	
	public void verifyGdsHeader()
	{
		ua  = new UserActions();
		Boolean isExistGds = ua.GetExistance(verifygds);
		if(isExistGds)
		{
			ExtentCucumberAdapter.addTestStepLog("Gds column is available in the Popup.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Gds column is not available in the Popup.");
			Assert.fail();
		}
	}
	
	
	public void verifyPnrHeader()
	{
		ua  = new UserActions();
		Boolean isExistPnr = ua.GetExistance(verifypnr);
		if(isExistPnr)
		{
			ExtentCucumberAdapter.addTestStepLog("Pnr column is available in the Popup.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Pnr column is not available in the Popup.");
			Assert.fail();
		}
		
	}
	
	
	public void verifyAstqHeader()
	{
		ua  = new UserActions();
		Boolean isExistAstq = ua.GetExistance(verifyastq);
		if(isExistAstq)
		{
			ExtentCucumberAdapter.addTestStepLog("Astq column is available in the Popup.");
		}
		
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Astq column is not available in the Popup.");
			Assert.fail();
		}
		
	}
	
	public void verifyTaskHeader()
	{
		ua  = new UserActions();
		Boolean isExistTask = ua.GetExistance(verifytask);
		if(isExistTask)
		{
			ExtentCucumberAdapter.addTestStepLog("Task column is available in the Popup.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Task column is not available in the Popup.");
			Assert.fail();
		}
		
	}
	
	public void verifySubTaskHeader()
	{
		ua  = new UserActions();
		Boolean isExistSubTask = ua.GetExistance(verifysubtask);
		if(isExistSubTask)
		{
			ExtentCucumberAdapter.addTestStepLog("SubTask column is available in the Popup.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Subtask column is not available in the Popup.");
			Assert.fail();
		}
	}
	
	public void verifyDateHeader()
	{
		ua  = new UserActions();
		Boolean isExistDate = ua.GetExistance(verifydate);
		if(isExistDate)
		{
			ExtentCucumberAdapter.addTestStepLog("Date column is available in the Popup.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Date column is not available in the Popup.");
			Assert.fail();
		}
		
	}
	
	public void verifySearchBox()
	{
		ua  = new UserActions();
		ua.HighWait_Sec();
		Boolean isExistSearchBox = ua.GetExistance(verifysearchbox);
		if(isExistSearchBox)
		{
			ExtentCucumberAdapter.addTestStepLog("Searchbox column is available in the Popup.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Searchbox column is not available in the Popup.");
			Assert.fail();
		}	
	}
	
	public void ClickAndverifyFilterDrpDrn()
	{
		ua  = new UserActions();
		Boolean isExistFilterDrpdrn = ua.GetExistance(verifyfilterdrpdrn);
		if(isExistFilterDrpdrn)
		{
			ua.click(verifyfilterdrpdrn);
			ExtentCucumberAdapter.addTestStepLog("Filter dropdown is available in the Popup.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Filter dropdown is not available in the Popup.");
			Assert.fail();
		}
	}
	
	public void ClickAndverifyPausedFilterDrpDrn()
	{
		ua  = new UserActions();
		Boolean isExistFilterDrpdrn = ua.GetExistance(verifyPausedfilterdrpdrn);
		if(isExistFilterDrpdrn)
		{
			ua.click(verifyPausedfilterdrpdrn);
			ExtentCucumberAdapter.addTestStepLog("Filter dropdown is available in the Popup.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Filter dropdown is not available in the Popup.");
			Assert.fail();
		}
	}
	
	public void clickPauseBasket()
	{
		ua  = new UserActions();
		ua.click(pausebasket);
		//UserActions.HighWait_Sec();
		ua.waitForElement(verifysearchbox);
	}
	
	public void verifyActionHeader()
	{
		ua  = new UserActions();
		Boolean isExistAction = ua.GetExistance(verifyaction);
		if(isExistAction)
		{
			ExtentCucumberAdapter.addTestStepLog("Action column is available in the Popup.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Action column is not available in the Popup.");
			Assert.fail();
		}	
	}
	
	public void searchPausedPNR()
	{
		ua  = new UserActions();
		Boolean isExist = ua.GetExistance(autotask);
		if(isExist)
		{
		ua.Wait_Sec();
		ua.click(autotask);
		}
		ua.Wait_Sec();
		String pnr = ua.getText(getpnr);
		ua.Wait_Sec();
		ua.click(pause);
		ua.click(submit);
		ua.Wait_Sec();
		ua.click(pausebasket);
		//UserActions.HighWait_Sec();
		ua.waitForElement(verifysearchbox);
		ua.SetValue(verifysearchbox,pnr);	
		
	}
	
	public void verifyResult()
	{
		ua  = new UserActions();
		String result = ua.getText(verifySearchResult);
		if(result!=null)
		{
			ExtentCucumberAdapter.addTestStepLog("Search result is available");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Search result is not available");
		}
		
	}
	
	public void closeDialog()
	{
		ua  = new UserActions();
		ua.click(dialogclose);
		
	}
	
	
}
