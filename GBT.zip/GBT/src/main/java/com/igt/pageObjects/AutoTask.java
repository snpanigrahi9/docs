package com.igt.pageObjects;

import java.io.IOException;
import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class AutoTask extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;

	public AutoTask(WebDriver d) {
		this.d = d;
	}
	
	public final By autotask = By.cssSelector(p.getProperty("Autotask_locator"));
	public final By filter = By.cssSelector(p.getProperty("filter_locator"));
	public final By generalinfo = By.cssSelector(p.getProperty("generalInfo_locator"));
	public final By completeworkitem = By.id(p.getProperty("completeWorkItem_locator"));
	public final By pnr = By.id(p.getProperty("getPNR_locator"));
	public final By pause = By.cssSelector(p.getProperty("pause_locator"));
	public final By submit = By.cssSelector(p.getProperty("submit_locator"));
	public final By delay = By.cssSelector(p.getProperty("delay_locator"));
	public final By delayremarks = By.cssSelector(p.getProperty("delayRemarks_locator"));
	public final By submitdelay = By.cssSelector(p.getProperty("submitDelay_locator"));
	public final By close = By.cssSelector(p.getProperty("CloseButton"));
	public final By breaks = By.cssSelector(p.getProperty("breaks_locator"));
	public final By submitbreaks = By.cssSelector(p.getProperty("submitBreaks_locator"));
	public final By escalate = By.cssSelector(p.getProperty("escalate_locator"));
	public final By escalateRemark = By.cssSelector(p.getProperty("escalateRemark_locator"));
	public final By submitescalate = By.cssSelector(p.getProperty("submitEscalate_locator"));
	public final By resume = By.cssSelector(p.getProperty("resume_locator"));
	public final By getText_SubAction = By.cssSelector(p.getProperty("getSubaction_locator"));
	public final By closeSubactionPopUp = By.cssSelector(p.getProperty("closeSubactions_locator"));
	public final By selectAllsubactions = By.cssSelector(p.getProperty("selectAllSubaction_locator"));
	
	
	public void clickAutoTask()
	{
		ua  = new UserActions();
		Boolean isExist = ua.GetExistance(autotask);
		if(isExist)
		{
		ua.Wait_Sec();
		ua.click(autotask);
		}
	}
	
	public void selectFilter() throws IOException
	{
		ua  = new UserActions();
		//String getpnr = UserActions.getText(pnr);
		 Boolean isPNRExist = ua.GetExistance(pnr);
		 Boolean isFilterExist = ua.GetExistance(filter);
		 
		if(isPNRExist && isFilterExist)
		{
		String filterValue = ua.getCellData("AgentRoleData","Filter_DrpdownValue",2);
		ua.SelectValue(filter,filterValue);
			//Assert.fail("No PNR exist or filter");
		}
		
		else if(isPNRExist && !isFilterExist){
			
			ExtentCucumberAdapter.addTestStepLog("Filter dropdown is not exist");			
		}
		
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Filter dropdown is not exist");	
		}
	}
	public void selectGeneralInfo() throws IOException
	{
		ua  = new UserActions();
		Boolean isGeneralInfoExist = ua.GetExistance(generalinfo);
		if(isGeneralInfoExist)
		{
			String generalInfoValue = ua.getCellData("AgentRoleData","GeneralInfo_DrpdownValue",2);
			ua.SelectValue(generalinfo,generalInfoValue);	
		}
	}
	
	public void clickCompleteWorkItem()
	{
		ua  = new UserActions();
		ua.Click_JavaScript(completeworkitem);
	}
	
	public void clickDiagnostics() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String diagnostics = ua.getCellData("AgentRoleData","Diagnostics",2);
		ua.DynamicXpathUsingTextByJavaScript(diagnostics);
	}
	
/*	public void clickActions() throws IOException, InterruptedException
	{
		String action = UserActions.getCellData("AgentRoleData","Actions",2);
		UserActions.xpathUsingTextByJavaScript(action);
	}*/
	
	public void clickActions() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String action = ua.getCellData("AgentRoleData","Actions",2);
		ua.Wait_Sec();
		ua.xpathUsingTextByJavaScript(action);
		//Boolean isExistpopup = UserActions.GetExistance(closeSubactionPopUp);

		   Boolean isExist_NoSubAction = ua.GetExistance(getText_SubAction);
		   if(isExist_NoSubAction)
		   {
			Boolean SubAction = ua.getText(getText_SubAction).contains("No Subaction");
			if(SubAction)
			{
				ua.click(closeSubactionPopUp);
			}
			else{
				   ua.CheckAllCheckbox(selectAllsubactions);
				   ua.Wait_Sec();
				   ua.click(closeSubactionPopUp);
			}
		   }   
	}
	
	
	public void clickPause()
	{
		ua  = new UserActions();
		ua.click(pause);
	}
	
	public void clickSubmit()
	{
		ua  = new UserActions();
		ua.click(submit);
	}
	
	public void clickDelay()
	{
		ua  = new UserActions();
		ua.click(delay);
	}
	
	
	public void selectDelayDateTime()
	{
		ua  = new UserActions();
		//UserActions.Wait_Sec();
		WebDriverWait wait = new WebDriverWait(d,Duration.ofSeconds(l));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[name='workitemBean.delayDate']")));
		
		WebElement delayDateTime = d.findElement(By.cssSelector("input[name='workitemBean.delayDate']"));
		ua.Wait_Sec();
		JavascriptExecutor executor = (JavascriptExecutor) d;
		executor.executeScript("arguments[0].removeAttribute('readonly','readonly')",delayDateTime );

		LocalDate date = LocalDate.now();
		System.out.println("Date: " + date);

		LocalDate local = date.plusDays(1);
		System.out.println("New Date: " + local);
		String delaydate = local.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		delayDateTime.sendKeys(delaydate);
		
	}
	
	public void enterDelayRemarks() throws IOException
	{
		ua  = new UserActions();
		String dremarks = ua.getCellData("AgentRoleData","DelayRemark",2);
		ua.click(delayremarks);
		ua.Wait_Sec();
		ua.SetValue(delayremarks,dremarks);
	}
	
	public void clickDelaySubmit()
	{
		ua  = new UserActions();
		ua.click(submitdelay);
	}
	
	public void clickClose()
	{
		ua  = new UserActions();
		ua.click(close);
	}
	
	public void clickBreaks()
	{
		ua  = new UserActions();
		ua.click(breaks);
	}
	
	public void selectBreakType() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String btype = ua.getCellData("AgentRoleData","BreakType",2);
		ua.xpathUsingTextByJavaScript(btype);
	}
	
	public void clickBreaksSubmit()
	{
		ua  = new UserActions();
		ua.click(submitbreaks);
	}
	
	public void clickResume()
	{
		ua  = new UserActions();
		ua.click(resume);
	}
	
	public void clickEscalate()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(escalate);
	}
	
	public void enterEscalateRemark() throws IOException
	{
		ua  = new UserActions();
		String eremark = ua.getCellData("AgentRoleData","EscalateRemark",2);
		ua.SetValue(escalateRemark,eremark);
	}
	
	public void clickEscalateSubmit()
	{
		ua  = new UserActions();
		ua.click(submitescalate);
	}
	
	public void verifyDefaultValue_FilterDropdown() throws IOException
	{
		ua  = new UserActions();
		//String getpnr = UserActions.getText(pnr);
		 Boolean isFilterExist = ua.GetExistance(filter);
		 String dvalue = ua.SelectDefaultDropDownValue(filter);
		 Assert.assertEquals(dvalue,"N/A - Filter"); 
		 ExtentCucumberAdapter.addTestStepLog("Successfully verified the default value"+"  "+dvalue);
	}
	
	public void verifyMultipleOptionsCount() throws IOException
	{
		 ua  = new UserActions();
		 Boolean isFilterExist = ua.GetExistance(filter);
		 int optionSize = ua.getAllOptionsCount(filter);
		 if(optionSize>0)
		 {
			 ExtentCucumberAdapter.addTestStepLog("Filter dropdown has multiple options.");
			 
		 }
		 
         
	}
	
	public void verifyGeneralInfoActivation() throws IOException
	{
		 ua  = new UserActions();
		 Boolean isFilterExist = ua.GetExistance(filter);
		 int optionSize = ua.getAllOptionsCount(filter);
		 if(optionSize>0)
		 {
		 int indexvalue = optionSize-1;
		 ua.SelectValueByIndex(filter, indexvalue);
		 }
		 Boolean isGeneralInfoExist = ua.GetExistance(generalinfo);
		 Boolean isActive = ua.GetEnabled(generalinfo);
		 if(isActive)
		 {
			 ExtentCucumberAdapter.addTestStepLog("GeneralInfo dropdown is currently enabled");
			 
		 }
         
	}
}
