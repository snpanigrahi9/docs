package com.igt.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class UserProfile extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;
	
	public UserProfile(WebDriver d)
	{
		this.d=d;
	}
	
	public final By clickMyprofile = By.cssSelector(p.getProperty("AgentClickMyProfile_locator"));
	public final By myprofile = By.cssSelector(p.getProperty("MyProfile_locator"));
	public final By fname = By.cssSelector(p.getProperty("fname_locator"));
	public final By lname = By.cssSelector(p.getProperty("lname_locator"));
	public final By mailid = By.cssSelector(p.getProperty("EmailId_locator"));
	public final By usertype = By.cssSelector(p.getProperty("UserType_locator"));
	public final By centername = By.cssSelector(p.getProperty("CenterName_locator"));
	public final By sitename = By.cssSelector(p.getProperty("SiteName_locator"));
	public final By sitepartition = By.cssSelector(p.getProperty("SiteP_locator"));
	public final By closeuserprofile = By.cssSelector(p.getProperty("CloseUserProfile_locator"));
	
	
	
	public void clickUserProfile()
	{
		ua  = new UserActions();
		ua.click(clickMyprofile);
		ua.Wait_Sec();
		ua.click(myprofile);
		
	}
	
	public void verifyFnameDisabled()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String fname_attribute = ua.GetAttribute(fname,"disabled");
		if(fname_attribute.equals("true"))
		{
			ExtentCucumberAdapter.addTestStepLog("First name field is disabled");
			
		}
		
	}
	
	public void verifyLnameDisabled()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String lname_attribute = ua.GetAttribute(lname,"disabled");
		if(lname_attribute.equals("true"))
		{
			ExtentCucumberAdapter.addTestStepLog("Last name field is disabled");
			
		}
		
	}
	
	public void verifyUserTypeDisabled()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String usertype_attribute = ua.GetAttribute(usertype,"disabled");
		if(usertype_attribute.equals("true"))
		{
			ExtentCucumberAdapter.addTestStepLog("UserType field is disabled");
			
		}
	}
	
	public void verifyEmailDisabled()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String email_attribute = ua.GetAttribute(mailid,"disabled");
		if(email_attribute.equals("true"))
		{
			ExtentCucumberAdapter.addTestStepLog("Emailid field is disabled");
		}
	}
	
	public void verifyCenterNameDisabled()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String centername_attribute = ua.GetAttribute(centername,"disabled");
		if(centername_attribute.equals("true"))
		{
			ExtentCucumberAdapter.addTestStepLog("Centername field is disabled");
		}
	}
	
	public void verifySiteNameDisabled()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String sitename_attribute = ua.GetAttribute(sitename,"disabled");
		if(sitename_attribute.equals("true"))
		{
			ExtentCucumberAdapter.addTestStepLog("Sitename field is disabled");
		}
	}
	
	public void verifySitePartitionDisabled()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String sitepartition_attribute = ua.GetAttribute(sitepartition,"disabled");
		if(sitepartition_attribute.equals("true"))
		{
			ExtentCucumberAdapter.addTestStepLog("Sitepartition field is disabled");
		}
	}
	
	public void closeUserProfileDialog()
	{
		ua  = new UserActions();
		ua.click(closeuserprofile);
	}


}
