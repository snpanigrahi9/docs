package com.igt.pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class SkillTaskQueueConfiguration extends TestSetup {
	
	
	UserActions ua = null;
	public WebDriver d;
	
	public SkillTaskQueueConfiguration(WebDriver d)
	{	
		this.d = d;
	}
	
	public final By skilltaskqueueconfiguration = By.cssSelector(p.getProperty("SkillTaskQueueConfiguration_locator"));
	public final By addnewstq = By.cssSelector(p.getProperty("AddNewStq_locator"));
	public final By stqcode = By.cssSelector(p.getProperty("StqCode_locator"));
	public final By stqdesc = By.cssSelector(p.getProperty("StqDesc_locator"));
	public final By selectsitename = By.cssSelector(p.getProperty("SelectSiteName_locator"));
	public final By selectsitepartitionname = By.cssSelector(p.getProperty("SelectSitePartitionName_locator"));
	public final By stqcreatedok = By.cssSelector(p.getProperty("StqCreatedOk_locator"));
	public final By manageastqbutton = By.cssSelector(p.getProperty("ManageAstqButton_locator"));
	public final By addnewastq = By.cssSelector(p.getProperty("AddNewAstq_locator"));
	public final By astqcode = By.cssSelector(p.getProperty("AstqCode_locator"));
	public final By astqdesc = By.cssSelector(p.getProperty("AstqDesc_locator"));
	public final By servingorder = By.cssSelector(p.getProperty("ServingOrer_locator"));
	public final By astqcreatedok = By.cssSelector(p.getProperty("AstqCreatedOk_locator"));
	public final By mapnewgdsqueue = By.cssSelector(p.getProperty("MapNewGDSQueues_locator"));
	public final By gdsno = By.cssSelector(p.getProperty("gdsno_locator"));
	public final By mapselectedgdsqueue = By.cssSelector(p.getProperty("MapNewGDSQueues_locator"));
	public final By mappingok = By.cssSelector(p.getProperty("MappedWithAstqOk_locator"));
	public final By uploadworkitem = By.cssSelector(p.getProperty("UploadWorkItems_locator"));
	public final By gdsqueuename = By.cssSelector(p.getProperty("SelectQueueName_locator"));
	public final By choosefile = By.cssSelector(p.getProperty("ChooseFile_locator"));
	public final By upload = By.cssSelector(p.getProperty("Upload_locator"));
	public final By back = By.cssSelector(p.getProperty("Back_locator"));
	public final By viewmappedgdsqueue = By.cssSelector(p.getProperty("ViewMappedGDSQueues_locator"));
	public final By clickclose = By.cssSelector(p.getProperty("ClickClose_locator"));
	public final By deletequeue = By.cssSelector(p.getProperty("DeleteGdsQueue_locator"));
	
	
	
	public void clickSkillTaskQueueConfiguration()
	{
		ua = new UserActions();
		ua.click(skilltaskqueueconfiguration);
	}
	
	public void addNewStq()
	{
		ua = new UserActions();
		ua.click(addnewstq);
	}
	
	public void enterStqCode() throws IOException
	{
		String stq_code = ua.getCellData("UserData","StqCode",2);
		ua = new UserActions();
		ua.SetValue(stqcode,stq_code);
		
	}
	
	public void enterStqDesc() throws IOException
	{
		String stq_desc = ua.getCellData("UserData","StqDesc",2);
		ua = new UserActions();
		ua.SetValue(stqdesc,stq_desc);
	}
	
	public void selectSiteName() throws IOException
	{
		String site_name = ua.getCellData("UserData","SiteName",2);
		ua = new UserActions();
		ua.SelectValue(selectsitename, site_name);
	}
	
	public void selectSitePartitionName() throws IOException
	{
		String sitepartition_name = ua.getCellData("UserData","SitePartitionName",2);
		ua = new UserActions();
		ua.SelectValue(selectsitepartitionname, sitepartition_name);
	}
	
	public void stqCreatedOk()
	{
		ua = new UserActions();
		Boolean isDisplayedOk = ua.GetDisplayed(stqcreatedok);
		if(isDisplayedOk)
		{
		ua.click(stqcreatedok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on Ok.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Ok popup is not present. So not clicking on it.");
		}
	}
	public void clickManageAstqButton()
	{
		List<WebElement>allbutton = d.findElements(manageastqbutton);
		//int numberof = allbutton.size();
		//int deleteNo = numberof-1;
		allbutton.get(0).click();
	}
	
	public void addNewAstq()
	{
		ua = new UserActions();
		ua.click(addnewastq);
	}
	
	public void enterAstqCode() throws IOException
	{
		String astq_code = ua.getCellData("UserData","AstqCode",2);
		ua = new UserActions();
		ua.SetValue(astqcode,astq_code);
		
	}
	
	public void enterAstqDesc() throws IOException
	{
		String astq_desc = ua.getCellData("UserData","AstqDesc",2);
		ua = new UserActions();
		ua.SetValue(astqdesc,astq_desc);
		
	}
	
	public void selectServingOrder() throws IOException
	{
		String serving_order = ua.getCellData("UserData","ServingOrder",2);
		ua = new UserActions();
		ua.SelectValue(servingorder,serving_order);
	}
	
	public void astqCreatedOk()
	{
		ua = new UserActions();
		Boolean isDisplayedOk = ua.GetDisplayed(astqcreatedok);
		if(isDisplayedOk)
		{
		ua.click(astqcreatedok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on Ok.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Ok popup is not present. So not clicking on it.");
		}
	}
	
	public void mapNewGdsQueue()
	{
		ua = new UserActions();
		ua.click(mapnewgdsqueue);
	}
	
	public void selectGDSQueueToMap() throws IOException
	{
		String selectgdsno = ua.getCellData("UserData","SelectGDSCheckboxNo",2);
		int gds_no = Integer.parseInt(selectgdsno);
		List<WebElement>allgds = d.findElements(gdsno);
		allgds.get(gds_no).click();
	}
	
	
	public void okMapping()
	{
		ua = new UserActions();
		ua.click(mappingok);
		
	}
	
	public void clickUploadWorkItem()
	{
		ua = new UserActions();
		ua.click(uploadworkitem);
		
	}
	
	public void selectGdsQueueName() throws IOException
	{
		String selectgds = ua.getCellData("UserData","SelectGds",2);
		ua = new UserActions();
		ua.SelectValue(gdsqueuename,selectgds);
	}
	
   public void fileToUpload()
   {
	   ua = new UserActions();
	   ua.Click_JavaScript(choosefile);
	   ua.Wait_Sec();
	   ua.browseFileToUpload(choosefile,"D://GBT//src//main//resources//CSVFiles//STQUPLOAD9.csv");
   }
   
   public void clickUpload()
   {
	   ua = new UserActions();
	   ua.click(upload);
	   ua.Wait_Sec();
   }
   
   
   public void clickBack()
   {
	   ua = new UserActions();
	   ua.click(back);
   }
   
   public void viewMappedGdsQueue()
   {
	   ua = new UserActions();
	   ua.click(viewmappedgdsqueue);
   }
   
   public void deleteQueue()
   {
	   ua = new UserActions();
	   ua.click(deletequeue);
   }
   
   public void clickClose()
   {
	   ua = new UserActions();
	   ua.click(clickclose);
   }
}
