package com.igt.pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;
import com.igt.utility.Util;

public class ManageSTQ extends TestSetup {

	UserActions ua = null;
	public WebDriver d;
	
	public ManageSTQ(WebDriver d) {

		this.d = d;

	}

	public final By ManageSTQ = By.cssSelector(p.getProperty("ManageSTQ_locator"));
	public final By GDSQueueConfiguration = By.cssSelector(p.getProperty("GDSQueueConfiguration_locator"));
	public final By AddNew = By.cssSelector(p.getProperty("AddNewGDS_locator"));
	public final By GDSQueueName = By.cssSelector(p.getProperty("GDSQueueName_locator"));
	public final By gdstype = By.cssSelector(p.getProperty("GDSType_locator"));
	public final By pos = By.cssSelector(p.getProperty("ManageSTQSelectPOS_locator"));
	public final By posiata = By.cssSelector(p.getProperty("POSIataNumber_locator"));
	public final By pcc = By.cssSelector(p.getProperty("SelectPCC_locator"));
	public final By ththour = By.cssSelector(p.getProperty("TargetTHTHour_locator"));
	public final By thtminute = By.cssSelector(p.getProperty("TargetTHTMinute_locator"));
	public final By gdstask = By.cssSelector(p.getProperty("SelectGDSTask_locator"));
	public final By gdssubtask = By.cssSelector(p.getProperty("SelectGDSSubTask_locator"));
	public final By timezone = By.cssSelector(p.getProperty("TimeZone_locator"));
	public final By durationHour = By.cssSelector(p.getProperty("DurationHour_locator"));
	public final By durationMinute = By.cssSelector(p.getProperty("DurationMinute_locator"));
	public final By submit = By.cssSelector(p.getProperty("Submit_locator"));
	public final By dropdownclickelement = By.cssSelector(p.getProperty("Skill_locator"));
	public final By already = By.xpath(p.getProperty("AlreadyExistError_locator"));
	public final By cancel = By.xpath(p.getProperty("CancelButton_locator"));
	public final By testconnection = By.cssSelector(p.getProperty("TestConnection_locator"));
	public final By queueNo = By.cssSelector(p.getProperty("QueueNo_locator"));
	public final By queueCategory = By.cssSelector(p.getProperty("QueueCategory_locator"));

	public void clickManageSTQ() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.Wait_Sec();
		ua.Click_JavaScript(ManageSTQ);
		ua.Wait_Sec();
	}

	public void clickGDSQueueConfiguration() {

		ua  = new UserActions();
		ua.click(GDSQueueConfiguration);

	}

	public void AddNew_Click() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(AddNew);
		ua.Wait_Sec();

	}

	public void enterGDSQueueName() throws IOException {
		
		ua  = new UserActions();
		String GDSQueue = ua.getCellData("UserData","GdsQueue",2);
		ua.SetValue(GDSQueueName, GDSQueue);
	}

	public void selectGDS() throws IOException {
		
		ua  = new UserActions();
		String GDSType = ua.getCellData("UserData","GdsType",2);
		//int gIndex = Integer.parseInt(GDSType);
		ua.SelectByOptionValue(gdstype,GDSType);
	}

	public void selectPOS() throws IOException {

		ua  = new UserActions();
		String PosName = ua.getCellData("UserData","PosName_GDSQueue",2);
		//UserActions.SelectValue(pos, PosName);
		ua.SelectByOptionValue(pos, PosName);
	}

	public void selectPOSIata() throws IOException {
		
		ua  = new UserActions();
		String PosIata = ua.getNumericFormulaCellData("UserData","PosIata",2);
		ua.SelectValue(posiata, PosIata);
	}

	public void selectPcc() throws IOException {

		ua  = new UserActions();
		String Pcc = ua.getCellData("UserData","Pcc_GDSQueue",2);
		ua.SelectValue(pcc, Pcc);

	}

	public void selectTargetTHT() throws IOException {

		ua  = new UserActions();
		String Hour = ua.getCellData("UserData","Hour",2);
		String Minute = ua.getCellData("UserData","Minute",2);
		ua.SelectValue(ththour, Hour);
		ua.SelectValue(thtminute,Minute);

	}

	public void selectTaskAndSubTask() throws IOException {

		ua  = new UserActions();
		String Task = ua.getCellData("UserData","Task",2);
		String Subtask = ua.getCellData("UserData","Subtask",2);
		ua.SelectByOptionValue(gdstask, Task);
		ua.SelectByOptionValue(gdssubtask, Subtask);
	}

	public void selectDuration() throws IOException {

		ua  = new UserActions();
		String Dhour = ua.getCellData("UserData","Dhour",2);
		String Dminute = ua.getCellData("UserData","Dminute",2);
		ua.SelectValue(durationHour, Dhour);
		ua.SelectValue(durationMinute, Dminute);
	}

	public void selectTimeZone() throws IOException {

		ua  = new UserActions();
		String TimeZone = ua.getCellData("UserData","TimeZone",2);
		ua.SelectValue(timezone, TimeZone);
	}

	public void selectSkill() throws InterruptedException, IOException {
		
		ua  = new UserActions();
		String Skilltype = ua.getCellData("UserData","Skilltype",2);
		ua.clickDynamicCssUsingScroll(Skilltype,dropdownclickelement);
	}

	public void clickTestConnection() throws IOException
	{
		ua  = new UserActions();
		if(ua.GetDisplayed(testconnection))
		{
			String qnumber = ua.getCellData("UserData","QueueNumber",2);
			String qcategory = ua.getCellData("UserData","QueueCategory",2);
			ua.SetValue(queueNo,qnumber );
			
			String value = ua.GetValue(queueCategory,"storeValue");
			//String s = UserActions.GetAttribute(queueCategory,"readonly");
			if(value.equals("C0"))
			{
			
				System.out.println("not editable");
				
			}
			else{
				
				ua.SetValue(queueCategory,qcategory);
				
			}
			
			ua.Click_JavaScript(testconnection);
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on TestConnection.");
			Util.TakeScreenShot(d, System.currentTimeMillis());
			
		}		
	}
	
	public void submit() {

		ua  = new UserActions();
		ua.click(submit);
		
		boolean isExist = ua.GetExistance(already);
		if(isExist)
		{
			ua.click(cancel);
		}
	}
	

}
