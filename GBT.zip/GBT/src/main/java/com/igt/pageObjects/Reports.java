package com.igt.pageObjects;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.igt.base.TestSetup;
import com.igt.utility.Const;
import com.igt.utility.UserActions;

public class Reports extends TestSetup {

	
	UserActions ua = null;
	String STARTDATE;
	String ENDDATE;
	String SDATE;
	String EDATE;
	LocalDate date;
    
	public WebDriver d;
	public Reports(WebDriver d) {

		this.d = d;

	}

	public final By report = By.cssSelector(p.getProperty("Reporting_locator"));
	public final By agentreport = By.cssSelector(p.getProperty("AgentReport_locator"));
	public final By site = By.cssSelector(p.getProperty("Site_locator"));
	public final By sitepartition = By.cssSelector(p.getProperty("SitePartition_locator"));
	public final By datefilter = By.cssSelector(p.getProperty("DateFilter_locator"));
	public final By sdate = By.cssSelector(p.getProperty("StartDate_locator"));
	public final By edate = By.cssSelector(p.getProperty("EndDate_locator"));
	public final By download = By.cssSelector(p.getProperty("Download_locator"));
	public final By agentperformance = By.cssSelector(p.getProperty("AgentPerformance_locator"));
	public final By posSelection = By.cssSelector(p.getProperty("selectpos_locator"));
	public final By downloadButton = By.cssSelector(p.getProperty("DownloadButton_locator"));
	public final By workitemdetails = By.cssSelector(p.getProperty("WorkItemDetails_locator"));
	public final By ondatetype = By.cssSelector(p.getProperty("OnDateType_locator"));
	public final By workitemtype = By.cssSelector(p.getProperty("WorkItemType_locator"));
	public final By taskname = By.cssSelector(p.getProperty("selectTaskName_locator"));
	public final By SLACompliance = By.cssSelector(p.getProperty("SLACompliance_locator"));
	public final By stask = By.cssSelector(p.getProperty("taskSelect_locator"));
	public final By sSTQ = By.cssSelector(p.getProperty("SelectSTQ_locator"));
	public final By singleworkitem = By.cssSelector(p.getProperty("SingleWorkItem_locator"));
	public final By workitemid = By.cssSelector(p.getProperty("WorkItemId_locator"));
	public final By pnr = By.cssSelector(p.getProperty("PNR_locator"));
	public final By escalatedworkitem = By.cssSelector(p.getProperty("EscalatedWorkItem_locator"));

	
	
	
	
	/**
	 * @author S.Panigrahi
	 * Clicking on report menu
	 *
	 */
	public void clickReporting() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(report);

	}
	
	
	/**
	 * @author S.Panigrahi
	 * Clicking on agent report
	 *
	 */

	public void clickAgentReport() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(agentreport);

	}
	
	
	/**
	 * Select vendor from the dropdown
	 * @param SITE
	 * @throws IOException 
	 */

	public void selectSite() throws IOException {

		ua  = new UserActions();
		String arsite = ua.getCellData("UserData","Site_AgentReport",2);
		ua.SelectValue(site, arsite);

	}
	
	public void selectSite_AgentPerformance() throws IOException {

		ua  = new UserActions();
		String apsite = ua.getCellData("UserData","Site_AgentPerformanceReport",2);
		ua.SelectValue(site, apsite);

	}
	
	public void selectSite_SLACompliance() throws IOException {

		ua  = new UserActions();
		String slasite = ua.getCellData("UserData","Site_SLAComplianceReport",2);
		ua.SelectValue(site, slasite);

	}
	
	public void selectSite_EscalatedWorkItem() throws IOException {

		ua  = new UserActions();
		String escsite = ua.getCellData("UserData","Site_EscalatedWorkItemReport",2);
		ua.SelectValue(site,escsite);

	}
	
	public void selectSite_WorkItemDetails() throws IOException {

		ua  = new UserActions();
		String wisite = ua.getCellData("UserData","Site_WorkItemDetailsReport",2);
		ua.SelectValue(site,wisite);

	}
	
	
	
	/**
	 * Select vendor partition from the dropdown
	 * @param SITEPARTITION
	 * @throws IOException 
	 */

	public void selectSitePartions() throws IOException {

		ua  = new UserActions();
		String arsitepartition = ua.getCellData("UserData","SitePartition_AgentReport",2);
		ua.SelectValue(sitepartition,arsitepartition );

	}
	
	public void selectSitePartions_AgentPerformance() throws IOException {

		ua  = new UserActions();
		String apsitepartition = ua.getCellData("UserData","SitePartition_AgentPerformanceReport",2);
		ua.SelectValue(sitepartition,apsitepartition );
	}
	
	public void selectSitePartions_SLACompliance() throws IOException {

		ua  = new UserActions();
		String slasitepartition = ua.getCellData("UserData","SitePartition_SLAComplianceReport",2);
		ua.SelectValue(sitepartition,slasitepartition );
	}
	
	public void selectSitePartions_EscalatedWorkItem() throws IOException {

		ua  = new UserActions();
		String escsitepartition = ua.getCellData("UserData","SitePartition_EscalatedWorkItemReport",2);
		ua.SelectValue(sitepartition,escsitepartition );
	}
	
	public void selectSitePartions_WorkItemDetails() throws IOException {

		ua  = new UserActions();
		String wisitepartition = ua.getCellData("UserData","SitePartition_WorkItemDetailsReport",2);
		ua.SelectValue(sitepartition,wisitepartition);
	}

	/**
	 * select start date and end date if date type is past date
	 * @param DateType
	 * @throws IOException 
	 */
	
	public void selectDateType() throws IOException

	{
		ua  = new UserActions();
		String ardatetype = ua.getCellData("UserData","DateType_AgentReport",2);
		ua.SelectValue(datefilter, ardatetype);
		if (ardatetype.equals(Const.PAST_DATE)) {
			ua.Wait_Sec();
			WebElement input_Sdate = d.findElement(By.xpath("//input[@name='reportBean.startDate']"));
			ua.Wait_Sec();
			JavascriptExecutor executor = (JavascriptExecutor) d;
			executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Sdate);

			LocalDate date = LocalDate.now();
			System.out.println("Date: " + date);

			LocalDate local = date.minusDays(30);
			System.out.println("New Date: " + local);
			STARTDATE = local.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

			input_Sdate.sendKeys(STARTDATE);

			ua.Wait_Sec();

			WebElement input_Edate = d.findElement(By.xpath("//input[@name='reportBean.endDate']"));
			ua.Wait_Sec();
			executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Edate);

			LocalDate edate = date.minusDays(10);
			System.out.println("New Date: " + edate);
			ENDDATE = edate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

			input_Edate.sendKeys(ENDDATE);

		}

	}
	
	public void selectDateType_AgentPerformance() throws IOException

	{

		String apdatetype = ua.getCellData("UserData","DateFilter_AgentPerformanceReport",2);
		ua.SelectValue(datefilter, apdatetype);
		if (apdatetype.equals(Const.PAST_DATE)) {
			ua.Wait_Sec();
			WebElement input_Sdate = d.findElement(By.xpath("//input[@name='reportBean.startDate']"));
			ua.Wait_Sec();
			JavascriptExecutor executor = (JavascriptExecutor) d;
			executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Sdate);

			LocalDate date = LocalDate.now();
			System.out.println("Date: " + date);

			LocalDate local = date.minusDays(30);
			System.out.println("New Date: " + local);
			STARTDATE = local.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

			
			input_Sdate.sendKeys(STARTDATE);

			ua.Wait_Sec();

			WebElement input_Edate = d.findElement(By.xpath("//input[@name='reportBean.endDate']"));
			ua.Wait_Sec();
			executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Edate);

			LocalDate edate = date.minusDays(16);
			System.out.println("New Date: " + edate);
			ENDDATE = edate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

			input_Edate.sendKeys(ENDDATE);

		}

	}
	
	
	
	public void selectDateType_SLACompliance() throws IOException

	{
		ua  = new UserActions();
		String sladatetype = ua.getCellData("UserData","DateType_SLAComplianceReport",2);
		ua.SelectValue(datefilter, sladatetype);
		if (sladatetype.equals(Const.PAST_DATE)) {
			ua.Wait_Sec();
			WebElement input_Sdate = d.findElement(By.xpath("//input[@name='reportBean.startDate']"));
			ua.Wait_Sec();
			JavascriptExecutor executor = (JavascriptExecutor) d;
			executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Sdate);

			LocalDate date = LocalDate.now();
			System.out.println("Date: " + date);

			LocalDate local = date.minusDays(30);
			System.out.println("New Date: " + local);
			STARTDATE = local.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

			input_Sdate.sendKeys(STARTDATE);

			ua.Wait_Sec();

			WebElement input_Edate = d.findElement(By.xpath("//input[@name='reportBean.endDate']"));
			ua.Wait_Sec();
			executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Edate);

			LocalDate edate = date.minusDays(10);
			System.out.println("New Date: " + edate);
			ENDDATE = edate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

			input_Edate.sendKeys(ENDDATE);

		}

	}

	
	/**
	 * Click on download button
	 */
	public void clickDownload() {
		
		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(download);
		ua.Wait_Sec();
	}

	/*
	 * public void fetchExcelData() {
	 * 
	 * String value = UserActions.readExcel(System.getProperty("user.dir")+
	 * "\\Config\\AgentDetailsReport_04-01-2022_04-01-2022.xlsx",1,1);
	 * ExtentCucumberAdapter.addTestStepLog("Site name is"+"  "+value);
	 * 
	 * 
	 * }
	 */

	/**
	 * Click on agent performance report
	 */
	
	public void clickAgentPerformance() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(agentperformance);

	}

	/**
	 * Select POS from the dropdown or list
	 * @param POS
	 * @throws IOException 
	 */
	
	
	public void select_pos() throws IOException {

		ua  = new UserActions();
		String apPos = ua.getCellData("UserData","Pos_AgentPerformanceReport",2);
		ua.SelectValue(posSelection, apPos);
	}

	/**
	 * Click on download button
	 */
	public void download() {

		ua  = new UserActions();
		ua.click(downloadButton);

	}

	/**
	 * Click on work item details
	 */
	
	public void click_WorkItemDetails() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.Click_JavaScript(workitemdetails);
		ua.Wait_Sec();

	}
	
	/**
	 * select value from ondatetype dropdown
	 * @param ONDATETYPE
	 * @throws IOException 
	 */

	public void selectOnDateType() throws IOException {
        
		ua  = new UserActions();
		String ONDATETYPE = ua.getCellData("UserData","OnDateType_WorkItemDetailsReport",2);
		ua.SelectValue(ondatetype, ONDATETYPE);
	}
	
	/**
	 * select work item type from the dropdown
	 * @param WORKITEMTYPE
	 * @throws IOException 
	 */

	public void selectWorkItemType() throws IOException {

		ua  = new UserActions();
		Boolean isAvailable = d.findElement(workitemtype).isDisplayed();
		if (isAvailable) {
			String WORKITEMTYPE = ua.getCellData("UserData","WorkItemType_WorkItemDetailsReport",2);
			ua.SelectValue(workitemtype, WORKITEMTYPE);
		}

	}

	/**
	 * select task from the list
	 * @param TASK
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	
	
	public void selectTask() throws InterruptedException, IOException {

		ua  = new UserActions();
		String TASK = ua.getCellData("UserData","Task_WorkItemDetailsReport",2);
		ua.dynamicxpath(TASK);

	}
	
	public void selectSubTask() throws InterruptedException, IOException {

		ua  = new UserActions();
		String SUBTASK = ua.getCellData("UserData","SubTask_WorkItemDetailsReport",2);
		ua.dynamicxpath(SUBTASK);

	}
	
	
	/**
	 * Enter past date for StartDate and EndDate field
	 * @param DateFilter
	 * @throws IOException 
	 */

	public void selectDateByDateType_WorkItemDetails() throws IOException

	{
		ua  = new UserActions();
		Boolean isAvailable = d.findElement(datefilter).isDisplayed();
		if (isAvailable) {
			String DateFilter = ua.getCellData("UserData","DateFilter_WorkItemDetailsReport",2);
			ua.SelectValue(datefilter, DateFilter);

			if (DateFilter.equals(Const.PAST_DATE)) {
				ua.Wait_Sec();
				WebElement input_Sdate = d.findElement(By.xpath("//input[@name='reportBean.startDate']"));
				ua.Wait_Sec();
				JavascriptExecutor executor = (JavascriptExecutor) d;
				executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Sdate);

				date = LocalDate.now();
				// displaying date
				System.out.println("Date: " + date);

				LocalDate local = date.minusDays(15);
				System.out.println("New Date: " + local);
				SDATE = local.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

				input_Sdate.sendKeys(SDATE);

				LocalDate edate = date.minusDays(5);
				System.out.println("New Date: " + edate);
				EDATE = edate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

				ua.Wait_Sec();
				WebElement input_Edate = d.findElement(By.xpath("//input[@name='reportBean.endDate']"));
				ua.Wait_Sec();
				executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", input_Edate);

				input_Edate.sendKeys(EDATE);

			}

		}

		else {

			Boolean isExist = ua.GetExistance(sdate);
			ua.Wait_Sec();
			if (isExist) {
				WebElement w = d.findElement(sdate);
				JavascriptExecutor executor = (JavascriptExecutor) d;
				executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", w);
				date = LocalDate.now();
				LocalDate local = date.minusDays(15);
				System.out.println("New Date: " + local);
				SDATE = local.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

				ua.SetValue(sdate, SDATE);
			}

			isExist = ua.GetExistance(edate);
			ua.Wait_Sec();
			if (isExist) {
				WebElement w1 = d.findElement(edate);
				JavascriptExecutor executor = (JavascriptExecutor) d;
				executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", w1);

				LocalDate ldate = date.minusDays(5);
				System.out.println("New Date: " + ldate);
				EDATE = ldate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

				ua.SetValue(edate, EDATE);
			}

		}

	}
	
	/**
	 * select a particular radio button from the list
	 * @param Task
	 * @throws InterruptedException
	 * @throws IOException 
	 */

	public void clickRadioButton() throws InterruptedException, IOException {

		ua  = new UserActions();
		String Task = ua.getCellData("UserData","SelectRadio_SLAComplianceReport",2);
		ua.dynamicxpathUsingAttribute(Task);

	}
	
	/**
	 * select a particular value from the dropdown
	 * @param SelectDropdownValue
	 * @throws IOException 
	 */

	public void selectValueFromDropdown() throws IOException {
		
		ua  = new UserActions();
		String SelectDropdownValue = ua.getCellData("UserData","SelectTask/Stq_SLAComplianceReport",2);
		Boolean isAvailable = d.findElement(stask).isDisplayed();
		if (isAvailable) {
			ua.SelectValue(stask, SelectDropdownValue);
		}
		isAvailable = d.findElement(sSTQ).isDisplayed();
		if (isAvailable) {
			ua.SelectValue(sSTQ, SelectDropdownValue);
		}
	}

	
	/**
	 * 
	 * select a particular checkbox from the list
	 * @param SelectCheckbox
	 * @throws InterruptedException
	 * @throws IOException 
	 */
	
	public void selectValueFromCheckbox() throws InterruptedException, IOException {

		ua  = new UserActions();
		String SelectCheckbox = ua.getCellData("UserData","SelectSubTask/Astq_SLAComplianceReport",2);
		//UserActions.dynamicxpath(SelectCheckbox);
		ua.clickXpathUsingTextByJavaScript(SelectCheckbox);
	}
	
	public void selectValueFromCheckboxes() throws InterruptedException, IOException {

		ua  = new UserActions();
		String SelectCheckbox = ua.getCellData("UserData","SelectAstq_EscalatedWorkItemReport",2);
		//UserActions.dynamicxpath(SelectCheckbox);
		ua.clickXpathUsingTextByJavaScript(SelectCheckbox);
	}
	
	/**
	 * click on single work item report
	 */

	public void click_SingleWorkItem() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.Click_JavaScript(singleworkitem);
		ua.Wait_Sec();

	}
	
	/**
	 * Enter value to WorkId and PNR field
	 * @param WORKID
	 * @param PNR
	 * @throws IOException 
	 */

	public void enterWorkItemIdAndPnr() throws IOException {

		ua  = new UserActions();
		String WorkId = ua.getCellData("UserData","WorkId_SingleWorkItemReport",2);
		String  Pnr = ua.getCellData("UserData","Pnr_SingleWorkItemReport",2);
		ua.SetValue(workitemid,WorkId);
		ua.SetValue(pnr, Pnr);

	}

	/**
	 * click on SLACompliance
	 * 
	 */
	
	public void click_SLACompliance() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(SLACompliance);
		ua.Wait_Sec();

	}
	
	/**
	 * click on escalated work item report
	 * 
	 */
	
	public void click_EscalatedWorkItem() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(escalatedworkitem);
		ua.Wait_Sec();

	}
	
	/**
	 * Enter past date for StartDate and EndDate field
	 * @param DateFilter
	 *
	 */
	
	public void selectDateByDateType()

	{
		    ua  = new UserActions();
			Boolean isExist = ua.GetExistance(sdate);
			ua.Wait_Sec();
			if (isExist) {
				WebElement w = d.findElement(sdate);
				JavascriptExecutor executor = (JavascriptExecutor) d;
				executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", w);
				date = LocalDate.now();
				LocalDate local = date.minusDays(15);
				System.out.println("New Date: " + local);
				SDATE = local.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

				ua.SetValue(sdate, SDATE);
			}

			isExist = ua.GetExistance(edate);
			ua.Wait_Sec();
			if (isExist) {
				WebElement w1 = d.findElement(edate);
				JavascriptExecutor executor = (JavascriptExecutor) d;
				executor.executeScript("arguments[0].removeAttribute('readonly','readonly')", w1);

				LocalDate ldate = date.minusDays(5);
				System.out.println("New Date: " + ldate);
				EDATE = ldate.format(DateTimeFormatter.ofPattern("MM-dd-yyyy"));

				ua.SetValue(edate, EDATE);
			}

		}
	
	/**
	 * Select STQ from the dropdown
	 * @param SelectDropdownValue
	 * @throws IOException 
	 */
	public void selectSTQ() throws IOException {

		    ua  = new UserActions();
		    String  SelectDropdownValue = ua.getCellData("UserData","SelectStq_EscalatedWorkItemReport",2);
			ua.SelectValue(sSTQ, SelectDropdownValue);
	}


}
