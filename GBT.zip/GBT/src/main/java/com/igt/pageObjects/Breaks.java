package com.igt.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class Breaks extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;
	
	public Breaks(WebDriver d)
	{
		this.d=d;
	}
	
	public final By clickMyprofile = By.cssSelector(p.getProperty("AgentClickMyProfile_locator"));
	public final By mydashboard = By.id(p.getProperty("MyDashboard_locator"));
	public final By splprojectinitiated = By.cssSelector(p.getProperty("SplProjectInitiated_locator"));
	public final By traininginitiated = By.cssSelector(p.getProperty("TrainingInitiated_locator"));
	public final By meeting = By.cssSelector(p.getProperty("Meeting_locator"));
	public final By coaching = By.cssSelector(p.getProperty("Coaching_locator"));
	public final By schedulebreak = By.cssSelector(p.getProperty("ScheduleBreak_locator"));
	public final By unschedulebreak = By.cssSelector(p.getProperty("UnscheduleBreak_locator"));
	public final By notreadyressupport = By.cssSelector(p.getProperty("NotReadyResSupport_locator"));
	public final By notreadypcproblem = By.cssSelector(p.getProperty("NotReadyPCProblem_locator"));
	public final By notreadyotherdepartment = By.cssSelector(p.getProperty("NotReadyOtherDepartment_locator"));
	public final By lunchbreak = By.cssSelector(p.getProperty("LunchBreak_locator"));
	
	
	public void clickSplprojectInitiated()
	{
		ua  = new UserActions();
		Boolean isExist = ua.GetExistance(splprojectinitiated);
		if(isExist)
		{
		ua.click(splprojectinitiated);
		}
		else{
			ua.click(clickMyprofile);
			ua.click(mydashboard);
			ua.click(splprojectinitiated);
		}
	}
	
	public void clickTrainingInitiated()
	{
		ua  = new UserActions();
		ua.click(traininginitiated);
	}
	
	public void clickMeeting()
	{
		ua  = new UserActions();
		ua.click(meeting);
	}
	
	public void clickCoaching()
	{
		ua  = new UserActions();
		ua.click(coaching);
	}
	
	public void clickScheduleBreak()
	{
		ua  = new UserActions();
		ua.click(schedulebreak);
	}
	
	public void clickUnScheduleBreak()
	{
		ua  = new UserActions();
		ua.click(unschedulebreak);
	}
	
	public void clickNotReadyResSupport()
	{
		ua  = new UserActions();
		ua.click(notreadyressupport);
	}
	
	public void clickNotReadyPCProblem()
	{
		ua  = new UserActions();
		ua.click(notreadypcproblem);
	}
	
	public void clickNotReadyOtherDepartment()
	{
		ua  = new UserActions();
		ua.click(notreadyotherdepartment);
	}
	
	public void clickLunch()
	{
		ua  = new UserActions();
		ua.click(lunchbreak);
	}
	
	

}
