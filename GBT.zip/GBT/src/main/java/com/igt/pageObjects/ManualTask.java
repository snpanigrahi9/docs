package com.igt.pageObjects;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class ManualTask extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;

	public ManualTask(WebDriver d) {
		this.d = d;
	}
	
	public final By manualtask = By.cssSelector(p.getProperty("ManualTask_locator"));
	public final By astq = By.cssSelector(p.getProperty("SelectAstq_locator"));
	public final By nextitem = By.cssSelector(p.getProperty("NextItem_locator"));
	
	public final By filter = By.cssSelector(p.getProperty("filter_locator"));
	public final By generalinfo = By.cssSelector(p.getProperty("generalInfo_locator"));
	public final By completeworkitem = By.id(p.getProperty("completeWorkItem_locator"));
	public final By pnr = By.id(p.getProperty("getPNR_locator"));
	public final By pause = By.cssSelector(p.getProperty("pause_locator"));
	public final By submit = By.cssSelector(p.getProperty("submit_locator"));
	public final By delay = By.cssSelector(p.getProperty("delay_locator"));
	public final By delayremarks = By.cssSelector(p.getProperty("delayRemarks_locator"));
	public final By submitdelay = By.cssSelector(p.getProperty("submitDelay_locator"));
	public final By close = By.cssSelector(p.getProperty("CloseButton"));
	public final By breaks = By.cssSelector(p.getProperty("breaks_locator"));
	public final By submitbreaks = By.cssSelector(p.getProperty("submitBreaks_locator"));
	public final By escalate = By.cssSelector(p.getProperty("escalate_locator"));
	public final By escalateRemark = By.cssSelector(p.getProperty("escalateRemark_locator"));
	public final By submitescalate = By.cssSelector(p.getProperty("submitEscalate_locator"));
	public final By resume = By.cssSelector(p.getProperty("resume_locator"));
	public final By clickprofile = By.cssSelector(p.getProperty("Profile_locator"));
	public final By clickdashboard = By.cssSelector(p.getProperty("MDashboard_locator"));
	public final By getText_SubAction = By.cssSelector(p.getProperty("getSubaction_locator"));
	public final By closeSubactionPopUp = By.cssSelector(p.getProperty("closeSubactions_locator"));
	public final By selectAllsubactions = By.cssSelector(p.getProperty("selectAllSubaction_locator"));
	
	public void clickManualTask()
	{
		ua  = new UserActions();
		Boolean isExist = ua.GetExistance(manualtask);
		if(isExist)
		{
		ua.Wait_Sec();
		ua.click(manualtask);
		}
		else{
			ua.click(clickprofile);
			ua.Wait_Sec();
			ua.click(clickdashboard);
			ua.Wait_Sec();
			ua.click(manualtask);
		}
	}
	
	public void selectASTQ() throws IOException
	{
		ua  = new UserActions();
		String selectAstq = ua.getCellData("AgentRoleData","ASTQ",2);
		ua.SelectValue(astq,selectAstq);
	}
	
	public void clickNextItem()
	{
		ua  = new UserActions();
		ua.click(nextitem);
		ua.Wait_Sec();
	}
	
	public void selectFilter() throws IOException
	{
		 ua  = new UserActions();
		//String getpnr = UserActions.getText(pnr);
		 Boolean isPNRExist = ua.GetExistance(pnr);
		 Boolean isFilter_Exist = ua.GetExistance(filter);
		if(isPNRExist && isFilter_Exist)
		{
		String filterValue = ua.getCellData("AgentRoleData","Filter_DrpdownValue",2);
		ua.SelectValue(filter,filterValue);
		}
		else{
			Assert.fail("No PNR exist");
		}
	}
	public void selectGeneralInfo() throws IOException
	{
		ua  = new UserActions();
		Boolean isGeneralInfoExist = ua.GetExistance(generalinfo);
		if(isGeneralInfoExist)
		{
			String generalInfoValue = ua.getCellData("AgentRoleData","GeneralInfo_DrpdownValue",2);
			ua.SelectValue(generalinfo,generalInfoValue);	
		}
	}
	
	public void clickCompleteWorkItem()
	{
		ua  = new UserActions();
		ua.Click_JavaScript(completeworkitem);
	}
	
	public void clickDiagnostics() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String diagnostics = ua.getCellData("AgentRoleData","Diagnostics",2);
		ua.DynamicXpathUsingTextByJavaScript(diagnostics);
	}
	
/*	public void clickActions() throws IOException, InterruptedException
	{
		String action = UserActions.getCellData("AgentRoleData","Actions_ManualTask",2);
		UserActions.xpathUsingTextByJavaScript(action);
	}*/
	
	public void clickActions() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String action = ua.getCellData("AgentRoleData","Actions_ManualTask",2);
		ua.Wait_Sec();
		ua.xpathUsingTextByJavaScript(action);
		 Boolean isExist_NoSubAction = ua.GetExistance(getText_SubAction);
		   if(isExist_NoSubAction)
		   {
			Boolean SubAction = ua.getText(getText_SubAction).contains("No Subaction");
			if(SubAction)
			{
				ua.click(closeSubactionPopUp);
			}
			else{
				   ua.CheckAllCheckbox(selectAllsubactions);
				   ua.Wait_Sec();
				   ua.click(closeSubactionPopUp);
			}
		   }
	}
	
	public void clickPause()
	{
		ua  = new UserActions();
		ua.click(pause);
	}
	
	public void clickSubmit()
	{
		ua  = new UserActions();
		ua.click(submit);
	}
	
	public void clickDelay()
	{
		ua  = new UserActions();
		ua.click(delay);
	}
	
	
	public void selectDelayDateTime()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		WebElement delayDateTime = d.findElement(By.cssSelector("input[name='workitemBean.delayDate']"));
		ua.Wait_Sec();
		JavascriptExecutor executor = (JavascriptExecutor) d;
		executor.executeScript("arguments[0].removeAttribute('readonly','readonly')",delayDateTime );

		LocalDate date = LocalDate.now();
		System.out.println("Date: " + date);

		LocalDate local = date.plusDays(1);
		System.out.println("New Date: " + local);
		String delaydate = local.format(DateTimeFormatter.ofPattern("dd-MM-yyyy"));
		delayDateTime.sendKeys(delaydate);
		
	}
	
	public void enterDelayRemarks() throws IOException
	{
		ua  = new UserActions();
		String dremarks = ua.getCellData("AgentRoleData","DelayRemark",2);
		ua.click(delayremarks);
		ua.SetValue(delayremarks,dremarks);
	}
	
	public void clickDelaySubmit()
	{
		ua  = new UserActions();
		ua.click(submitdelay);
	}
	
	public void clickClose()
	{
		ua  = new UserActions();
		ua.click(close);
	}
	
	public void clickBreaks()
	{
		ua  = new UserActions();
		ua.click(breaks);
	}
	
	public void selectBreakType() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String btype = ua.getCellData("AgentRoleData","BreakType",2);
		ua.xpathUsingTextByJavaScript(btype);
	}
	
	public void clickBreaksSubmit()
	{
		ua  = new UserActions();
		ua.click(submitbreaks);
	}
	
	public void clickResume()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		ua.click(resume);
	}
	
	public void clickEscalate()
	{
		ua  = new UserActions();
		ua.click(escalate);
	}
	
	public void enterEscalateRemark() throws IOException
	{
		ua  = new UserActions();
		String eremark = ua.getCellData("AgentRoleData","EscalateRemark",2);
		ua.SetValue(escalateRemark,eremark);
	}
	
	public void clickEscalateSubmit()
	{
		ua  = new UserActions();
		ua.click(submitescalate);
	}
}
