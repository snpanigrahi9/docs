package com.igt.pageObjects;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;
import com.igt.utility.Util;

public class AllocateGDSQueueToSitepartition extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;
	
	public AllocateGDSQueueToSitepartition(WebDriver d)
	{	
		this.d = d;
	}
	
	public final By allocategdsqueue = By.cssSelector(p.getProperty("AllocateGdsQueue_locator"));
	public final By selectsite = By.cssSelector(p.getProperty("SelectSite_locator"));
	public final By selectsitepartition = By.cssSelector(p.getProperty("SelectSitePartition_locator"));
	public final By clicksearch = By.cssSelector(p.getProperty("clickSearch_locator"));
	public final By mapselectedgdsqueue = By.cssSelector(p.getProperty("MapSelectedGDSQueue_locator"));
	public final By confirmdelete = By.cssSelector(p.getProperty("ConfirmDelete_locator"));
	public final By cannot_delete = By.cssSelector(p.getProperty("CannotDelete_locator"));
	public final By systemInformation_close = By.cssSelector(p.getProperty("SystemInformationClose_locator"));
	
	public void clickAllocateGDSQueueToSitePartition()
	{
		ua  = new UserActions();
		Boolean isDisplayed = ua.GetDisplayed(allocategdsqueue);
		if(isDisplayed)
		{
			ua.click(allocategdsqueue);
		}
		
	}
	
	
	public void selectSiteAndSitePartition() throws IOException
	{
		ua  = new UserActions();
		String site = ua.getCellData("UserData","Site_AllocateGDSQueues",2);
		ua.SelectValue(selectsite,site);
		String sitepartition = ua.getCellData("UserData","SitePartition_AllocateGDSQueues",2);
		ua.SelectValue(selectsitepartition,sitepartition);
	}
	
	public void clickSearchButton()
	{
		ua  = new UserActions();
		ua.click(clicksearch);
	}
	
	public void mapNewGDSQueues() throws IOException
	{
		ua  = new UserActions();
		String checkboxnumber = ua.getCellData("UserData","MapNewGDSQueue_CheckboxNo",2);
		int checkbox_No = Integer.parseInt(checkboxnumber);
		List<WebElement>allCheckbox = d.findElements(By.cssSelector("input[name='vendorPartGdsQueueMapBean.gdsQueueConfigIds']"));
		allCheckbox.get(checkbox_No).click();
	}
	
	public void mapSelectedGDSQueue()
	{
		ua  = new UserActions();
		ua.click(mapselectedgdsqueue);
	}
	
	public void deleteGDSQueueCurrentlyMapped() throws IOException
	{
		ua  = new UserActions();
		String buttonnumber = ua.getCellData("UserData","DeleteGDSQueue_ButtonNo",2);
		int button_No = Integer.parseInt(buttonnumber);
		List<WebElement>allDeleteButton = d.findElements(By.cssSelector("a[title='Delete']"));
		allDeleteButton.get(button_No).click();
	}
	
	public void confirmDelete()
	{
		ua  = new UserActions();
		ua.click(confirmdelete);
		Boolean isExit_CannotDelete = ua.GetDisplayed(cannot_delete);
		if(isExit_CannotDelete)
		{
			Util.TakeScreenShot(d, System.currentTimeMillis());
			ua.click(systemInformation_close);
			ExtentCucumberAdapter.addTestStepLog("Queue cannot be deleted.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Successfully clicked on confirm from the delete dialog.");
		}
	}
	

}
