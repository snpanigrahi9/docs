package com.igt.pageObjects;

import java.awt.AWTException;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.github.javafaker.Faker;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

import io.cucumber.java.en.When;

public class ManageMasterData extends TestSetup {

	String tcode;
	UserActions ua = null;
	public WebDriver d;
	public ManageMasterData(WebDriver d) {
		this.d = d;

	}

	public final By MasterData = By.cssSelector(p.getProperty("ManageMasterData_locator"));
	public final By task = By.cssSelector(p.getProperty("Task_locator"));
	public final By Addnew = By.cssSelector(p.getProperty("AddNew_locator"));
	public final By taskcode = By.cssSelector(p.getProperty("TaskCode_locator"));
	public final By taskname = By.cssSelector(p.getProperty("TaskName_locator"));
	public final By submit = By.cssSelector(p.getProperty("Submit_locator"));
	public final By popupok = By.cssSelector(p.getProperty("TaskcreatedOK_locator"));
	public final By subtaskpopupok = By.cssSelector(p.getProperty("SubTaskcreatedOK_locator"));
	public final By actionpopupok = By.cssSelector(p.getProperty("ActioncreatedOK_locator"));
	public final By subactionpopupok = By.cssSelector(p.getProperty("SubActioncreatedOK_locator"));
	public final By brandpopupok = By.cssSelector(p.getProperty("BrandcreatedOK_locator"));
	public final By agentskillpopupok = By.cssSelector(p.getProperty("AgentSkillcreatedOK_locator"));
	public final By languageskillpopupok = By.cssSelector(p.getProperty("LanguageSkillcreatedOK_locator"));
	public final By mappingpopupok = By.cssSelector(p.getProperty("MappingcreatedOK_locator"));
	public final By pospopupok = By.cssSelector(p.getProperty("PoscreatedOK_locator"));
	public final By pccpopupok = By.cssSelector(p.getProperty("PcccreatedOK_locator"));
	public final By gdspopupok = By.cssSelector(p.getProperty("GdscreatedOK_locator"));
	
	
	
	public final By subtask = By.cssSelector(p.getProperty("Subtasks_locator"));
	public final By subtaskcode = By.cssSelector(p.getProperty("SubtaskCode_locator"));
	public final By subtaskname = By.cssSelector(p.getProperty("SubtaskName_locator"));
	public final By TaskSuccessText = By.cssSelector(p.getProperty("TaskSuccess_locator"));
	public final By action = By.cssSelector(p.getProperty("Action_locator"));
	public final By actioncode = By.cssSelector(p.getProperty("ActionCode_locator"));
	public final By actionname = By.cssSelector(p.getProperty("ActionName_locator"));
	public final By subaction = By.cssSelector(p.getProperty("SubAction_locator"));
	public final By subactionCode = By.cssSelector(p.getProperty("SubActionCode_locator"));
	public final By subactionName = By.cssSelector(p.getProperty("SubActionName_locator"));
	public final By maptasksubtaskaction = By.cssSelector(p.getProperty("MapTaskSubtaskAction_locator"));
	public final By selecttask = By.cssSelector(p.getProperty("SelectTask_locator"));
	public final By mapsubtask = By.cssSelector(p.getProperty("MapSubtask_locator"));
	public final By selectsubtask = By.cssSelector(p.getProperty("SelectSubtask_locator"));
	public final By clickaction = By.xpath(p.getProperty("ClickAction_locator"));
	public final By pos = By.cssSelector(p.getProperty("Pos_locator"));
	public final By poscode = By.cssSelector(p.getProperty("PosCode_locator"));
	public final By posname = By.cssSelector(p.getProperty("PosName_locator"));
	public final By country = By.cssSelector(p.getProperty("SelectCountry_locator"));
	public final By brand = By.cssSelector(p.getProperty("Brand_locator"));
	public final By currency = By.cssSelector(p.getProperty("Currency_locator"));
	public final By langid = By.cssSelector(p.getProperty("ClickLangId_locator"));
	public final By addnewiata = By.cssSelector(p.getProperty("AddNewIata_locator"));
	public final By iatanumber = By.cssSelector(p.getProperty("IataNumber_locator"));
	public final By confirmiata = By.cssSelector(p.getProperty("ConfirmIata_locator"));
	public final By pccconfiguration = By.cssSelector(p.getProperty("PccConfiguration_locator"));
	public final By selectpos = By.cssSelector(p.getProperty("SelectPOS_locator"));
	public final By selectgds = By.cssSelector(p.getProperty("SelectGDS_locator"));
	public final By pcc = By.cssSelector(p.getProperty("Pcc_locator"));
	public final By nodata = By.cssSelector(p.getProperty("NoData_locator"));

	public final By agentskills = By.cssSelector(p.getProperty("AgentSkills_locator"));
	public final By agentskillcode = By.cssSelector(p.getProperty("AgentSkillCode_locator"));
	public final By agentskillname = By.cssSelector(p.getProperty("AgentSkillName_locator"));
	public final By languageskills = By.cssSelector(p.getProperty("LanguageSkills_locator"));
	public final By languagecode = By.cssSelector(p.getProperty("LanguageCode_locator"));
	public final By languagename = By.cssSelector(p.getProperty("LanguageName_locator"));
	public final By already = By.cssSelector(p.getProperty("AlreadyError_locator"));
	public final By cancel = By.xpath(p.getProperty("CancelButton_locator"));
	public final By cancelBrand = By.cssSelector(p.getProperty("CancelButtonBrand_locator"));
	
	
	public final By brands = By.cssSelector(p.getProperty("BrandsMenu_locator"));
	public final By brandcode = By.cssSelector(p.getProperty("BrandCode_locator"));
	public final By brandname = By.cssSelector(p.getProperty("BrandName_locator"));
	public final By countries = By.xpath(p.getProperty("Countries_locator"));
	public final By regionname = By.xpath(p.getProperty("RegionName_locator"));
	public final By countrycode = By.xpath(p.getProperty("CountryCode_locator"));
	public final By countryname = By.xpath(p.getProperty("CountryName_locator"));
	
	
	
	public void ClickManageMasterData() {

		ua  = new UserActions();
		ua.Click_JavaScript(MasterData);

	}

	public void ClickTask() throws InterruptedException {

		ua  = new UserActions();
		boolean isVisible = ua.GetDisplayed(task);
		if(isVisible)
		{
			ua.Wait_Sec();
			ua.Click_JavaScript(task);
		}
		else{
			ua.click(MasterData);
			ua.Wait_Sec();
        	ua.Click_JavaScript(task);
		}
	}

	public void ClickAddNew() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.Click_JavaScript(Addnew);

	}

	public String enterNewTaskCode() throws IOException {
		ua  = new UserActions();
		tcode = ua.getCellData("UserData","TaskCode",2);
		ua.SetValue(taskcode, tcode);
		return tcode;
	}

	public void enterNewTaskName() throws IOException {
		ua  = new UserActions();
		String tname = ua.getCellData("UserData","TaskName",2);
		ua.SetValue(taskname,tname);
	}

	public void clickSubmit() {
		
		ua  = new UserActions();
		ua.Click_JavaScript(submit);
		ua.Wait_Sec();
		boolean isExist = ua.GetDisplayed(already);
		if(isExist)
		{
			ua.Wait_Sec();
			ua.Click_JavaScript(cancel);
		}
	}
	
	public void clickSubmitBrand() {
		
		ua  = new UserActions();
		ua.Click_JavaScript(submit);
		ua.Wait_Sec();
		boolean isExist = ua.GetDisplayed(already);
		if(isExist)
		{
			ua.Wait_Sec();
			ua.Click_JavaScript(cancelBrand);
		}
		

	}

	public void clickOkPopup() {

		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(popupok);
		if(isExist)
		{
		ua.click(popupok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("PopUp is not present. So not clicking on it.");
		}
	}
	
	public void clickOkPopup_SubTask() {

		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(subtaskpopupok);
		if(isExist)
		{
		ua.click(subtaskpopupok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the subtask PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Subtask PopUp is not present. So not clicking on it.");
		}

	}
	
	
	public void clickOkPopup_Action() {

		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(actionpopupok);
		if(isExist)
		{
		ua.click(actionpopupok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the action PopUp.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Action PopUp is not present. So not clicking on it.");
		}
	}

	
	public void clickOkPopup_SubAction() {

		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(subactionpopupok);
		if(isExist)
		{
		ua.click(subactionpopupok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the subaction PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("SubAction PopUp is not present. So not clicking on it.");
		}
	}
	
	public void clickOkPopup_Brand() {

		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(brandpopupok);
		if(isExist)
		{
		ua.click(brandpopupok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the brand PopUp.");
		}
		else{
			ExtentCucumberAdapter.addTestStepLog("Brand PopUp is not present. So not clicking on it.");
		}
	}
	
	public void clickOkPopup_AgentSkill() {

		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(agentskillpopupok);
		if(isExist)
		{
		ua.click(agentskillpopupok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the agentskill PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("AgentSkill PopUp is not present. So not clicking on it.");
		}
	}
	
	public void clickOkPopup_LanguageSkill() {

		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(languageskillpopupok);
		if(isExist)
		{
		ua.click(languageskillpopupok);
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the languageskill PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("LanguageSkill PopUp is not present. So not clicking on it.");
		}
	}
	
	public void clickOkPopup_Mapping() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isExist = ua.GetDisplayed(mappingpopupok);
		if(isExist)
		{
		ua.click(mappingpopupok);
		ua.Wait_Sec();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the mapping PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Mapping PopUp is not present. So not clicking on it.");
		}

	}
	
	public void clickOkPopup_Pos() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isExist = ua.GetDisplayed(pospopupok);
		if(isExist)
		{
		ua.click(pospopupok);
		ua.Wait_Sec();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the pos PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Pos PopUp is not present. So not clicking on it.");
		}

	}
	
	
	public void clickOkPopup_Pcc() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isExist = ua.GetDisplayed(pccpopupok);
		if(isExist)
		{
		ua.click(pccpopupok);
		ua.Wait_Sec();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the pcc PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Pcc PopUp is not present. So not clicking on it.");
		}

	}
	
	public void clickOkPopup_Gds() {

		ua  = new UserActions();
	    ua.Wait_Sec();
		boolean isExist = ua.GetDisplayed(gdspopupok);
		if(isExist)
		{
		ua.click(gdspopupok);
		ua.Wait_Sec();
		ExtentCucumberAdapter.addTestStepLog("Successfully clicked on OK button from the gds PopUp.");
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Gds PopUp is not present. So not clicking on it.");
		}

	}
	
	
	public void ClickSubTasks() {
	
		ua  = new UserActions();
		boolean isVisible = ua.GetDisplayed(subtask);
		if(isVisible)
		{
			ua.Click_JavaScript(subtask);
		}
		else{
			
			ua.click(MasterData);
        	ua.Click_JavaScript(subtask);
			
		}

	}

	public void enterNewSubTaskCode() throws IOException {
		ua  = new UserActions();
		String scode = ua.getCellData("UserData","SubTaskCode",2);
		ua.SetValue(subtaskcode,scode);
	}

	public void enterNewSubTaskName() throws IOException {
		
		ua  = new UserActions();
		String sname = ua.getCellData("UserData","SubTaskName",2);
		ua.SetValue(subtaskname,sname);
	}

	public String getSuccessMsg() {
		
		ua  = new UserActions();
		boolean isExist = ua.GetDisplayed(TaskSuccessText);
		if(isExist)
		{
		String msg = ua.getText(TaskSuccessText);
		return msg;
		}
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Already exist.So it is not created again.");
			
		}
		return null;
	}

	public void ClickAction() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(action);
		if(isVisible)
		{
			ua.click(action);
		}
		else{
			ua.click(MasterData);
			ua.Wait_Sec();
        	ua.click(action);
		}

	}

	public void enterNewActionCode() throws IOException {
		
		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isExist = ua.GetExistance(actioncode);
		if (isExist) {
			String acode = ua.getCellData("UserData","ActionCode",2);
			ua.Wait_Sec();
			ua.SetValue(actioncode, acode);
		}
	}

	public void enterNewActionName() throws IOException {
		
		ua  = new UserActions();
		String aname = ua.getCellData("UserData","ActionName",2);
		ua.SetValue(actionname,aname);
	}

	public void clickMapSubtaskAction() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(maptasksubtaskaction);
		if(isVisible)
		{
			ua.click(maptasksubtaskaction);
		}
		else{
			
			ua.click(MasterData);
			ua.Wait_Sec();
        	ua.click(maptasksubtaskaction);	
		}
	}

	public void selectTask() throws IOException {

		ua  = new UserActions();
		//tcode
		String mtask = ua.getCellData("UserData","MappingTaskName",2);
		//UserActions.SelectValue(selecttask, tcode);
		ua.SelectByOptionValue(selecttask,mtask);
	}
	
	public void selectTaskForExistingMap() throws IOException {

		ua  = new UserActions();
		String mtask = ua.getCellData("UserData","MappingTaskName",2);
		ua.SelectByOptionValue(selecttask,mtask);
		Boolean isDisplayedNoData = ua.GetDisplayed(nodata);
		if(!isDisplayedNoData)
		{
			
		}
		
		
	}

	public void clickMapTaskSubtaskAction_Button() {

		ua  = new UserActions();
		ua.Wait_Sec();
		ua.Wait_Sec();
		ua.click(mapsubtask);

	}

	public void selectSubTask() throws IOException {

		ua  = new UserActions();
		ua.Wait_Sec();
		String msubtask = ua.getCellData("UserData","MappingSubTaskName",2);
		//UserActions.SelectValue(selectsubtask, msubtask);
		ua.Wait_Sec();
		ua.Wait_Sec();
		ua.Wait_Sec();
		ua.SelectByOptionValue(selectsubtask,msubtask);

	}

	public void selectAction() throws IOException, InterruptedException {
		
		ua  = new UserActions();
		String maction = ua.getCellData("UserData","MappingActionName",2);
		ua.click_by_dynamicCss(maction);

	}
	
	
	public void selectSubAction() throws InterruptedException, IOException{
			
		   ua  = new UserActions();
		   String msubaction = ua.getCellData("UserData","MappingSubActionName",2);
			ua.click_by_dynamicCss(msubaction);

	}

	public void clickPOS() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(pos);
		if(isVisible)
		{
			ua.click(pos);
		}
		else{
			
			ua.click(MasterData);
			ua.Wait_Sec();
        	ua.click(pos);
		}
	}

	public void enterPosCode() throws IOException {
		
		ua  = new UserActions();
		 String pcode = ua.getCellData("UserData","PosCode",2);
		 ua.SetValue(poscode,pcode);

	}

	public void enterPosName() throws IOException {
		
		ua  = new UserActions();
		String pname = ua.getCellData("UserData","PosName",2);
		ua.SetValue(posname, pname);

	}

	public void selectCountry() throws IOException {

		String Country = ua.getCellData("UserData","Country",2);
		ua.SelectValue(country, Country);

	}

	public void selectBrand() throws IOException {
		
		ua  = new UserActions();
		ua.Wait_Sec();
		Boolean isExist = ua.GetExistance(brand);
		if (isExist) {
			String Brand = ua.getCellData("UserData","Brand",2);
			//UserActions.SelectValue(brand, Brand);
			ua.SelectByOptionValue(brand,Brand);
		}
	}

	public void selectCurrency() throws IOException {

		ua  = new UserActions();
		ua.Wait_Sec();
		String Currency = ua.getCellData("UserData","Currency",2);
		ua.SelectValue(currency, Currency);

	}

	public void selectLangId() throws InterruptedException, IOException {
 
		    ua  = new UserActions();
			ua.click(langid);
			String LangId = ua.getCellData("UserData","LangId",2);
			ua.click_by_dynamicxpath(LangId);
			ua.click(langid);
	}

	public void addIataCode() throws IOException {
		
		ua  = new UserActions();
		ua.click(addnewiata);
		//String icode = UserActions.getCellData("UserData","Iatacode",2);
		String icode = ua.getNumericFormulaCellData("UserData","Iatacode",2);
		ua.SetValue(iatanumber,icode);
		ua.click(confirmiata);

	}

	public void clickPccConfiguration() {

		ua  = new UserActions();
		boolean isVisible =ua.GetDisplayed(pccconfiguration);
		if(isVisible)
		{
			ua.click(pccconfiguration);
		}
		else{
			
			ua.click(MasterData);
        	ua.click(pccconfiguration);	
		}
	}

	public void selectPOSAndGDS() throws IOException {
        
		ua  = new UserActions();
		String Pos = ua.getCellData("UserData","Pos",2);
		String Gds = ua.getCellData("UserData","Gds",2);
		//String Gds = UserActions.getNumericFormulaCellData("UserData","Gds",2);
		
		//int gdsIndex = Integer.parseInt(Gds);
		ua.SelectByOptionValue(selectpos, Pos);
		
		ua.SelectValue(selectgds, Gds);
		//UserActions.SelectValueByIndex(selectgds,gdsIndex);
		
	}

	public void enterPCC() throws IOException {

		ua  = new UserActions();
		String Pcc = ua.getCellData("UserData","Pcc",2);
		ua.SetValue(pcc, Pcc);
	}
	
	
	public void click_SubAction() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(subaction);
		if(isVisible)
		{
			ua.click(subaction);
		}
		else{
			
			ua.click(MasterData);
        	ua.click(subaction);
			
		}
		ua.Wait_Sec();

	}
	
	public void enterNewSubActionCode() throws IOException {
		
		ua  = new UserActions();
		String sacode = ua.getCellData("UserData","SubActionCode",2);
		ua.Wait_Sec();
		ua.SetValue(subactionCode,sacode);
	}
	
	public void enterNewSubActionName() throws IOException {
		
		ua  = new UserActions();
		String saname = ua.getCellData("UserData","SubActionName",2);
		ua.Wait_Sec();
		ua.SetValue(subactionName,saname);
	}
	
	public void clickAgentSkills()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(agentskills);
		if(isVisible)
		{
			ua.click(agentskills);
		}
		else{
			
			ua.click(MasterData);
			ua.Wait_Sec();
        	ua.click(agentskills);
			
		}
	}
	
	public void enterAgentSkillCode() throws IOException
	{
		ua  = new UserActions();
		String AgentSkillCode = ua.getCellData("UserData","AgentSkillCode",2);
		ua.Wait_Sec();
		ua.SetValue(agentskillcode, AgentSkillCode);
		
	}
	
	public void enterAgentSkillName() throws IOException
	{
		ua  = new UserActions();
		String AgentSkillName = ua.getCellData("UserData","AgentSkillName",2);
		ua.Wait_Sec();
		ua.SetValue(agentskillname, AgentSkillName);
	}
	
	public void clickLanguageSkills()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(languageskills);
		if(isVisible)
		{
			ua.click(languageskills);
		}
		else{
			
			ua.click(MasterData);
			ua.Wait_Sec();
        	ua.click(languageskills);
		}
	}
	
	public void enterLanguageCode() throws IOException
	{
		ua  = new UserActions();
		String lcode = ua.getCellData("UserData","LanguageCode",2);
		ua.Wait_Sec();
		ua.SetValue(languagecode, lcode);
		
	}
	
	public void enterLanguageName() throws IOException
	{
		ua  = new UserActions();
		String lname = ua.getCellData("UserData","LanguageName",2);
		ua.Wait_Sec();
		ua.SetValue(languagename, lname);
	}
	
	
	public void ClickBrand() {

		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(brands);
		if(isVisible)
		{
			ua.click(brands);
		}
		else{
			ua.click(MasterData);
			ua.Wait_Sec();
        	ua.click(brands);
		}

	}
	
	public void enterBrandCode() throws IOException
	{
		ua  = new UserActions();
		String bcode = ua.getCellData("UserData","BrandCode",2);
		ua.Wait_Sec();
		ua.SetValue(brandcode, bcode);
		
	}
	
	public void enterBrandName() throws IOException
	{
		ua  = new UserActions();
		String bname = ua.getCellData("UserData","BrandName",2);
		ua.SetValue(brandname, bname);
		
	}
	
	public void ClickCountry() {

		ua  = new UserActions();
		boolean isVisible = ua.GetDisplayed(countries);
		if(isVisible)
		{
			ua.click(countries);
		}
		else{
			ua.click(MasterData);
        	ua.click(countries);
		}
	}
		
	    public void enterRegionName() throws IOException
		{
	    	ua  = new UserActions();
			String rname = ua.getCellData("UserData","RegionName",2);
			ua.SetValue(regionname, rname);
	     }
	    
	    public void enterCountryCode() throws IOException
		{
	    	ua  = new UserActions();
			String ccode = ua.getCellData("UserData","CountryCode",2);
			ua.SetValue(countrycode, ccode);
		
	     }

}