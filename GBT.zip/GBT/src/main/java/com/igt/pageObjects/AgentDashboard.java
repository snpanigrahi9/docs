package com.igt.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class AgentDashboard extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;

	public AgentDashboard(WebDriver d) {
		this.d = d;
	}

	public final By autotask = By.cssSelector(p.getProperty("Autotask_locator"));
	public final By manualtask = By.cssSelector(p.getProperty("Manualtask_locator"));
	public final By createmanualworkitem = By.cssSelector(p.getProperty("CreateManualWorkitem_locator"));
	public final By splprojectinitiated = By.cssSelector(p.getProperty("SplProjectInitiated_locator"));
	public final By traininginitiated = By.cssSelector(p.getProperty("TrainingInitiated_locator"));
	public final By meeting = By.cssSelector(p.getProperty("Meeting_locator"));
	public final By coaching = By.cssSelector(p.getProperty("Coaching_locator"));
	public final By schedulebreak = By.cssSelector(p.getProperty("ScheduleBreak_locator"));
	public final By unschedulebreak = By.cssSelector(p.getProperty("UnscheduleBreak_locator"));
	public final By notreadyressupport = By.cssSelector(p.getProperty("NotReadyResSupport_locator"));
	public final By notreadypcproblem = By.cssSelector(p.getProperty("NotReadyPCProblem_locator"));
	public final By notreadyotherdepartment = By.cssSelector(p.getProperty("NotReadyOtherDepartment_locator"));
	public final By lunchbreak = By.cssSelector(p.getProperty("LunchBreak_locator"));
	public final By itemspick = By.cssSelector(p.getProperty("ItemsPick_locator"));
	public final By itemscomplete = By.cssSelector(p.getProperty("ItemsComplete_locator"));
	public final By itemsescalate = By.cssSelector(p.getProperty("ItemsEscalate_locator"));
	public final By itemsdelay = By.cssSelector(p.getProperty("ItemsDelay_locator"));
	public final By clickMyprofile = By.cssSelector(p.getProperty("AgentClickMyProfile_locator"));
	public final By mydashboard = By.id(p.getProperty("MyDashboard_locator"));
	public final By myprofile = By.cssSelector(p.getProperty("MyProfile_locator"));
	public final By changepassword = By.cssSelector(p.getProperty("ChangePassword_locator"));
	public final By logout = By.cssSelector(p.getProperty("AgentLogout_locator"));
	
	public void verifyAutoTaskTile() {
		
		ua  = new UserActions();
		String getAutoTask1 = ua.GetText_JavaScript(autotask);
		String getAutoTask = getAutoTask1.trim();
		
		Assert.assertEquals("Auto Task",getAutoTask);
		
		
		
	}
	
	public void verifyManualTaskTile() {
		
		ua  = new UserActions();
		String getManualTask1 = ua.GetText_JavaScript(manualtask);
		String getManualTask = getManualTask1.trim();
		
		Assert.assertEquals("Manual Task",getManualTask);
			
	}
	
	public void verifyCreateManualWorkitemTile() {
		
		ua  = new UserActions();
		String getManualTask1 = ua.GetText_JavaScript(manualtask);
		String getManualTask = getManualTask1.trim();
		
		Assert.assertEquals("Manual Task",getManualTask);
			
	}
	
	public void verifysplProjectInitiatedTile() {
		
		ua  = new UserActions();
		String getSplProjectInitiated1 = ua.GetText_JavaScript(splprojectinitiated);
		String getSplProjectInitiated = getSplProjectInitiated1.trim();
		
		Assert.assertEquals("Spl. Project Initiated",getSplProjectInitiated);
			
	}
	
	public void verifyTrainingInitiatedTile() {
		
		ua  = new UserActions();
		String getTrainingInitiated1 = ua.GetText_JavaScript(traininginitiated);
		String getTrainingInitiated = getTrainingInitiated1.trim();
		
		Assert.assertEquals("Training Initiated",getTrainingInitiated);
			
	}
	
	public void verifyMeetingTile() {
		
		ua  = new UserActions();
		String getMeeting1 = ua.GetText_JavaScript(meeting);
		String getMeeting = getMeeting1.trim();
		Assert.assertEquals("Meeting",getMeeting);
			
	}
	
	public void verifyCoachingTile() {
		
		ua  = new UserActions();
		String getCoaching1 = ua.GetText_JavaScript(coaching);
		String getCoaching = getCoaching1.trim();
		Assert.assertEquals("Coaching",getCoaching);
			
	}
	
	public void verifyScheduleBreakTile() {
		
		ua  = new UserActions();
		String getScheduleBreak1 = ua.GetText_JavaScript(schedulebreak);
		String getScheduleBreak = getScheduleBreak1.trim();
		Assert.assertEquals("Schedule Break",getScheduleBreak);
			
	}
	
	public void verifyUnScheduleBreakTile() {
		
		ua  = new UserActions();
		String getUnscheduleBreak1 = ua.GetText_JavaScript(unschedulebreak);
		String getUnscheduleBreak = getUnscheduleBreak1.trim();
		Assert.assertEquals("Unschedule Break",getUnscheduleBreak);
			
	}
	
	public void verifyNotReadyResSupportTile() {
		ua  = new UserActions();
		String getNotReadyResSupport1 = ua.GetText_JavaScript(notreadyressupport);
		String getNotReadyResSupport = getNotReadyResSupport1.trim();
		Assert.assertEquals("Not Ready Res Support",getNotReadyResSupport);
			
	}
	
	public void verifyNotReadyPCProblemTile() {
		ua  = new UserActions();
		String getNotReadyPCProblem1 = ua.GetText_JavaScript(notreadypcproblem);
		String getNotReadyPCProblem = getNotReadyPCProblem1.trim();
		Assert.assertEquals("Not Ready PC Problem",getNotReadyPCProblem);
			
	}
	
	public void verifyNotReadyOtherDepartmentTile() {
		ua  = new UserActions();
		String getNotReadyOtherDepartment1 = ua.GetText_JavaScript(notreadyotherdepartment);
		String getNotReadyOtherDepartment = getNotReadyOtherDepartment1.trim();
		Assert.assertEquals("Not Ready Other Department",getNotReadyOtherDepartment);
			
	}
	
	public void verifyLunchBreakTile() {
		ua  = new UserActions();
		String getLunchBreak1 = ua.GetText_JavaScript(lunchbreak);
		String getLunchBreak = getLunchBreak1.trim();
		Assert.assertEquals("Lunch Break",getLunchBreak);
			
	}
	
	public String getItemsPick() {
		ua  = new UserActions();
		String getItemsPick = ua.GetText_JavaScript(itemspick);
		return getItemsPick;
			
	}
	
	public String getItemsComplete() {
		ua  = new UserActions();
		String getItemsComplete = ua.GetText_JavaScript(itemscomplete);
		return getItemsComplete;
			
	}
	
	public String getItemsEscalate() {
		ua  = new UserActions();
		String getItemsEscalate = ua.GetText_JavaScript(itemsescalate);
		return getItemsEscalate;	
	}
	
	public String getItemsDelay() {
		ua  = new UserActions();
		String getItemsDelay = ua.GetText_JavaScript(itemsdelay);
		return getItemsDelay;		
	}
	
	public void clickMyDashboard()
	{
		ua  = new UserActions();
	    ua.Click_JavaScript(clickMyprofile);
		
	}
	public void verifyMyDashboardMenu() {
		ua  = new UserActions();
		//WebElement mdashboard = d.findElement(mydashboard);
		//wait.until(ExpectedConditions.visibilityOf(mydashboard));
		boolean isExistMydashboard = ua.GetExistance(mydashboard);
		if(isExistMydashboard == false)
		{
			Assert.fail();
		}	
	}
	
	public void verifyMyprofileMenu() {
		ua  = new UserActions();
		boolean isExistMyprofile = ua.GetExistance(myprofile);
		if(isExistMyprofile == false)
		{
			Assert.fail();
		}	
	}
	
	public void verifyChangePasswordMenu() {
		ua  = new UserActions();
		boolean isExistChangepassword = ua.GetExistance(changepassword);
		if(isExistChangepassword == false)
		{
			Assert.fail();
		}	
	}
	
	public void verifyLogoutMenu() {
		ua  = new UserActions();
		boolean isExistLogout = ua.GetExistance(logout);
		if(isExistLogout == false)
		{
			Assert.fail();
		}	
	}

}
