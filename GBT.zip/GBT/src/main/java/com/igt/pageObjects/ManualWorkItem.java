package com.igt.pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class ManualWorkItem extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;

	public ManualWorkItem(WebDriver d) {
		this.d = d;
	}
	
	public final By manualworkitem = By.cssSelector(p.getProperty("CreateManualWorkitem_locator"));
	public final By callertype = By.cssSelector(p.getProperty("ByCallerType_locator"));
	public final By clicksubmit = By.cssSelector(p.getProperty("clickSubmit_locator"));
	public final By pos = By.cssSelector(p.getProperty("SPOS_locator"));
	public final By gds = By.cssSelector(p.getProperty("GDS_locator"));
	public final By pnr = By.cssSelector(p.getProperty("PNRText_locator"));
	public final By task = By.cssSelector(p.getProperty("STask_locator"));
	public final By subtask = By.cssSelector(p.getProperty("SSubTask_locator"));
	public final By remark = By.cssSelector(p.getProperty("RemarksText_locator"));
	public final By completeWorkItemButton = By.cssSelector(p.getProperty("CompleteWorkItemButton_locator"));
	public final By confirmcomplete = By.cssSelector(p.getProperty("ConfirmComplete_locator"));
	public final By clickprofile = By.cssSelector(p.getProperty("Profile_locator"));
	public final By clickdashboard = By.cssSelector(p.getProperty("MDashboard_locator"));
	
	
	public void clickManualWorkItem()
	{
		ua  = new UserActions();
		Boolean isExist = ua.GetExistance(manualworkitem);
		if(isExist)
		{
		ua.Wait_Sec();
		ua.click(manualworkitem);
		}
		else{
			ua.click(clickprofile);
			ua.click(clickdashboard);
			ua.click(manualworkitem);
		}
	}
	
	public void clickByCallerTypeTab()
	{
		ua  = new UserActions();
		ua.click(callertype);
	}
	
	public void submit()
	{
		ua  = new UserActions();
		ua.click(clicksubmit);
	}
	
	
	public void selectPointOfSale() throws IOException
	{
		ua  = new UserActions();
		String posname = ua.getCellData("AgentRoleData","POS",2);
		ua.SelectValue(pos,posname );
	}
	
	public void selectGDS() throws IOException
	{
		ua  = new UserActions();
		String gdsname = ua.getCellData("AgentRoleData","GDS",2);
		ua.SelectValue(gds,gdsname);
	}
	
	public void enterPNRName() throws IOException
	{
		ua  = new UserActions();
		String pnrname = ua.getCellData("AgentRoleData","PNR",2);
		ua.SetValue(pnr,pnrname);
	}
	
	public void selectTask() throws IOException
	{
		ua  = new UserActions();
		String taskname = ua.getCellData("AgentRoleData","Task",2);
		ua.SelectByOptionValue(task,taskname);
	}
	
	public void selectSubTask() throws IOException
	{
		ua  = new UserActions();
		String subtaskname = ua.getCellData("AgentRoleData","SubTask",2);
		ua.SelectByOptionValue(subtask,subtaskname);
	}
	
	public void enterRemark() throws IOException
	{
		ua  = new UserActions();
		String remark_text = ua.getCellData("AgentRoleData","Remark",2);
		ua.SetValue(remark,remark_text);
	}
	
	public void selectAction() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String selectAction = ua.getCellData("AgentRoleData","Actions_ManualWorkItem",2);
		ua.xpathUsingTextByJavaScript(selectAction);
	}
	
	public void selectDiagnostics() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String selectDiagnostics = ua.getCellData("AgentRoleData","Diagnostics_ManualWorkItem",2);
		ua.DynamicXpathUsingTextByJavaScript(selectDiagnostics);
	}
	
	public void clickCompleteWorkitemButton()
	{
		ua  = new UserActions();
		ua.click(completeWorkItemButton);
	}
	
	public void clickConfirmComplete()
	{
		ua  = new UserActions();
		ua.click(confirmcomplete);
	}
	

}
