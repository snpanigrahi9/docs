package com.igt.pageObjects;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class Dashboard extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;

	public Dashboard(WebDriver d) {
		this.d = d;

	}
	
	public final By dashboard = By.cssSelector(p.getProperty("Dashboard_locator"));
	public final By agentworkitem = By.cssSelector(p.getProperty("AgentAndWorkItem_locator"));
	public final By site = By.cssSelector(p.getProperty("site_locator"));
	public final By sitepartitions = By.cssSelector(p.getProperty("sitepartitions_locator"));
	public final By duration = By.cssSelector(p.getProperty("duration_locator"));
	public final By search = By.cssSelector(p.getProperty("searchbutton_locator"));
	public final By stqOrastq = By.cssSelector(p.getProperty("stq/astq_locator"));
	public final By expandarrow = By.cssSelector(p.getProperty("arrow_locator"));
	public final By workitemstatus = By.cssSelector(p.getProperty("workitemstatus_locator"));
	public final By newitems = By.cssSelector(p.getProperty("newitems_locator"));
	
	
	
	
	public void click_Dashboard()
	{
		ua  = new UserActions();
		ua.Click_JavaScript(dashboard);
	}
	
	public void click_agentworkitem()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(agentworkitem);
		if(isVisible)
		{
		ua.Wait_Sec();
		ua.Click_JavaScript(agentworkitem);
		}
		else{		
			ua.Click_JavaScript(dashboard);
			ua.Wait_Sec();
			ua.Click_JavaScript(agentworkitem);	
		}
	}
	
	public void select_Site_Sitepartitions_Duration() throws IOException
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		String dsite = ua.getCellData("UserData","Site_AgentWorkItem",2);
		ua.SelectValue(site, dsite);
		String dsitepartitions = ua.getCellData("UserData","SitePartitions_AgentWorkItem",2);
		ua.SelectValue(sitepartitions, dsitepartitions);
		String dduration = ua.getCellData("UserData","Duration_AgentWorkItem",2);
		//String dduration = UserActions.getNumericFormulaCellData("UserData","Duration_AgentWorkItem",2);
		ua.SelectValue(duration, dduration);
	}
	
	public void select_Stq() throws IOException, InterruptedException
	{
		ua  = new UserActions();
		String dstq = ua.getCellData("UserData","Stq_AgentWorkItem",2);
		//UserActions.dynamicXpathNoSpace(dstq);
		ua.clickXpathUsingTextByJavaScript(dstq);
		
	}
	
	public void click_Search()
	{
		ua  = new UserActions();
		ua.Click_JavaScript(search);
	}
	
	public void click_StqAstq()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(stqOrastq);
		if(isVisible){
			ua.Wait_Sec();
		ua.Click_JavaScript(stqOrastq);
	     }
		else{
			
			ua.Click_JavaScript(dashboard);
			ua.Wait_Sec();
			ua.Click_JavaScript(stqOrastq);
		}
	}
	
	public void click_ExpandArrow()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		ua.mouseHover(newitems);
		ua.Wait_Sec();
		ua.Click_JavaScript(expandarrow);
	}
	
	public void verifyExpandDialog()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		boolean isVisible = ua.GetDisplayed(workitemstatus);
		if(isVisible)
		{
			ExtentCucumberAdapter.addTestStepLog("Expand arrow verified successfully.");
			
		}
		
		else{
			
			ExtentCucumberAdapter.addTestStepLog("Error occured in expand arrow.");
		}
		
	}
	
	public void expandAllSTQ()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int stqsize = d.findElements(By.xpath("//table[@class='table ']//td[contains(@id,'stq')]")).size();
		for(int i=1;i<=stqsize;i++)
		{
			ua.Wait_Sec();
			d.findElement(By.xpath("(//table[@class='table ']//td[contains(@id,'stq')])["+i+"]")).click();
			ua.Wait_Sec();
			
		}
	}
	
	public void verifyCompletedWorkItemsCount()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int l = d.findElements(By.xpath("//table[@class='table ']//tr[@class='accordion-toggle collapsed']")).size();		
		for(int k = 1;k<=l;k++)
		{	
		//d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])[1]"));
		String stqname = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[contains(@id,'stq')]")).getText();
		String completedworkitems_count = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[2]")).getText();	
		ExtentCucumberAdapter.addTestStepLog("Completed work items count for"+ stqname + " is " +completedworkitems_count);	
		
		}			
	}
	
	public void verifyNewWorkItemsCount()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int l = d.findElements(By.xpath("//table[@class='table ']//tr[@class='accordion-toggle collapsed']")).size();		
		for(int k = 1;k<=l;k++)
		{	
		//d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])[1]"));
		String stqname = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[contains(@id,'stq')]")).getText();
		String newworkitems_count = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[3]")).getText();	
		ExtentCucumberAdapter.addTestStepLog("New work items count for"+ stqname + " is " +newworkitems_count);	
		
		}			
	}
	
	public void verifySLABreachedCount()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int l = d.findElements(By.xpath("//table[@class='table ']//tr[@class='accordion-toggle collapsed']")).size();		
		for(int k = 1;k<=l;k++)
		{	
		//d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])[1]"));
		String stqname = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[contains(@id,'stq')]")).getText();
		String slacount = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[4]")).getText();	
		ExtentCucumberAdapter.addTestStepLog("SLA breached count for"+ stqname + " is " +slacount);	
		
		}			
	}
	
	public void verifyAgentsAssignedCount()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int l = d.findElements(By.xpath("//table[@class='table ']//tr[@class='accordion-toggle collapsed']")).size();		
		for(int k = 1;k<=l;k++)
		{	
		//d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])[1]"));
		String stqname = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[contains(@id,'stq')]")).getText();
		String agentassigned_count = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[5]")).getText();	
		ExtentCucumberAdapter.addTestStepLog("Agent Assigned count for"+ stqname + " is " +agentassigned_count);	
		
		}			
	}
	
	public void verifyAgentsWorkingCount()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int l = d.findElements(By.xpath("//table[@class='table ']//tr[@class='accordion-toggle collapsed']")).size();		
		for(int k = 1;k<=l;k++)
		{	
		//d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])[1]"));
		String stqname = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[contains(@id,'stq')]")).getText();
		String agentworking_count = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[6]")).getText();	
		ExtentCucumberAdapter.addTestStepLog("Agents working count for"+ stqname + " is " +agentworking_count);	
		
		}			
	}
	
	public void verifyAgentsOnBreakCount()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int l = d.findElements(By.xpath("//table[@class='table ']//tr[@class='accordion-toggle collapsed']")).size();		
		for(int k = 1;k<=l;k++)
		{	
		//d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])[1]"));
		String stqname = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[contains(@id,'stq')]")).getText();
		String agentonbreak_count = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[7]")).getText();	
		ExtentCucumberAdapter.addTestStepLog("Agents on break count for"+ stqname + " is " +agentonbreak_count);	
		
		}			
	}
	
	public void verifyAgentsIdleCount()
	{
		ua  = new UserActions();
		ua.Wait_Sec();
		int l = d.findElements(By.xpath("//table[@class='table ']//tr[@class='accordion-toggle collapsed']")).size();		
		for(int k = 1;k<=l;k++)
		{	
		//d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])[1]"));
		String stqname = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[contains(@id,'stq')]")).getText();
		String agentidle_count = d.findElement(By.xpath("(//table[@class='table ']//tr[@class='accordion-toggle collapsed'])["+k+"]//td[8]")).getText();	
		ExtentCucumberAdapter.addTestStepLog("Agents idle count for"+ stqname + " is " +agentidle_count);	
		
		}			
	}
	
}
