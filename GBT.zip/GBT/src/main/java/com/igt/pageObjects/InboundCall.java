package com.igt.pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.aventstack.extentreports.cucumber.adapter.ExtentCucumberAdapter;
import com.igt.base.TestSetup;
import com.igt.utility.UserActions;

public class InboundCall extends TestSetup {
	
	UserActions ua = null;
	public WebDriver d;
	
	public InboundCall(WebDriver d)
	{
		this.d=d;
	}
	
	public final By inboundcall = By.cssSelector(p.getProperty("inboundCall_locator"));
	public final By bysearchpnr = By.cssSelector(p.getProperty("bySearchPNR_locator"));
	public final By bycallertype = By.cssSelector(p.getProperty("byCallerType_locator"));
	public final By airlineoutbound = By.cssSelector(p.getProperty("airlineOutbound_locator"));
	public final By customeroutbound = By.cssSelector(p.getProperty("customerOutbound_locator"));
	public final By email = By.cssSelector(p.getProperty("email-locator"));
	public final By other = By.cssSelector(p.getProperty("Other_locator"));
	public final By QueueWork = By.cssSelector(p.getProperty("QueueWork_locator"));
	public final By SlackEscalation = By.cssSelector(p.getProperty("SlackEscalation_locator"));
	public final By clickprofile = By.cssSelector(p.getProperty("Profile_locator"));
	public final By clickdashboard = By.cssSelector(p.getProperty("MDashboard_locator"));
	
	public void clickInboundcall()
	{
		ua  = new UserActions();
		ua.click(clickprofile);
		ua.Wait_Sec();
		ua.click(clickdashboard);
		ua.Wait_Sec();
		ua.click(inboundcall);
	}
	
	public void verifyBysearchPnr_Tab()
	{
		ua  = new UserActions();
		Boolean isExist_BySearchPnr = ua.GetExistance(bysearchpnr);
		if(isExist_BySearchPnr)
		{
			ExtentCucumberAdapter.addTestStepLog("BySearchPNR tab is present");
		}
	}
	
	public void verifyBycallerType_Tab()
	{
		ua  = new UserActions();
		Boolean isExist_ByCallerType = ua.GetExistance(bycallertype);
		if(isExist_ByCallerType)
		{
			ExtentCucumberAdapter.addTestStepLog("ByCallerType tab is present");
		}
	}
	
	public void clickBycallerType_Tab()
	{
		ua  = new UserActions();
		ua.click(bycallertype);
	}
	
	public void verifyAirlineOutboundOption()
	{
		ua  = new UserActions();
		Boolean isExist_AirlineOutbound = ua.GetExistance(airlineoutbound);
		if(isExist_AirlineOutbound)
		{
			ExtentCucumberAdapter.addTestStepLog("Airline outbound option is present in the dropdown.");
		}
	}
	
	public void verifyCustomerOutboundOption()
	{
		ua  = new UserActions();
		Boolean isExist_CustomerOutbound = ua.GetExistance(customeroutbound);
		if(isExist_CustomerOutbound)
		{
			ExtentCucumberAdapter.addTestStepLog("Customer outbound option is present in the dropdown.");
		}
	}
	
	public void verifyEmailOption()
	{
		ua  = new UserActions();
		Boolean isExist_email = ua.GetExistance(email);
		if(isExist_email)
		{
			ExtentCucumberAdapter.addTestStepLog("Email option is present in the dropdown.");
		}
	}
	
	public void verifyOtherOption()
	{
		ua  = new UserActions();
		Boolean isExist_other = ua.GetExistance(other);
		if(isExist_other)
		{
			ExtentCucumberAdapter.addTestStepLog("Other option is present in the dropdown.");
		}
	}
	
	public void verifyQueueWorkOption()
	{
		ua  = new UserActions();
		Boolean isExist_QueueWork = ua.GetExistance(QueueWork);
		if(isExist_QueueWork)
		{
			ExtentCucumberAdapter.addTestStepLog("QueueWork option is present in the dropdown.");
		}
	}
	
	public void verifySlackEscalationOption()
	{
		ua  = new UserActions();
		Boolean isExist_SlackEscalation = ua.GetExistance(SlackEscalation);
		if(isExist_SlackEscalation)
		{
			ExtentCucumberAdapter.addTestStepLog("SlackEscalation option is present in the dropdown.");
		}
	}
	

}
