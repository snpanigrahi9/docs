package org.igt.demo.stepDefinitions;


import org.igt.demo.apitests.GetTest;

import io.cucumber.java.en.Given;


public class carnivalStepDefinitions {
	
	
	@Given("API endpoint")
	public void api_endpoint() {
	 
		//System.out.println("test");
		GetTest gt = new GetTest();
		gt.sampleGetRequest();
	}
	

}
