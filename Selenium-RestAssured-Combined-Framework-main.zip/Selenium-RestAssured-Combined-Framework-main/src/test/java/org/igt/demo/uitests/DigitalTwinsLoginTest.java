/**
 * 
 */
package org.igt.demo.uitests;

import org.aeonbits.owner.ConfigFactory;
import org.openqa.selenium.By;
import org.igt.demo.drivers.DriverManager;
import org.igt.demo.enums.PropertiesType;
import org.igt.demo.enums.WaitMethods;
import org.igt.demo.pompages.BasePage;
import org.igt.demo.utils.PropertyUtilOwnerLib;
import org.igt.demo.utils.PropertyUtils;

/**
 * Apr 5, 2022
 * @author Mandeep Sheoran
 * @version 1.0
 * @since 1.0
 * @see
 */
public class DigitalTwinsLoginTest {
	private static PropertyUtilOwnerLib config = ConfigFactory.create(PropertyUtilOwnerLib.class);
	public static final  By usernamefield = By.id("mat-input-0");
	public  static final  By passwordfield = By.id("mat-input-1");
	public  static final  By loginbttn = By.xpath("//span[@class='button-text ng-star-inserted']");
	public static final  By lgaunity = By.xpath("/html[1]/body[1]/app-root[1]/app-dashboard[1]/app-airports[1]/div[1]/div[2]/div[1]/div[3]/app-airport-card[1]/mat-card[1]/div[3]/app-button[1]/button[1]/span[1]/span[1]/span[1]");
	public static String portalUrl = null;
	public static String lgaunitylUrl = null;
	public static String portalUsername = null;
	public static String portalPassword = null;

	static {
		portalUrl = config.WEBURL();
		lgaunitylUrl = PropertyUtils.getValue(String.valueOf(PropertiesType.LGAUNITYURL));
		portalUsername = config.DTUSERNAME();
		portalPassword = config.DTPASSWORD();
	}

	public static void login() throws InterruptedException {
		if (portalUsername.length() == 0 || portalPassword.length() == 0) {
			throw new IllegalArgumentException("Login: USERNAME or PASSWORD cannot be empty");
		}
		DriverManager.getDriver().manage().window().maximize();
		BasePage.sendkeys(usernamefield, portalUsername, WaitMethods.PRESENCE, "Username Entered");
		BasePage.sendkeys(passwordfield, portalPassword, WaitMethods.PRESENCE, "Password Entered");
		BasePage.click(loginbttn, WaitMethods.CLICKABLE, "Login button");
		BasePage.navigateToURL(lgaunitylUrl);
	}
}
