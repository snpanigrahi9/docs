

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class RemoveElementArray {

	public static void main(String[] args) {
		
		//String ing = {"BMW,Audi,Honda,Hero"};
		List<String> a = Arrays.asList("BMW","Audi","Honda","Hero");
		a.stream().forEach(x->{System.out.println(x);});
	   	List<String> l = a.stream().filter(y->!y.equals("Hero")).collect(Collectors.toList());
	   	System.out.println(l);
		
		
	

		
		
	}

}
