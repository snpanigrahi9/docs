import java.util.List;
import java.util.stream.Collectors;

public class Whitespace {

	public static void main(String[] args) {
		
		
		String s = "s a t y a";
		List<Character> space = s.chars().filter(c->!Character.isWhitespace(c)).mapToObj(c->(char)c).collect(Collectors.toList());
		space.forEach(System.out::print);
		
		
		
		
		
		

	}

}
