

public class ReplaceCharacterEachWord {

	public static void main(String[] args) {
		
		
		
		var a = "Go to joho";
		//"G$ t$$ j$$$h$$$$"
		
		var sb = new StringBuilder();
		int count =0;
		
		for(int i=0;i<a.length();i++)
		{
			if(a.charAt(i)=='o')
			{
				count++;
				sb.repeat('$',count);
			}
			else {
				sb.append(a.charAt(i));
			}
		}
		
		System.out.println(sb.toString());
	
	}

}
