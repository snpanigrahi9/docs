

import java.util.OptionalInt;

public class NumberMax {

	public static void main(String[] args) {
		
		
		int n = 7623961;
		String m = String.valueOf(n);
		int max = m.chars().map(c->c - '0').max().getAsInt();
		System.out.println(max);
		

	}

}
