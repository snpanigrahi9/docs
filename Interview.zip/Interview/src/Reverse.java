import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Reverse {

	public static void main(String[] args) {
		
		String s = "satya";
		List<String> r = Arrays.asList(s).stream().map(x-> new StringBuilder(x).reverse().toString())
		.collect(Collectors.toList());
		r.forEach(System.out::print);
		
		
		
		

	}

}
