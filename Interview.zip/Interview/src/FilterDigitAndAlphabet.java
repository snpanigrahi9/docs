

public class FilterDigitAndAlphabet {

	public static void main(String[] args) {
		
		String str = "sa12ty3";
		
		for(int i=0;i<str.length();i++)
		{
			Character cha = str.charAt(i);
			if(cha.isDigit(cha))
			{
				System.out.print(cha);
			}
			
			
		}
		
		
		System.out.println("\n");
		
		
		for(int i=0;i<str.length();i++)
		{
			Character cha = str.charAt(i);
			if(cha.isAlphabetic(cha))
			{
				System.out.print(cha);
			}
			
			
		}
		
		
		

	}

}
