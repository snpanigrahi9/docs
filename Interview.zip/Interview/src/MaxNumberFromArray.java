import java.util.stream.IntStream;

public class MaxNumberFromArray {

	public static void main(String[] args) {
		
		int[]iarray = {10,20,30};
		int i = IntStream.of(iarray).max().getAsInt();
		System.out.println(i);
		
		int m = IntStream.of(iarray).min().getAsInt();
		System.out.println(m);

	}

}
