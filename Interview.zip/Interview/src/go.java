import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class go {

	public static void main(String[] args) {
		
		StringBuilder b = new StringBuilder();
		 String s = "Go to joho";
		 
		 int count =0;
		 
		 for(int i=0;i<s.length();i++)
		 {
			 if(s.charAt(i)=='o')
			 {
				 count++;
				// b.r
			 }
			 
			 
		 }
		
		
}

}
