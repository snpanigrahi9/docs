

public class Latestswitchcase {

	public static void main(String[] args) {
		String bname="";
		String browser="opera";
		
		bname  = switch(browser)
		{
		case "Chrome" -> "browser is chrome";
		case "Firefox"->"browser is firefox";
		default-> "other browser";
		
		};
		
		System.out.println(bname);

	}

}
