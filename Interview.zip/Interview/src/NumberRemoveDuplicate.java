

public class NumberRemoveDuplicate {

	public static void main(String[] args) {
		
		int i = 1290152;
		String s = String.valueOf(i);
		
		s.chars().mapToObj(c ->(char)c).distinct().forEach(System.out::print);
		

	}

}
