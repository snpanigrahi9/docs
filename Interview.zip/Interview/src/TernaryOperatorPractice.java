
public class TernaryOperatorPractice {

	public static void main(String[] args) {


		int mark = 30;
		
		String result = mark> 40 ? "pass" : "fail";
		
		System.out.println(result);

	}

}
