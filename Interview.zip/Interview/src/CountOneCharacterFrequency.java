

public class CountOneCharacterFrequency {

	public static void main(String[] args) {
		 String s = "abbbac";
		 int j = 0;
		 for(int i =0 ; i<s.length();i++)
		 {
			 
			 Character c = s.charAt(i);
			 if(c == 'b')
			 {
				 j++;
				 
			 }
			 
		 }
		 System.out.println(j);
		 
	}

}
