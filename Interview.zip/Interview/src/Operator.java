
public class Operator {

	public static void main(String[] args) {
		
		int a = 5;
		a++;
		int b= ++a;
		System.out.println(a);
		System.out.println(b);

		System.out.println("**************************");
		
		int x = 5;
		x++;
		int y= x++;
		System.out.println(x);
		System.out.println(y);
		

	}

}
