

public class IncreaseNumberAfterEachChar {

	public static void main(String[] args) {
		
		StringBuilder n = new StringBuilder();
	      String s = "satya";
	    //Output   s1a2t3y4a5
	      
	      
	      
	      int count=1;
	      
	      for(int j = 0; j<s.length();j++)
	      {
	    	  char r = s.charAt(j);
	         n.append(r).append(count);
	         count++;
	    	  
	    	  
	      }
	      
	      System.out.println(n.toString());
		
		
		

	}

}
