import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class NumberTotalCount {
	
	
	
	
	public static void main(String[] args) {
		
		int i = 1290152;
		String s = String.valueOf(i);
		long l = s.chars().map(c->c - '0').sum();
		System.out.println(l);
		
		
		
		List<Integer>li = Arrays.asList(10,20,30);
		Optional<Integer> f = li.stream().max(Integer::compareTo);
		f.ifPresent(System.out::println);
		
    

       
		
	}
	
	
	
	

	

}

