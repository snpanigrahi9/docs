import java.util.List;
import java.util.stream.Collectors;

public class Digit {

	public static void main(String[] args) {
		
		String s = "Satya123";
	List<Character>digit = s.chars().filter(c->Character.isDigit(c)).mapToObj(c->(char)c).collect(Collectors.toList());
    digit.forEach(System.out::print);
    
	}

}
