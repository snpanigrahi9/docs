import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class RemoveDuplicateArray2 {

	public static void main(String[] args) {
		
		String[]s= {"Mango","Banana","Mango","Orange"};
		List<String>fruits = Arrays.asList(s);
		Set<String> unique = fruits.stream().distinct().collect(Collectors.toSet());
		unique.forEach(c -> System.out.println(c));
		
		

	}

}
