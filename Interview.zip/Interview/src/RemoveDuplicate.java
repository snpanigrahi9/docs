

import java.util.stream.Collector;

public class RemoveDuplicate {

	public static void main(String[] args) {
		
		
		String s = "satyanarayan";
		s.chars().mapToObj(c->(char)c).distinct().forEach(System.out::print);
		
		
		
		
		
		
		System.out.println("    ");
		
		
		long l = s.chars().filter(d -> d == 'a').count();
		 System.out.println("Occurrance of a is" +l);
		 
		 
		 


	}

}
