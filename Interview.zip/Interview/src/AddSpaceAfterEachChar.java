

public class AddSpaceAfterEachChar {

	public static void main(String[] args) {
		
		StringBuilder sb = new StringBuilder();
		String m = "satya";
		
		for (int i=0;i<m.length();i++)
		{
			char ch = m.charAt(i);
			sb.append(ch).append(" ");
			
		}
		
		System.out.print(sb.toString());
		
	}

}
