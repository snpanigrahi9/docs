import java.util.stream.Collectors;

public class Capital {

	public static void main(String[] args) {
		
		
		String s = "SATYAnarayan";
		String result = s.chars().filter(c->Character.isUpperCase(c)).mapToObj(c->String.valueOf((char)c)).
		collect(Collectors.joining());
		System.out.println(result);
		
		

	}

}
