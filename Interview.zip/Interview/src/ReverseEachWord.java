

public class ReverseEachWord {

	public static void main(String[] args) {
		
		
		
		var st = "satya narayan panigrahi";
		StringBuilder result = new StringBuilder();
		String[] w = st.split(" ");
		for (String s: w)
		{
			String bb = new StringBuilder(s).reverse().toString();
			result.append(bb).append(" ");
			
		}

		System.out.println(result.toString().trim());

}
}
