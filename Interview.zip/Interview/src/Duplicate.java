import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class Duplicate {

	public static void main(String[] args) {

		
		String s = "satya";
		Set<Character> cha = s.chars().mapToObj(c->(char)c).collect(Collectors.toSet());
		cha.forEach(System.out::print);
		
		System.out.println("***********************");
		
		
		//method 2
		
		
		List<Character> i = s.chars().mapToObj(x->(char)x).distinct().collect(Collectors.toList());
		i.forEach(a-> System.out.print(a));
		
		
	

	}

}
