

public class VowelConsonant {

	public static void main(String[] args) {
		
		String s = "satya";
	
		StringBuilder vowel = new StringBuilder();
		StringBuilder consonant = new StringBuilder();
		
		String upper = s.toUpperCase();
		 for(int i = 0; i<upper.length();i++)
		 {
			char c =  upper.charAt(i);
			if(c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U') {
				
				vowel.append(c);
				
				
			}
			
			else {
				
				consonant.append(c);
				
			}
			 
		 }
		 
		 System.out.println(vowel.toString());
		 System.out.println(consonant.toString());

	}

}
