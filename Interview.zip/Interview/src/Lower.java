import java.util.List;
import java.util.stream.Collectors;

public class Lower {

	public static void main(String[] args) {
	
		String s = "SaTYanARAYAN";
		List<Character> lower = s.chars().filter(Character::isLowerCase).mapToObj(c->(char)c).collect(Collectors.toList());
		lower.forEach(System.out::print);
		



	}

}
