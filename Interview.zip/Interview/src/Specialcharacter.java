
import java.util.stream.Collectors;

public class Specialcharacter {

	public static void main(String[] args) {
		
		
		String s = "S@#at&ya";
		String newword = s.chars().filter(c->!Character.isLetterOrDigit(c))
				.mapToObj(c->String.valueOf((char)c)).collect(Collectors.joining());
		System.out.println(newword);;
		
		

	}

}
