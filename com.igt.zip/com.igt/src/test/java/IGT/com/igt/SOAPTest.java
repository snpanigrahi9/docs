package IGT.com.igt;


import org.testng.annotations.Test;

import groovy.util.Node;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.IOUtils;

import io.restassured.RestAssured;
import io.restassured.internal.path.xml.NodeChildrenImpl;
import io.restassured.path.xml.XmlPath;

import static io.restassured.RestAssured.given;
import io.restassured.response.Response;


public class SOAPTest {
	
	Response r;
	
	@Test
	public void execute() throws IOException
	{
		RestAssured.useRelaxedHTTPSValidation();
	
        FileInputStream f = new FileInputStream("D:\\com.igt\\RequestSOAP\\RatePlan.xml");
        
        RestAssured.baseURI="https://qa-igt-ttconnect.ttaws.com/ttconnect/services/soap/ota/2008a/HotelService/clid/availpro";
        
        		
       r = given().header("content-type","text/xml")
       .and()
       .body(IOUtils.toString(f,"UTF-8"))
       .when()
       .post()
       .then()
       .log()
       .all()
       .extract()
       .response();

       
       String output = r.asString();
       //System.out.println(output);
        XmlPath path = new XmlPath(r.getBody().asString());  		
        String tok = path.getString("Envelope.Header.HTNGHeader.echoToken");
        System.out.println("token  is"+" "+tok); 
        
        
       String tok1 = path.getString("Envelope.Body.OTA_HotelRatePlanRS.RatePlans.RatePlan.Rates.Rate.@InvTypeCode");
       System.out.println("InventoryTypeCode  is"+" "+tok1); 
       
      
       	//RestAssured.given().body(IOUtils.toString(f,"UTF-8")).post().then().log().all().assertThat().statusCode(200);
        		
        		

    
        		
    }
		
		
		
		
	}

	
	

