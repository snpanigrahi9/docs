package IGT.com.igt;

import static io.restassured.RestAssured.given;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.commons.io.IOUtils;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;

public class PublicSOAPTest {

	Response r;
	
	@Test
	public void execute() throws IOException
	{
		RestAssured.useRelaxedHTTPSValidation();
	
        FileInputStream f = new FileInputStream("D:\\com.igt\\RequestSOAP\\NumberToWord.xml");
        
        RestAssured.baseURI="https://www.dataaccess.com/webservicesserver/NumberConversion.wso";
        
        		
       r = given().header("content-type","text/xml")
       .and()
       .body(IOUtils.toString(f,"UTF-8"))
       .when()
       .post()
       .then()
       .log()
       .all()
       .extract()
       .response();

       
       String output = r.asString();
       System.out.println(output);
        XmlPath path = new XmlPath(r.getBody().asString());  		
       String word =  path.getString("**.find { it.name() == 'NumberToWordsResult' }.text()");
        System.out.println("result  is"+" "+word); 
        		
    
        		
    }
	
}
