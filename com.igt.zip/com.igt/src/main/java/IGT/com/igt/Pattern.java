package IGT.com.igt;

public class Pattern {
	
	
	 static int i;
	 static int j;
	 static int count=1;

	public static void main(String[] args) {
		
		
		run("abaaba");	
		
	}
		
		
	public static int run(String s)
	{
		
		char[]c = s.toCharArray();
		for(i=0;i<=s.length();i++)
		{
			for(j=1;j<=s.length();j++)
			{
				
				
				if(c[i]==c[j])
				{
				System.out.println(c[i]);
				count++;
				break;
				}
				//break;
			}
			
			
		}
		return count;
		
	}		


}

