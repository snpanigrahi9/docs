package IGT.com.igt;

public class Sub extends Sup {

	Sub(int c, int d) {
		super(c, d);
		
	}

	public static void main(String[] args) {
		
		Sup s = new Sub(15,12);
		
		System.out.println(s.x);
		System.out.println(s.add());
		
	    

	}
	
	
	

}
