package IGT.com.igt;

public class SA {
	
	public static int d;

}
