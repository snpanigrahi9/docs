package IGT.com.igt;

public class SB extends SA {
	
	public void ini()
	{
		
		d=10;
		System.out.println(d);
		System.out.println("hi");
		
	}

}
