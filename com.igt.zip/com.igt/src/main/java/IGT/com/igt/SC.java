package IGT.com.igt;

public class SC extends SB {

	public static void main(String[] args) {
		
      SB b = new SB();
      b.ini();
    
		
		
	}
}
