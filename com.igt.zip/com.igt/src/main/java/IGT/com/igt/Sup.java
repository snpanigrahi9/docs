package IGT.com.igt;

public class Sup {
	
	
	int x = 10;
	int y = 20;
	
	public int add()
	{
		return x+y;
		
	}
	
	Sup(int c , int d)
	{
		int q = c-d;
		System.out.println(q);
	}

}
