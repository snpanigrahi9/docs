package IGT.com.igt;

public class SD extends SA {

	static{
		
		
		System.out.println(d);

	}

}
