package IGT.com.igt;

public class Rev {

	public static void main(String[] args) {
		
		 String s = "Satya narayan";
		 
		String[] str =  s.split(" ");
		
		for(int k = str.length-1;k>=0;k--)
		{
			
			StringBuilder b = new StringBuilder();
			b.append(str[k]);
			b.append("  ");
			
			System.out.print(b);
			
			
		}
		
		
		  System.out.println("  ");
		 
		 for(String s1 : str)
			
		 {
		 for(int i= s1.length()-1;i>=0;i-- )
		 {
			 String reverse = "";
			 s1.charAt(i);
			 reverse = reverse+s1.charAt(i);
			 System.out.print(reverse);
			 
		 }
		 }

	}

}

