package IGT.com.igt;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.commons.io.IOUtils;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;

import static io.restassured.RestAssured.given;
import io.restassured.response.Response;


public class App 
{
    public static void main( String[] args ) throws IOException
    {
        FileInputStream f = new FileInputStream("/com.igt/testng.xml");
        
        RestAssured.baseURI="http://qa-igt-ttconnect.ttaws.com";
        Response r =
        		
       given().header("content-type","text/xml").and().body(IOUtils.toString(f,"UTF-8")).when().post("/ttconnect/services/soap/ota/2008a/HotelService/clid/availpro")
       .then()
       .log()
       .all()
       .extract()
       .response();
        		
    XmlPath path = new XmlPath(r.asString());  		
        String inventoryType = path.getString("InvTypeCode");
        System.out.println("inventory type is"+" "+inventoryType);
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
        		
    }
}
