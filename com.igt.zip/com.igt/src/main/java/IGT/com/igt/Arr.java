package IGT.com.igt;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Arr {

	public static void main(String[] args) {
		
		int[]in = {1,2,3};
		int[]er = {4,5,6};
		List<int[]> l = new ArrayList<int[]>(Arrays.asList(in));
		l.addAll(Arrays.asList(er));
		Object[] o = l.toArray();
		Arrays.toString(o);	
			

	}

}
