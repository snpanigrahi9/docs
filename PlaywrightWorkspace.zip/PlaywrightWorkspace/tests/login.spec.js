const {test,expect} = require('@playwright/test');

test ("first testcase",async ({browser})=>{

const insta = await browser.newContext();

const fpage = await insta.newPage();
await fpage.goto("http://15.207.65.178:8080/ta/index");
console.log(await fpage.title());
await expect(fpage).toHaveTitle("IQD");
await fpage.locator("#emailID").type("taadmin@igt.in");
await fpage.locator("#PasswrdText").type("Admin@123");
await fpage.locator("[value='Login']").click();

});



test ("second testcase",async ({browser})=>{

    const insta = await browser.newContext();
    
    const fpage = await insta.newPage();
    await fpage.goto("http://15.207.65.178:8080/ta/index");
    console.log(await fpage.title());
    await expect(fpage).toHaveTitle("IQD");
    await fpage.locator("#emailID").type("taadmin@igt.in");
    //await fpage.locator("#PasswrdText").type("Admin@123");
    await fpage.locator("[value='Login']").click();
          console.log(await fpage.locator("ul[class='errorMessage'] li span").textContent());
          await expect(fpage.locator("ul[class='errorMessage'] li span")).toContainText('Password is required');

    
    });

    test ("third testcase",async ({browser})=>{

        const insta = await browser.newContext();
        
        const fpage = await insta.newPage();
        await fpage.goto("http://15.207.65.178:8080/ta/index");
        //console.log(await fpage.title());
        //await expect(fpage).toHaveTitle("IQD");
        await fpage.locator("#emailID").type("taadmin@igt.in");
        await fpage.locator("#PasswrdText").type("Admin@123");
        await fpage.locator("[value='Login']").click();
              //console.log(await fpage.locator("ul[class='errorMessage'] li span").textContent());
              //await expect(fpage.locator("ul[class='errorMessage'] li span")).toContainText('Password is required');
              console.log(await fpage.locator(".panel-title").nth(1).textContent());

        
        });