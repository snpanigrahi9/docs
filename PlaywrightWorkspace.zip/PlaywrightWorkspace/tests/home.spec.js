const {test} = require('@playwright/test');

test("home page testcase",async({page})=>{

await page.goto("http://15.207.65.178:8080/ta/index");
const username = page.locator("#emailID");
await username.fill("taadmin@igt.in");
const password = page.locator("#PasswrdText");
await password.fill("Admin@123");
const login = page.locator("[value='Login']");


await Promise.all(

[page.waitForNavigation(),
login.click(),
]

);

console.log(await page.locator(".panel-title span[class='accordion-toggle sub_menu not_active collapsed']").allTextContents());


});